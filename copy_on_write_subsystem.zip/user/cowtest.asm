
user/_cowtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <print>:
#include "kernel/stat.h"
#include "user/user.h"

void
print(const char *s)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	1000                	addi	s0,sp,32
   a:	84aa                	mv	s1,a0
  write(1, s, strlen(s));
   c:	386000ef          	jal	392 <strlen>
  10:	0005061b          	sext.w	a2,a0
  14:	85a6                	mv	a1,s1
  16:	4505                	li	a0,1
  18:	5d6000ef          	jal	5ee <write>
}
  1c:	60e2                	ld	ra,24(sp)
  1e:	6442                	ld	s0,16(sp)
  20:	64a2                	ld	s1,8(sp)
  22:	6105                	addi	sp,sp,32
  24:	8082                	ret

0000000000000026 <basic_test>:

// Test 1: basic parent/child divergence after a COW fault.
void
basic_test(void)
{
  26:	1101                	addi	sp,sp,-32
  28:	ec06                	sd	ra,24(sp)
  2a:	e822                	sd	s0,16(sp)
  2c:	e426                	sd	s1,8(sp)
  2e:	1000                	addi	s0,sp,32
  print("cowtest: basic_test starting\n");
  30:	00001517          	auipc	a0,0x1
  34:	b8050513          	addi	a0,a0,-1152 # bb0 <malloc+0xfe>
  38:	fc9ff0ef          	jal	0 <print>

  volatile int *p = (int*)sbrk(4096);
  3c:	6505                	lui	a0,0x1
  3e:	55c000ef          	jal	59a <sbrk>
  42:	84aa                	mv	s1,a0
  *p = 100;
  44:	06400793          	li	a5,100
  48:	c11c                	sw	a5,0(a0)

  int pid = fork();
  4a:	57c000ef          	jal	5c6 <fork>
  if(pid < 0){
  4e:	02054363          	bltz	a0,74 <basic_test+0x4e>
    print("cowtest: fork failed\n");
    exit(1);
  }

  if(pid == 0){
  52:	ed0d                	bnez	a0,8c <basic_test+0x66>
    // child: write, should not affect the parent
    *p = 200;
  54:	0c800713          	li	a4,200
  58:	c098                	sw	a4,0(s1)
    if(*p != 200){
  5a:	409c                	lw	a5,0(s1)
  5c:	2781                	sext.w	a5,a5
  5e:	02e78463          	beq	a5,a4,86 <basic_test+0x60>
      print("cowtest: FAIL child did not see its own write\n");
  62:	00001517          	auipc	a0,0x1
  66:	b8e50513          	addi	a0,a0,-1138 # bf0 <malloc+0x13e>
  6a:	f97ff0ef          	jal	0 <print>
      exit(1);
  6e:	4505                	li	a0,1
  70:	55e000ef          	jal	5ce <exit>
    print("cowtest: fork failed\n");
  74:	00001517          	auipc	a0,0x1
  78:	b6450513          	addi	a0,a0,-1180 # bd8 <malloc+0x126>
  7c:	f85ff0ef          	jal	0 <print>
    exit(1);
  80:	4505                	li	a0,1
  82:	54c000ef          	jal	5ce <exit>
    }
    exit(0);
  86:	4501                	li	a0,0
  88:	546000ef          	jal	5ce <exit>
  }

  wait(0);
  8c:	4501                	li	a0,0
  8e:	548000ef          	jal	5d6 <wait>

  if(*p != 100){
  92:	409c                	lw	a5,0(s1)
  94:	2781                	sext.w	a5,a5
  96:	06400713          	li	a4,100
  9a:	00e79d63          	bne	a5,a4,b4 <basic_test+0x8e>
    print("cowtest: FAIL parent value changed by child's write\n");
    exit(1);
  }

  print("cowtest: basic_test OK\n");
  9e:	00001517          	auipc	a0,0x1
  a2:	bba50513          	addi	a0,a0,-1094 # c58 <malloc+0x1a6>
  a6:	f5bff0ef          	jal	0 <print>
}
  aa:	60e2                	ld	ra,24(sp)
  ac:	6442                	ld	s0,16(sp)
  ae:	64a2                	ld	s1,8(sp)
  b0:	6105                	addi	sp,sp,32
  b2:	8082                	ret
    print("cowtest: FAIL parent value changed by child's write\n");
  b4:	00001517          	auipc	a0,0x1
  b8:	b6c50513          	addi	a0,a0,-1172 # c20 <malloc+0x16e>
  bc:	f45ff0ef          	jal	0 <print>
    exit(1);
  c0:	4505                	li	a0,1
  c2:	50c000ef          	jal	5ce <exit>

00000000000000c6 <multi_test>:

// Test 2: several children sharing the same page, each writing a
// different value -- checks refcounting with >2 owners.
void
multi_test(void)
{
  c6:	7139                	addi	sp,sp,-64
  c8:	fc06                	sd	ra,56(sp)
  ca:	f822                	sd	s0,48(sp)
  cc:	f426                	sd	s1,40(sp)
  ce:	f04a                	sd	s2,32(sp)
  d0:	ec4e                	sd	s3,24(sp)
  d2:	0080                	addi	s0,sp,64
  print("cowtest: multi_test starting\n");
  d4:	00001517          	auipc	a0,0x1
  d8:	b9c50513          	addi	a0,a0,-1124 # c70 <malloc+0x1be>
  dc:	f25ff0ef          	jal	0 <print>

  volatile int *p = (int*)sbrk(4096);
  e0:	6505                	lui	a0,0x1
  e2:	4b8000ef          	jal	59a <sbrk>
  e6:	892a                	mv	s2,a0
  *p = -1;
  e8:	57fd                	li	a5,-1
  ea:	c11c                	sw	a5,0(a0)

  int nchildren = 5;
  int i;

  for(i = 0; i < nchildren; i++){
  ec:	4481                	li	s1,0
  ee:	4995                	li	s3,5
    int pid = fork();
  f0:	4d6000ef          	jal	5c6 <fork>
    if(pid < 0){
  f4:	04054563          	bltz	a0,13e <multi_test+0x78>
      print("cowtest: fork failed\n");
      exit(1);
    }
    if(pid == 0){
  f8:	cd21                	beqz	a0,150 <multi_test+0x8a>
  for(i = 0; i < nchildren; i++){
  fa:	2485                	addiw	s1,s1,1
  fc:	ff349ae3          	bne	s1,s3,f0 <multi_test+0x2a>
 100:	4495                	li	s1,5
      exit(0);
    }
  }

  for(i = 0; i < nchildren; i++){
    int xstatus = 0;
 102:	fc042623          	sw	zero,-52(s0)
    wait(&xstatus);
 106:	fcc40513          	addi	a0,s0,-52
 10a:	4cc000ef          	jal	5d6 <wait>
    if(xstatus != 0){
 10e:	fcc42783          	lw	a5,-52(s0)
 112:	e7a5                	bnez	a5,17a <multi_test+0xb4>
  for(i = 0; i < nchildren; i++){
 114:	34fd                	addiw	s1,s1,-1
 116:	f4f5                	bnez	s1,102 <multi_test+0x3c>
      print("cowtest: FAIL a child reported failure\n");
      exit(1);
    }
  }

  if(*p != -1){
 118:	00092783          	lw	a5,0(s2)
 11c:	2781                	sext.w	a5,a5
 11e:	577d                	li	a4,-1
 120:	06e79663          	bne	a5,a4,18c <multi_test+0xc6>
    print("cowtest: FAIL parent value changed by a child's write\n");
    exit(1);
  }

  print("cowtest: multi_test OK\n");
 124:	00001517          	auipc	a0,0x1
 128:	c0c50513          	addi	a0,a0,-1012 # d30 <malloc+0x27e>
 12c:	ed5ff0ef          	jal	0 <print>
}
 130:	70e2                	ld	ra,56(sp)
 132:	7442                	ld	s0,48(sp)
 134:	74a2                	ld	s1,40(sp)
 136:	7902                	ld	s2,32(sp)
 138:	69e2                	ld	s3,24(sp)
 13a:	6121                	addi	sp,sp,64
 13c:	8082                	ret
      print("cowtest: fork failed\n");
 13e:	00001517          	auipc	a0,0x1
 142:	a9a50513          	addi	a0,a0,-1382 # bd8 <malloc+0x126>
 146:	ebbff0ef          	jal	0 <print>
      exit(1);
 14a:	4505                	li	a0,1
 14c:	482000ef          	jal	5ce <exit>
      *p = 1000 + i;
 150:	3e84849b          	addiw	s1,s1,1000
 154:	00992023          	sw	s1,0(s2)
      if(*p != 1000 + i){
 158:	00092783          	lw	a5,0(s2)
 15c:	2481                	sext.w	s1,s1
 15e:	00f48b63          	beq	s1,a5,174 <multi_test+0xae>
        print("cowtest: FAIL child saw wrong value after its own write\n");
 162:	00001517          	auipc	a0,0x1
 166:	b2e50513          	addi	a0,a0,-1234 # c90 <malloc+0x1de>
 16a:	e97ff0ef          	jal	0 <print>
        exit(1);
 16e:	4505                	li	a0,1
 170:	45e000ef          	jal	5ce <exit>
      exit(0);
 174:	4501                	li	a0,0
 176:	458000ef          	jal	5ce <exit>
      print("cowtest: FAIL a child reported failure\n");
 17a:	00001517          	auipc	a0,0x1
 17e:	b5650513          	addi	a0,a0,-1194 # cd0 <malloc+0x21e>
 182:	e7fff0ef          	jal	0 <print>
      exit(1);
 186:	4505                	li	a0,1
 188:	446000ef          	jal	5ce <exit>
    print("cowtest: FAIL parent value changed by a child's write\n");
 18c:	00001517          	auipc	a0,0x1
 190:	b6c50513          	addi	a0,a0,-1172 # cf8 <malloc+0x246>
 194:	e6dff0ef          	jal	0 <print>
    exit(1);
 198:	4505                	li	a0,1
 19a:	434000ef          	jal	5ce <exit>

000000000000019e <big_test>:
// Test 3: allocate many pages, fork, and have the child touch every
// single one. Mostly checks that COW survives at scale without
// crashing or corrupting data.
void
big_test(void)
{
 19e:	1101                	addi	sp,sp,-32
 1a0:	ec06                	sd	ra,24(sp)
 1a2:	e822                	sd	s0,16(sp)
 1a4:	e426                	sd	s1,8(sp)
 1a6:	1000                	addi	s0,sp,32
  print("cowtest: big_test starting\n");
 1a8:	00001517          	auipc	a0,0x1
 1ac:	ba050513          	addi	a0,a0,-1120 # d48 <malloc+0x296>
 1b0:	e51ff0ef          	jal	0 <print>

  int npages = 32; // 32 * 4096 = 128 KB
  char *base = sbrk(npages * 4096);
 1b4:	00020537          	lui	a0,0x20
 1b8:	3e2000ef          	jal	59a <sbrk>
 1bc:	84aa                	mv	s1,a0
 1be:	872a                	mv	a4,a0
  int i;

  for(i = 0; i < npages; i++)
 1c0:	4781                	li	a5,0
 1c2:	6605                	lui	a2,0x1
 1c4:	02000693          	li	a3,32
    base[i * 4096] = (char)i;
 1c8:	00f70023          	sb	a5,0(a4)
  for(i = 0; i < npages; i++)
 1cc:	2785                	addiw	a5,a5,1
 1ce:	9732                	add	a4,a4,a2
 1d0:	fed79ce3          	bne	a5,a3,1c8 <big_test+0x2a>

  int pid = fork();
 1d4:	3f2000ef          	jal	5c6 <fork>
  if(pid < 0){
 1d8:	02054f63          	bltz	a0,216 <big_test+0x78>
    print("cowtest: fork failed\n");
    exit(1);
  }

  if(pid == 0){
 1dc:	c531                	beqz	a0,228 <big_test+0x8a>
      }
    }
    exit(0);
  }

  wait(0);
 1de:	4501                	li	a0,0
 1e0:	3f6000ef          	jal	5d6 <wait>

  for(i = 0; i < npages; i++){
 1e4:	4781                	li	a5,0
 1e6:	6585                	lui	a1,0x1
 1e8:	02000613          	li	a2,32
    if(base[i * 4096] != (char)i){
 1ec:	0004c683          	lbu	a3,0(s1)
 1f0:	0ff7f713          	zext.b	a4,a5
 1f4:	04e69763          	bne	a3,a4,242 <big_test+0xa4>
  for(i = 0; i < npages; i++){
 1f8:	2785                	addiw	a5,a5,1
 1fa:	94ae                	add	s1,s1,a1
 1fc:	fec798e3          	bne	a5,a2,1ec <big_test+0x4e>
      print("cowtest: FAIL parent page corrupted by child\n");
      exit(1);
    }
  }

  print("cowtest: big_test OK\n");
 200:	00001517          	auipc	a0,0x1
 204:	b9850513          	addi	a0,a0,-1128 # d98 <malloc+0x2e6>
 208:	df9ff0ef          	jal	0 <print>
}
 20c:	60e2                	ld	ra,24(sp)
 20e:	6442                	ld	s0,16(sp)
 210:	64a2                	ld	s1,8(sp)
 212:	6105                	addi	sp,sp,32
 214:	8082                	ret
    print("cowtest: fork failed\n");
 216:	00001517          	auipc	a0,0x1
 21a:	9c250513          	addi	a0,a0,-1598 # bd8 <malloc+0x126>
 21e:	de3ff0ef          	jal	0 <print>
    exit(1);
 222:	4505                	li	a0,1
 224:	3aa000ef          	jal	5ce <exit>
 228:	4785                	li	a5,1
    for(i = 0; i < npages; i++){
 22a:	6685                	lui	a3,0x1
 22c:	02100713          	li	a4,33
      base[i * 4096] = (char)(i + 1); // touch/write every page -> COW fault each time
 230:	00f48023          	sb	a5,0(s1)
    for(i = 0; i < npages; i++){
 234:	0785                	addi	a5,a5,1
 236:	94b6                	add	s1,s1,a3
 238:	fee79ce3          	bne	a5,a4,230 <big_test+0x92>
    exit(0);
 23c:	4501                	li	a0,0
 23e:	390000ef          	jal	5ce <exit>
      print("cowtest: FAIL parent page corrupted by child\n");
 242:	00001517          	auipc	a0,0x1
 246:	b2650513          	addi	a0,a0,-1242 # d68 <malloc+0x2b6>
 24a:	db7ff0ef          	jal	0 <print>
      exit(1);
 24e:	4505                	li	a0,1
 250:	37e000ef          	jal	5ce <exit>

0000000000000254 <refcount_test>:

// Test 4 (Phase 4): use the pgrefcount() syscall to directly observe
// the effect of COW sharing and of the later private copy.
void
refcount_test(void)
{
 254:	1101                	addi	sp,sp,-32
 256:	ec06                	sd	ra,24(sp)
 258:	e822                	sd	s0,16(sp)
 25a:	e426                	sd	s1,8(sp)
 25c:	1000                	addi	s0,sp,32
  print("cowtest: refcount_test starting\n");
 25e:	00001517          	auipc	a0,0x1
 262:	b5250513          	addi	a0,a0,-1198 # db0 <malloc+0x2fe>
 266:	d9bff0ef          	jal	0 <print>

  volatile int *p = (int*)sbrk(4096);
 26a:	6505                	lui	a0,0x1
 26c:	32e000ef          	jal	59a <sbrk>
 270:	84aa                	mv	s1,a0
  *p = 42;
 272:	02a00793          	li	a5,42
 276:	c11c                	sw	a5,0(a0)

  printf("cowtest: before fork, refcount=%d (expect 1)\n", pgrefcount((uint64)p));
 278:	3f6000ef          	jal	66e <pgrefcount>
 27c:	85aa                	mv	a1,a0
 27e:	00001517          	auipc	a0,0x1
 282:	b5a50513          	addi	a0,a0,-1190 # dd8 <malloc+0x326>
 286:	778000ef          	jal	9fe <printf>

  int pid = fork();
 28a:	33c000ef          	jal	5c6 <fork>
  if(pid < 0){
 28e:	04054763          	bltz	a0,2dc <refcount_test+0x88>
    print("cowtest: fork failed\n");
    exit(1);
  }

  if(pid == 0){
 292:	e12d                	bnez	a0,2f4 <refcount_test+0xa0>
    // Right after fork, both parent and child point at the same
    // physical page, so refcount should be >= 2 (scheduling can make
    // it hard to guarantee an exact moment, so this print is
    // informational rather than a hard assertion).
    printf("cowtest: child refcount=%d before its own write (expect >= 2)\n",
 294:	8526                	mv	a0,s1
 296:	3d8000ef          	jal	66e <pgrefcount>
 29a:	85aa                	mv	a1,a0
 29c:	00001517          	auipc	a0,0x1
 2a0:	b6c50513          	addi	a0,a0,-1172 # e08 <malloc+0x356>
 2a4:	75a000ef          	jal	9fe <printf>
           pgrefcount((uint64)p));

    *p = 99; // triggers a COW fault -> private copy for the child
 2a8:	06300793          	li	a5,99
 2ac:	c09c                	sw	a5,0(s1)

    int r = pgrefcount((uint64)p);
 2ae:	8526                	mv	a0,s1
 2b0:	3be000ef          	jal	66e <pgrefcount>
 2b4:	84aa                	mv	s1,a0
    printf("cowtest: child refcount=%d after its own write (expect 1)\n", r);
 2b6:	85aa                	mv	a1,a0
 2b8:	00001517          	auipc	a0,0x1
 2bc:	b9050513          	addi	a0,a0,-1136 # e48 <malloc+0x396>
 2c0:	73e000ef          	jal	9fe <printf>
    if(r != 1){
 2c4:	4785                	li	a5,1
 2c6:	02f48463          	beq	s1,a5,2ee <refcount_test+0x9a>
      print("cowtest: FAIL refcount did not drop to 1 after COW copy\n");
 2ca:	00001517          	auipc	a0,0x1
 2ce:	bbe50513          	addi	a0,a0,-1090 # e88 <malloc+0x3d6>
 2d2:	d2fff0ef          	jal	0 <print>
      exit(1);
 2d6:	4505                	li	a0,1
 2d8:	2f6000ef          	jal	5ce <exit>
    print("cowtest: fork failed\n");
 2dc:	00001517          	auipc	a0,0x1
 2e0:	8fc50513          	addi	a0,a0,-1796 # bd8 <malloc+0x126>
 2e4:	d1dff0ef          	jal	0 <print>
    exit(1);
 2e8:	4505                	li	a0,1
 2ea:	2e4000ef          	jal	5ce <exit>
    }
    exit(0);
 2ee:	4501                	li	a0,0
 2f0:	2de000ef          	jal	5ce <exit>
  }

  wait(0);
 2f4:	4501                	li	a0,0
 2f6:	2e0000ef          	jal	5d6 <wait>
  print("cowtest: refcount_test OK\n");
 2fa:	00001517          	auipc	a0,0x1
 2fe:	bce50513          	addi	a0,a0,-1074 # ec8 <malloc+0x416>
 302:	cffff0ef          	jal	0 <print>
}
 306:	60e2                	ld	ra,24(sp)
 308:	6442                	ld	s0,16(sp)
 30a:	64a2                	ld	s1,8(sp)
 30c:	6105                	addi	sp,sp,32
 30e:	8082                	ret

0000000000000310 <main>:

int
main(void)
{
 310:	1141                	addi	sp,sp,-16
 312:	e406                	sd	ra,8(sp)
 314:	e022                	sd	s0,0(sp)
 316:	0800                	addi	s0,sp,16
  basic_test();
 318:	d0fff0ef          	jal	26 <basic_test>
  multi_test();
 31c:	dabff0ef          	jal	c6 <multi_test>
  big_test();
 320:	e7fff0ef          	jal	19e <big_test>
  refcount_test();
 324:	f31ff0ef          	jal	254 <refcount_test>
  print("cowtest: ALL TESTS PASSED\n");
 328:	00001517          	auipc	a0,0x1
 32c:	bc050513          	addi	a0,a0,-1088 # ee8 <malloc+0x436>
 330:	cd1ff0ef          	jal	0 <print>
  exit(0);
 334:	4501                	li	a0,0
 336:	298000ef          	jal	5ce <exit>

000000000000033a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 33a:	1141                	addi	sp,sp,-16
 33c:	e406                	sd	ra,8(sp)
 33e:	e022                	sd	s0,0(sp)
 340:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 342:	fcfff0ef          	jal	310 <main>
  exit(r);
 346:	288000ef          	jal	5ce <exit>

000000000000034a <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 34a:	1141                	addi	sp,sp,-16
 34c:	e422                	sd	s0,8(sp)
 34e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 350:	87aa                	mv	a5,a0
 352:	0585                	addi	a1,a1,1 # 1001 <digits+0xf1>
 354:	0785                	addi	a5,a5,1
 356:	fff5c703          	lbu	a4,-1(a1)
 35a:	fee78fa3          	sb	a4,-1(a5)
 35e:	fb75                	bnez	a4,352 <strcpy+0x8>
    ;
  return os;
}
 360:	6422                	ld	s0,8(sp)
 362:	0141                	addi	sp,sp,16
 364:	8082                	ret

0000000000000366 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 366:	1141                	addi	sp,sp,-16
 368:	e422                	sd	s0,8(sp)
 36a:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 36c:	00054783          	lbu	a5,0(a0)
 370:	cb91                	beqz	a5,384 <strcmp+0x1e>
 372:	0005c703          	lbu	a4,0(a1)
 376:	00f71763          	bne	a4,a5,384 <strcmp+0x1e>
    p++, q++;
 37a:	0505                	addi	a0,a0,1
 37c:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 37e:	00054783          	lbu	a5,0(a0)
 382:	fbe5                	bnez	a5,372 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 384:	0005c503          	lbu	a0,0(a1)
}
 388:	40a7853b          	subw	a0,a5,a0
 38c:	6422                	ld	s0,8(sp)
 38e:	0141                	addi	sp,sp,16
 390:	8082                	ret

0000000000000392 <strlen>:

uint
strlen(const char *s)
{
 392:	1141                	addi	sp,sp,-16
 394:	e422                	sd	s0,8(sp)
 396:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 398:	00054783          	lbu	a5,0(a0)
 39c:	cf91                	beqz	a5,3b8 <strlen+0x26>
 39e:	0505                	addi	a0,a0,1
 3a0:	87aa                	mv	a5,a0
 3a2:	86be                	mv	a3,a5
 3a4:	0785                	addi	a5,a5,1
 3a6:	fff7c703          	lbu	a4,-1(a5)
 3aa:	ff65                	bnez	a4,3a2 <strlen+0x10>
 3ac:	40a6853b          	subw	a0,a3,a0
 3b0:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 3b2:	6422                	ld	s0,8(sp)
 3b4:	0141                	addi	sp,sp,16
 3b6:	8082                	ret
  for(n = 0; s[n]; n++)
 3b8:	4501                	li	a0,0
 3ba:	bfe5                	j	3b2 <strlen+0x20>

00000000000003bc <memset>:

void*
memset(void *dst, int c, uint n)
{
 3bc:	1141                	addi	sp,sp,-16
 3be:	e422                	sd	s0,8(sp)
 3c0:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 3c2:	ca19                	beqz	a2,3d8 <memset+0x1c>
 3c4:	87aa                	mv	a5,a0
 3c6:	1602                	slli	a2,a2,0x20
 3c8:	9201                	srli	a2,a2,0x20
 3ca:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 3ce:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 3d2:	0785                	addi	a5,a5,1
 3d4:	fee79de3          	bne	a5,a4,3ce <memset+0x12>
  }
  return dst;
}
 3d8:	6422                	ld	s0,8(sp)
 3da:	0141                	addi	sp,sp,16
 3dc:	8082                	ret

00000000000003de <strchr>:

char*
strchr(const char *s, char c)
{
 3de:	1141                	addi	sp,sp,-16
 3e0:	e422                	sd	s0,8(sp)
 3e2:	0800                	addi	s0,sp,16
  for(; *s; s++)
 3e4:	00054783          	lbu	a5,0(a0)
 3e8:	cb99                	beqz	a5,3fe <strchr+0x20>
    if(*s == c)
 3ea:	00f58763          	beq	a1,a5,3f8 <strchr+0x1a>
  for(; *s; s++)
 3ee:	0505                	addi	a0,a0,1
 3f0:	00054783          	lbu	a5,0(a0)
 3f4:	fbfd                	bnez	a5,3ea <strchr+0xc>
      return (char*)s;
  return 0;
 3f6:	4501                	li	a0,0
}
 3f8:	6422                	ld	s0,8(sp)
 3fa:	0141                	addi	sp,sp,16
 3fc:	8082                	ret
  return 0;
 3fe:	4501                	li	a0,0
 400:	bfe5                	j	3f8 <strchr+0x1a>

0000000000000402 <gets>:

char*
gets(char *buf, int max)
{
 402:	711d                	addi	sp,sp,-96
 404:	ec86                	sd	ra,88(sp)
 406:	e8a2                	sd	s0,80(sp)
 408:	e4a6                	sd	s1,72(sp)
 40a:	e0ca                	sd	s2,64(sp)
 40c:	fc4e                	sd	s3,56(sp)
 40e:	f852                	sd	s4,48(sp)
 410:	f456                	sd	s5,40(sp)
 412:	f05a                	sd	s6,32(sp)
 414:	ec5e                	sd	s7,24(sp)
 416:	1080                	addi	s0,sp,96
 418:	8baa                	mv	s7,a0
 41a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 41c:	892a                	mv	s2,a0
 41e:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 420:	4aa9                	li	s5,10
 422:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 424:	89a6                	mv	s3,s1
 426:	2485                	addiw	s1,s1,1
 428:	0344d663          	bge	s1,s4,454 <gets+0x52>
    cc = read(0, &c, 1);
 42c:	4605                	li	a2,1
 42e:	faf40593          	addi	a1,s0,-81
 432:	4501                	li	a0,0
 434:	1b2000ef          	jal	5e6 <read>
    if(cc < 1)
 438:	00a05e63          	blez	a0,454 <gets+0x52>
    buf[i++] = c;
 43c:	faf44783          	lbu	a5,-81(s0)
 440:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 444:	01578763          	beq	a5,s5,452 <gets+0x50>
 448:	0905                	addi	s2,s2,1
 44a:	fd679de3          	bne	a5,s6,424 <gets+0x22>
    buf[i++] = c;
 44e:	89a6                	mv	s3,s1
 450:	a011                	j	454 <gets+0x52>
 452:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 454:	99de                	add	s3,s3,s7
 456:	00098023          	sb	zero,0(s3)
  return buf;
}
 45a:	855e                	mv	a0,s7
 45c:	60e6                	ld	ra,88(sp)
 45e:	6446                	ld	s0,80(sp)
 460:	64a6                	ld	s1,72(sp)
 462:	6906                	ld	s2,64(sp)
 464:	79e2                	ld	s3,56(sp)
 466:	7a42                	ld	s4,48(sp)
 468:	7aa2                	ld	s5,40(sp)
 46a:	7b02                	ld	s6,32(sp)
 46c:	6be2                	ld	s7,24(sp)
 46e:	6125                	addi	sp,sp,96
 470:	8082                	ret

0000000000000472 <stat>:

int
stat(const char *n, struct stat *st)
{
 472:	1101                	addi	sp,sp,-32
 474:	ec06                	sd	ra,24(sp)
 476:	e822                	sd	s0,16(sp)
 478:	e04a                	sd	s2,0(sp)
 47a:	1000                	addi	s0,sp,32
 47c:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 47e:	4581                	li	a1,0
 480:	18e000ef          	jal	60e <open>
  if(fd < 0)
 484:	02054263          	bltz	a0,4a8 <stat+0x36>
 488:	e426                	sd	s1,8(sp)
 48a:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 48c:	85ca                	mv	a1,s2
 48e:	198000ef          	jal	626 <fstat>
 492:	892a                	mv	s2,a0
  close(fd);
 494:	8526                	mv	a0,s1
 496:	160000ef          	jal	5f6 <close>
  return r;
 49a:	64a2                	ld	s1,8(sp)
}
 49c:	854a                	mv	a0,s2
 49e:	60e2                	ld	ra,24(sp)
 4a0:	6442                	ld	s0,16(sp)
 4a2:	6902                	ld	s2,0(sp)
 4a4:	6105                	addi	sp,sp,32
 4a6:	8082                	ret
    return -1;
 4a8:	597d                	li	s2,-1
 4aa:	bfcd                	j	49c <stat+0x2a>

00000000000004ac <atoi>:

int
atoi(const char *s)
{
 4ac:	1141                	addi	sp,sp,-16
 4ae:	e422                	sd	s0,8(sp)
 4b0:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 4b2:	00054683          	lbu	a3,0(a0)
 4b6:	fd06879b          	addiw	a5,a3,-48 # fd0 <digits+0xc0>
 4ba:	0ff7f793          	zext.b	a5,a5
 4be:	4625                	li	a2,9
 4c0:	02f66863          	bltu	a2,a5,4f0 <atoi+0x44>
 4c4:	872a                	mv	a4,a0
  n = 0;
 4c6:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 4c8:	0705                	addi	a4,a4,1
 4ca:	0025179b          	slliw	a5,a0,0x2
 4ce:	9fa9                	addw	a5,a5,a0
 4d0:	0017979b          	slliw	a5,a5,0x1
 4d4:	9fb5                	addw	a5,a5,a3
 4d6:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 4da:	00074683          	lbu	a3,0(a4)
 4de:	fd06879b          	addiw	a5,a3,-48
 4e2:	0ff7f793          	zext.b	a5,a5
 4e6:	fef671e3          	bgeu	a2,a5,4c8 <atoi+0x1c>
  return n;
}
 4ea:	6422                	ld	s0,8(sp)
 4ec:	0141                	addi	sp,sp,16
 4ee:	8082                	ret
  n = 0;
 4f0:	4501                	li	a0,0
 4f2:	bfe5                	j	4ea <atoi+0x3e>

00000000000004f4 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 4f4:	1141                	addi	sp,sp,-16
 4f6:	e422                	sd	s0,8(sp)
 4f8:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 4fa:	02b57463          	bgeu	a0,a1,522 <memmove+0x2e>
    while(n-- > 0)
 4fe:	00c05f63          	blez	a2,51c <memmove+0x28>
 502:	1602                	slli	a2,a2,0x20
 504:	9201                	srli	a2,a2,0x20
 506:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 50a:	872a                	mv	a4,a0
      *dst++ = *src++;
 50c:	0585                	addi	a1,a1,1
 50e:	0705                	addi	a4,a4,1
 510:	fff5c683          	lbu	a3,-1(a1)
 514:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 518:	fef71ae3          	bne	a4,a5,50c <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 51c:	6422                	ld	s0,8(sp)
 51e:	0141                	addi	sp,sp,16
 520:	8082                	ret
    dst += n;
 522:	00c50733          	add	a4,a0,a2
    src += n;
 526:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 528:	fec05ae3          	blez	a2,51c <memmove+0x28>
 52c:	fff6079b          	addiw	a5,a2,-1 # fff <digits+0xef>
 530:	1782                	slli	a5,a5,0x20
 532:	9381                	srli	a5,a5,0x20
 534:	fff7c793          	not	a5,a5
 538:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 53a:	15fd                	addi	a1,a1,-1
 53c:	177d                	addi	a4,a4,-1
 53e:	0005c683          	lbu	a3,0(a1)
 542:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 546:	fee79ae3          	bne	a5,a4,53a <memmove+0x46>
 54a:	bfc9                	j	51c <memmove+0x28>

000000000000054c <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 54c:	1141                	addi	sp,sp,-16
 54e:	e422                	sd	s0,8(sp)
 550:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 552:	ca05                	beqz	a2,582 <memcmp+0x36>
 554:	fff6069b          	addiw	a3,a2,-1
 558:	1682                	slli	a3,a3,0x20
 55a:	9281                	srli	a3,a3,0x20
 55c:	0685                	addi	a3,a3,1
 55e:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 560:	00054783          	lbu	a5,0(a0)
 564:	0005c703          	lbu	a4,0(a1)
 568:	00e79863          	bne	a5,a4,578 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 56c:	0505                	addi	a0,a0,1
    p2++;
 56e:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 570:	fed518e3          	bne	a0,a3,560 <memcmp+0x14>
  }
  return 0;
 574:	4501                	li	a0,0
 576:	a019                	j	57c <memcmp+0x30>
      return *p1 - *p2;
 578:	40e7853b          	subw	a0,a5,a4
}
 57c:	6422                	ld	s0,8(sp)
 57e:	0141                	addi	sp,sp,16
 580:	8082                	ret
  return 0;
 582:	4501                	li	a0,0
 584:	bfe5                	j	57c <memcmp+0x30>

0000000000000586 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 586:	1141                	addi	sp,sp,-16
 588:	e406                	sd	ra,8(sp)
 58a:	e022                	sd	s0,0(sp)
 58c:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 58e:	f67ff0ef          	jal	4f4 <memmove>
}
 592:	60a2                	ld	ra,8(sp)
 594:	6402                	ld	s0,0(sp)
 596:	0141                	addi	sp,sp,16
 598:	8082                	ret

000000000000059a <sbrk>:

char *
sbrk(int n) {
 59a:	1141                	addi	sp,sp,-16
 59c:	e406                	sd	ra,8(sp)
 59e:	e022                	sd	s0,0(sp)
 5a0:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 5a2:	4585                	li	a1,1
 5a4:	0b2000ef          	jal	656 <sys_sbrk>
}
 5a8:	60a2                	ld	ra,8(sp)
 5aa:	6402                	ld	s0,0(sp)
 5ac:	0141                	addi	sp,sp,16
 5ae:	8082                	ret

00000000000005b0 <sbrklazy>:

char *
sbrklazy(int n) {
 5b0:	1141                	addi	sp,sp,-16
 5b2:	e406                	sd	ra,8(sp)
 5b4:	e022                	sd	s0,0(sp)
 5b6:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 5b8:	4589                	li	a1,2
 5ba:	09c000ef          	jal	656 <sys_sbrk>
}
 5be:	60a2                	ld	ra,8(sp)
 5c0:	6402                	ld	s0,0(sp)
 5c2:	0141                	addi	sp,sp,16
 5c4:	8082                	ret

00000000000005c6 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 5c6:	4885                	li	a7,1
 ecall
 5c8:	00000073          	ecall
 ret
 5cc:	8082                	ret

00000000000005ce <exit>:
.global exit
exit:
 li a7, SYS_exit
 5ce:	4889                	li	a7,2
 ecall
 5d0:	00000073          	ecall
 ret
 5d4:	8082                	ret

00000000000005d6 <wait>:
.global wait
wait:
 li a7, SYS_wait
 5d6:	488d                	li	a7,3
 ecall
 5d8:	00000073          	ecall
 ret
 5dc:	8082                	ret

00000000000005de <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 5de:	4891                	li	a7,4
 ecall
 5e0:	00000073          	ecall
 ret
 5e4:	8082                	ret

00000000000005e6 <read>:
.global read
read:
 li a7, SYS_read
 5e6:	4895                	li	a7,5
 ecall
 5e8:	00000073          	ecall
 ret
 5ec:	8082                	ret

00000000000005ee <write>:
.global write
write:
 li a7, SYS_write
 5ee:	48c1                	li	a7,16
 ecall
 5f0:	00000073          	ecall
 ret
 5f4:	8082                	ret

00000000000005f6 <close>:
.global close
close:
 li a7, SYS_close
 5f6:	48d5                	li	a7,21
 ecall
 5f8:	00000073          	ecall
 ret
 5fc:	8082                	ret

00000000000005fe <kill>:
.global kill
kill:
 li a7, SYS_kill
 5fe:	4899                	li	a7,6
 ecall
 600:	00000073          	ecall
 ret
 604:	8082                	ret

0000000000000606 <exec>:
.global exec
exec:
 li a7, SYS_exec
 606:	489d                	li	a7,7
 ecall
 608:	00000073          	ecall
 ret
 60c:	8082                	ret

000000000000060e <open>:
.global open
open:
 li a7, SYS_open
 60e:	48bd                	li	a7,15
 ecall
 610:	00000073          	ecall
 ret
 614:	8082                	ret

0000000000000616 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 616:	48c5                	li	a7,17
 ecall
 618:	00000073          	ecall
 ret
 61c:	8082                	ret

000000000000061e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 61e:	48c9                	li	a7,18
 ecall
 620:	00000073          	ecall
 ret
 624:	8082                	ret

0000000000000626 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 626:	48a1                	li	a7,8
 ecall
 628:	00000073          	ecall
 ret
 62c:	8082                	ret

000000000000062e <link>:
.global link
link:
 li a7, SYS_link
 62e:	48cd                	li	a7,19
 ecall
 630:	00000073          	ecall
 ret
 634:	8082                	ret

0000000000000636 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 636:	48d1                	li	a7,20
 ecall
 638:	00000073          	ecall
 ret
 63c:	8082                	ret

000000000000063e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 63e:	48a5                	li	a7,9
 ecall
 640:	00000073          	ecall
 ret
 644:	8082                	ret

0000000000000646 <dup>:
.global dup
dup:
 li a7, SYS_dup
 646:	48a9                	li	a7,10
 ecall
 648:	00000073          	ecall
 ret
 64c:	8082                	ret

000000000000064e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 64e:	48ad                	li	a7,11
 ecall
 650:	00000073          	ecall
 ret
 654:	8082                	ret

0000000000000656 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 656:	48b1                	li	a7,12
 ecall
 658:	00000073          	ecall
 ret
 65c:	8082                	ret

000000000000065e <pause>:
.global pause
pause:
 li a7, SYS_pause
 65e:	48b5                	li	a7,13
 ecall
 660:	00000073          	ecall
 ret
 664:	8082                	ret

0000000000000666 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 666:	48b9                	li	a7,14
 ecall
 668:	00000073          	ecall
 ret
 66c:	8082                	ret

000000000000066e <pgrefcount>:
.global pgrefcount
pgrefcount:
 li a7, SYS_pgrefcount
 66e:	48d9                	li	a7,22
 ecall
 670:	00000073          	ecall
 ret
 674:	8082                	ret

0000000000000676 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 676:	1101                	addi	sp,sp,-32
 678:	ec06                	sd	ra,24(sp)
 67a:	e822                	sd	s0,16(sp)
 67c:	1000                	addi	s0,sp,32
 67e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 682:	4605                	li	a2,1
 684:	fef40593          	addi	a1,s0,-17
 688:	f67ff0ef          	jal	5ee <write>
}
 68c:	60e2                	ld	ra,24(sp)
 68e:	6442                	ld	s0,16(sp)
 690:	6105                	addi	sp,sp,32
 692:	8082                	ret

0000000000000694 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 694:	715d                	addi	sp,sp,-80
 696:	e486                	sd	ra,72(sp)
 698:	e0a2                	sd	s0,64(sp)
 69a:	f84a                	sd	s2,48(sp)
 69c:	0880                	addi	s0,sp,80
 69e:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 6a0:	c299                	beqz	a3,6a6 <printint+0x12>
 6a2:	0805c363          	bltz	a1,728 <printint+0x94>
  neg = 0;
 6a6:	4881                	li	a7,0
 6a8:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 6ac:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 6ae:	00001517          	auipc	a0,0x1
 6b2:	86250513          	addi	a0,a0,-1950 # f10 <digits>
 6b6:	883e                	mv	a6,a5
 6b8:	2785                	addiw	a5,a5,1
 6ba:	02c5f733          	remu	a4,a1,a2
 6be:	972a                	add	a4,a4,a0
 6c0:	00074703          	lbu	a4,0(a4)
 6c4:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 6c8:	872e                	mv	a4,a1
 6ca:	02c5d5b3          	divu	a1,a1,a2
 6ce:	0685                	addi	a3,a3,1
 6d0:	fec773e3          	bgeu	a4,a2,6b6 <printint+0x22>
  if(neg)
 6d4:	00088b63          	beqz	a7,6ea <printint+0x56>
    buf[i++] = '-';
 6d8:	fd078793          	addi	a5,a5,-48
 6dc:	97a2                	add	a5,a5,s0
 6de:	02d00713          	li	a4,45
 6e2:	fee78423          	sb	a4,-24(a5)
 6e6:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 6ea:	02f05a63          	blez	a5,71e <printint+0x8a>
 6ee:	fc26                	sd	s1,56(sp)
 6f0:	f44e                	sd	s3,40(sp)
 6f2:	fb840713          	addi	a4,s0,-72
 6f6:	00f704b3          	add	s1,a4,a5
 6fa:	fff70993          	addi	s3,a4,-1
 6fe:	99be                	add	s3,s3,a5
 700:	37fd                	addiw	a5,a5,-1
 702:	1782                	slli	a5,a5,0x20
 704:	9381                	srli	a5,a5,0x20
 706:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 70a:	fff4c583          	lbu	a1,-1(s1)
 70e:	854a                	mv	a0,s2
 710:	f67ff0ef          	jal	676 <putc>
  while(--i >= 0)
 714:	14fd                	addi	s1,s1,-1
 716:	ff349ae3          	bne	s1,s3,70a <printint+0x76>
 71a:	74e2                	ld	s1,56(sp)
 71c:	79a2                	ld	s3,40(sp)
}
 71e:	60a6                	ld	ra,72(sp)
 720:	6406                	ld	s0,64(sp)
 722:	7942                	ld	s2,48(sp)
 724:	6161                	addi	sp,sp,80
 726:	8082                	ret
    x = -xx;
 728:	40b005b3          	neg	a1,a1
    neg = 1;
 72c:	4885                	li	a7,1
    x = -xx;
 72e:	bfad                	j	6a8 <printint+0x14>

0000000000000730 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 730:	711d                	addi	sp,sp,-96
 732:	ec86                	sd	ra,88(sp)
 734:	e8a2                	sd	s0,80(sp)
 736:	e0ca                	sd	s2,64(sp)
 738:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 73a:	0005c903          	lbu	s2,0(a1)
 73e:	28090663          	beqz	s2,9ca <vprintf+0x29a>
 742:	e4a6                	sd	s1,72(sp)
 744:	fc4e                	sd	s3,56(sp)
 746:	f852                	sd	s4,48(sp)
 748:	f456                	sd	s5,40(sp)
 74a:	f05a                	sd	s6,32(sp)
 74c:	ec5e                	sd	s7,24(sp)
 74e:	e862                	sd	s8,16(sp)
 750:	e466                	sd	s9,8(sp)
 752:	8b2a                	mv	s6,a0
 754:	8a2e                	mv	s4,a1
 756:	8bb2                	mv	s7,a2
  state = 0;
 758:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 75a:	4481                	li	s1,0
 75c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 75e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 762:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 766:	06c00c93          	li	s9,108
 76a:	a005                	j	78a <vprintf+0x5a>
        putc(fd, c0);
 76c:	85ca                	mv	a1,s2
 76e:	855a                	mv	a0,s6
 770:	f07ff0ef          	jal	676 <putc>
 774:	a019                	j	77a <vprintf+0x4a>
    } else if(state == '%'){
 776:	03598263          	beq	s3,s5,79a <vprintf+0x6a>
  for(i = 0; fmt[i]; i++){
 77a:	2485                	addiw	s1,s1,1
 77c:	8726                	mv	a4,s1
 77e:	009a07b3          	add	a5,s4,s1
 782:	0007c903          	lbu	s2,0(a5)
 786:	22090a63          	beqz	s2,9ba <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 78a:	0009079b          	sext.w	a5,s2
    if(state == 0){
 78e:	fe0994e3          	bnez	s3,776 <vprintf+0x46>
      if(c0 == '%'){
 792:	fd579de3          	bne	a5,s5,76c <vprintf+0x3c>
        state = '%';
 796:	89be                	mv	s3,a5
 798:	b7cd                	j	77a <vprintf+0x4a>
      if(c0) c1 = fmt[i+1] & 0xff;
 79a:	00ea06b3          	add	a3,s4,a4
 79e:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 7a2:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 7a4:	c681                	beqz	a3,7ac <vprintf+0x7c>
 7a6:	9752                	add	a4,a4,s4
 7a8:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 7ac:	05878363          	beq	a5,s8,7f2 <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 7b0:	05978d63          	beq	a5,s9,80a <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 7b4:	07500713          	li	a4,117
 7b8:	0ee78763          	beq	a5,a4,8a6 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 7bc:	07800713          	li	a4,120
 7c0:	12e78963          	beq	a5,a4,8f2 <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 7c4:	07000713          	li	a4,112
 7c8:	14e78e63          	beq	a5,a4,924 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 7cc:	06300713          	li	a4,99
 7d0:	18e78e63          	beq	a5,a4,96c <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 7d4:	07300713          	li	a4,115
 7d8:	1ae78463          	beq	a5,a4,980 <vprintf+0x250>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 7dc:	02500713          	li	a4,37
 7e0:	04e79563          	bne	a5,a4,82a <vprintf+0xfa>
        putc(fd, '%');
 7e4:	02500593          	li	a1,37
 7e8:	855a                	mv	a0,s6
 7ea:	e8dff0ef          	jal	676 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 7ee:	4981                	li	s3,0
 7f0:	b769                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 7f2:	008b8913          	addi	s2,s7,8
 7f6:	4685                	li	a3,1
 7f8:	4629                	li	a2,10
 7fa:	000ba583          	lw	a1,0(s7)
 7fe:	855a                	mv	a0,s6
 800:	e95ff0ef          	jal	694 <printint>
 804:	8bca                	mv	s7,s2
      state = 0;
 806:	4981                	li	s3,0
 808:	bf8d                	j	77a <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'd'){
 80a:	06400793          	li	a5,100
 80e:	02f68963          	beq	a3,a5,840 <vprintf+0x110>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 812:	06c00793          	li	a5,108
 816:	04f68263          	beq	a3,a5,85a <vprintf+0x12a>
      } else if(c0 == 'l' && c1 == 'u'){
 81a:	07500793          	li	a5,117
 81e:	0af68063          	beq	a3,a5,8be <vprintf+0x18e>
      } else if(c0 == 'l' && c1 == 'x'){
 822:	07800793          	li	a5,120
 826:	0ef68263          	beq	a3,a5,90a <vprintf+0x1da>
        putc(fd, '%');
 82a:	02500593          	li	a1,37
 82e:	855a                	mv	a0,s6
 830:	e47ff0ef          	jal	676 <putc>
        putc(fd, c0);
 834:	85ca                	mv	a1,s2
 836:	855a                	mv	a0,s6
 838:	e3fff0ef          	jal	676 <putc>
      state = 0;
 83c:	4981                	li	s3,0
 83e:	bf35                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 840:	008b8913          	addi	s2,s7,8
 844:	4685                	li	a3,1
 846:	4629                	li	a2,10
 848:	000bb583          	ld	a1,0(s7)
 84c:	855a                	mv	a0,s6
 84e:	e47ff0ef          	jal	694 <printint>
        i += 1;
 852:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 854:	8bca                	mv	s7,s2
      state = 0;
 856:	4981                	li	s3,0
        i += 1;
 858:	b70d                	j	77a <vprintf+0x4a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 85a:	06400793          	li	a5,100
 85e:	02f60763          	beq	a2,a5,88c <vprintf+0x15c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 862:	07500793          	li	a5,117
 866:	06f60963          	beq	a2,a5,8d8 <vprintf+0x1a8>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 86a:	07800793          	li	a5,120
 86e:	faf61ee3          	bne	a2,a5,82a <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 872:	008b8913          	addi	s2,s7,8
 876:	4681                	li	a3,0
 878:	4641                	li	a2,16
 87a:	000bb583          	ld	a1,0(s7)
 87e:	855a                	mv	a0,s6
 880:	e15ff0ef          	jal	694 <printint>
        i += 2;
 884:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 886:	8bca                	mv	s7,s2
      state = 0;
 888:	4981                	li	s3,0
        i += 2;
 88a:	bdc5                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 88c:	008b8913          	addi	s2,s7,8
 890:	4685                	li	a3,1
 892:	4629                	li	a2,10
 894:	000bb583          	ld	a1,0(s7)
 898:	855a                	mv	a0,s6
 89a:	dfbff0ef          	jal	694 <printint>
        i += 2;
 89e:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 8a0:	8bca                	mv	s7,s2
      state = 0;
 8a2:	4981                	li	s3,0
        i += 2;
 8a4:	bdd9                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 8a6:	008b8913          	addi	s2,s7,8
 8aa:	4681                	li	a3,0
 8ac:	4629                	li	a2,10
 8ae:	000be583          	lwu	a1,0(s7)
 8b2:	855a                	mv	a0,s6
 8b4:	de1ff0ef          	jal	694 <printint>
 8b8:	8bca                	mv	s7,s2
      state = 0;
 8ba:	4981                	li	s3,0
 8bc:	bd7d                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 8be:	008b8913          	addi	s2,s7,8
 8c2:	4681                	li	a3,0
 8c4:	4629                	li	a2,10
 8c6:	000bb583          	ld	a1,0(s7)
 8ca:	855a                	mv	a0,s6
 8cc:	dc9ff0ef          	jal	694 <printint>
        i += 1;
 8d0:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 8d2:	8bca                	mv	s7,s2
      state = 0;
 8d4:	4981                	li	s3,0
        i += 1;
 8d6:	b555                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 8d8:	008b8913          	addi	s2,s7,8
 8dc:	4681                	li	a3,0
 8de:	4629                	li	a2,10
 8e0:	000bb583          	ld	a1,0(s7)
 8e4:	855a                	mv	a0,s6
 8e6:	dafff0ef          	jal	694 <printint>
        i += 2;
 8ea:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 8ec:	8bca                	mv	s7,s2
      state = 0;
 8ee:	4981                	li	s3,0
        i += 2;
 8f0:	b569                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 8f2:	008b8913          	addi	s2,s7,8
 8f6:	4681                	li	a3,0
 8f8:	4641                	li	a2,16
 8fa:	000be583          	lwu	a1,0(s7)
 8fe:	855a                	mv	a0,s6
 900:	d95ff0ef          	jal	694 <printint>
 904:	8bca                	mv	s7,s2
      state = 0;
 906:	4981                	li	s3,0
 908:	bd8d                	j	77a <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 90a:	008b8913          	addi	s2,s7,8
 90e:	4681                	li	a3,0
 910:	4641                	li	a2,16
 912:	000bb583          	ld	a1,0(s7)
 916:	855a                	mv	a0,s6
 918:	d7dff0ef          	jal	694 <printint>
        i += 1;
 91c:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 91e:	8bca                	mv	s7,s2
      state = 0;
 920:	4981                	li	s3,0
        i += 1;
 922:	bda1                	j	77a <vprintf+0x4a>
 924:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 926:	008b8d13          	addi	s10,s7,8
 92a:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 92e:	03000593          	li	a1,48
 932:	855a                	mv	a0,s6
 934:	d43ff0ef          	jal	676 <putc>
  putc(fd, 'x');
 938:	07800593          	li	a1,120
 93c:	855a                	mv	a0,s6
 93e:	d39ff0ef          	jal	676 <putc>
 942:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 944:	00000b97          	auipc	s7,0x0
 948:	5ccb8b93          	addi	s7,s7,1484 # f10 <digits>
 94c:	03c9d793          	srli	a5,s3,0x3c
 950:	97de                	add	a5,a5,s7
 952:	0007c583          	lbu	a1,0(a5)
 956:	855a                	mv	a0,s6
 958:	d1fff0ef          	jal	676 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 95c:	0992                	slli	s3,s3,0x4
 95e:	397d                	addiw	s2,s2,-1
 960:	fe0916e3          	bnez	s2,94c <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 964:	8bea                	mv	s7,s10
      state = 0;
 966:	4981                	li	s3,0
 968:	6d02                	ld	s10,0(sp)
 96a:	bd01                	j	77a <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 96c:	008b8913          	addi	s2,s7,8
 970:	000bc583          	lbu	a1,0(s7)
 974:	855a                	mv	a0,s6
 976:	d01ff0ef          	jal	676 <putc>
 97a:	8bca                	mv	s7,s2
      state = 0;
 97c:	4981                	li	s3,0
 97e:	bbf5                	j	77a <vprintf+0x4a>
        if((s = va_arg(ap, char*)) == 0)
 980:	008b8993          	addi	s3,s7,8
 984:	000bb903          	ld	s2,0(s7)
 988:	00090f63          	beqz	s2,9a6 <vprintf+0x276>
        for(; *s; s++)
 98c:	00094583          	lbu	a1,0(s2)
 990:	c195                	beqz	a1,9b4 <vprintf+0x284>
          putc(fd, *s);
 992:	855a                	mv	a0,s6
 994:	ce3ff0ef          	jal	676 <putc>
        for(; *s; s++)
 998:	0905                	addi	s2,s2,1
 99a:	00094583          	lbu	a1,0(s2)
 99e:	f9f5                	bnez	a1,992 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 9a0:	8bce                	mv	s7,s3
      state = 0;
 9a2:	4981                	li	s3,0
 9a4:	bbd9                	j	77a <vprintf+0x4a>
          s = "(null)";
 9a6:	00000917          	auipc	s2,0x0
 9aa:	56290913          	addi	s2,s2,1378 # f08 <malloc+0x456>
        for(; *s; s++)
 9ae:	02800593          	li	a1,40
 9b2:	b7c5                	j	992 <vprintf+0x262>
        if((s = va_arg(ap, char*)) == 0)
 9b4:	8bce                	mv	s7,s3
      state = 0;
 9b6:	4981                	li	s3,0
 9b8:	b3c9                	j	77a <vprintf+0x4a>
 9ba:	64a6                	ld	s1,72(sp)
 9bc:	79e2                	ld	s3,56(sp)
 9be:	7a42                	ld	s4,48(sp)
 9c0:	7aa2                	ld	s5,40(sp)
 9c2:	7b02                	ld	s6,32(sp)
 9c4:	6be2                	ld	s7,24(sp)
 9c6:	6c42                	ld	s8,16(sp)
 9c8:	6ca2                	ld	s9,8(sp)
    }
  }
}
 9ca:	60e6                	ld	ra,88(sp)
 9cc:	6446                	ld	s0,80(sp)
 9ce:	6906                	ld	s2,64(sp)
 9d0:	6125                	addi	sp,sp,96
 9d2:	8082                	ret

00000000000009d4 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 9d4:	715d                	addi	sp,sp,-80
 9d6:	ec06                	sd	ra,24(sp)
 9d8:	e822                	sd	s0,16(sp)
 9da:	1000                	addi	s0,sp,32
 9dc:	e010                	sd	a2,0(s0)
 9de:	e414                	sd	a3,8(s0)
 9e0:	e818                	sd	a4,16(s0)
 9e2:	ec1c                	sd	a5,24(s0)
 9e4:	03043023          	sd	a6,32(s0)
 9e8:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 9ec:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 9f0:	8622                	mv	a2,s0
 9f2:	d3fff0ef          	jal	730 <vprintf>
}
 9f6:	60e2                	ld	ra,24(sp)
 9f8:	6442                	ld	s0,16(sp)
 9fa:	6161                	addi	sp,sp,80
 9fc:	8082                	ret

00000000000009fe <printf>:

void
printf(const char *fmt, ...)
{
 9fe:	711d                	addi	sp,sp,-96
 a00:	ec06                	sd	ra,24(sp)
 a02:	e822                	sd	s0,16(sp)
 a04:	1000                	addi	s0,sp,32
 a06:	e40c                	sd	a1,8(s0)
 a08:	e810                	sd	a2,16(s0)
 a0a:	ec14                	sd	a3,24(s0)
 a0c:	f018                	sd	a4,32(s0)
 a0e:	f41c                	sd	a5,40(s0)
 a10:	03043823          	sd	a6,48(s0)
 a14:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 a18:	00840613          	addi	a2,s0,8
 a1c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a20:	85aa                	mv	a1,a0
 a22:	4505                	li	a0,1
 a24:	d0dff0ef          	jal	730 <vprintf>
}
 a28:	60e2                	ld	ra,24(sp)
 a2a:	6442                	ld	s0,16(sp)
 a2c:	6125                	addi	sp,sp,96
 a2e:	8082                	ret

0000000000000a30 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a30:	1141                	addi	sp,sp,-16
 a32:	e422                	sd	s0,8(sp)
 a34:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a36:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a3a:	00001797          	auipc	a5,0x1
 a3e:	5c67b783          	ld	a5,1478(a5) # 2000 <freep>
 a42:	a02d                	j	a6c <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 a44:	4618                	lw	a4,8(a2)
 a46:	9f2d                	addw	a4,a4,a1
 a48:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a4c:	6398                	ld	a4,0(a5)
 a4e:	6310                	ld	a2,0(a4)
 a50:	a83d                	j	a8e <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 a52:	ff852703          	lw	a4,-8(a0)
 a56:	9f31                	addw	a4,a4,a2
 a58:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a5a:	ff053683          	ld	a3,-16(a0)
 a5e:	a091                	j	aa2 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a60:	6398                	ld	a4,0(a5)
 a62:	00e7e463          	bltu	a5,a4,a6a <free+0x3a>
 a66:	00e6ea63          	bltu	a3,a4,a7a <free+0x4a>
{
 a6a:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a6c:	fed7fae3          	bgeu	a5,a3,a60 <free+0x30>
 a70:	6398                	ld	a4,0(a5)
 a72:	00e6e463          	bltu	a3,a4,a7a <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a76:	fee7eae3          	bltu	a5,a4,a6a <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 a7a:	ff852583          	lw	a1,-8(a0)
 a7e:	6390                	ld	a2,0(a5)
 a80:	02059813          	slli	a6,a1,0x20
 a84:	01c85713          	srli	a4,a6,0x1c
 a88:	9736                	add	a4,a4,a3
 a8a:	fae60de3          	beq	a2,a4,a44 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 a8e:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 a92:	4790                	lw	a2,8(a5)
 a94:	02061593          	slli	a1,a2,0x20
 a98:	01c5d713          	srli	a4,a1,0x1c
 a9c:	973e                	add	a4,a4,a5
 a9e:	fae68ae3          	beq	a3,a4,a52 <free+0x22>
    p->s.ptr = bp->s.ptr;
 aa2:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 aa4:	00001717          	auipc	a4,0x1
 aa8:	54f73e23          	sd	a5,1372(a4) # 2000 <freep>
}
 aac:	6422                	ld	s0,8(sp)
 aae:	0141                	addi	sp,sp,16
 ab0:	8082                	ret

0000000000000ab2 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 ab2:	7139                	addi	sp,sp,-64
 ab4:	fc06                	sd	ra,56(sp)
 ab6:	f822                	sd	s0,48(sp)
 ab8:	f426                	sd	s1,40(sp)
 aba:	ec4e                	sd	s3,24(sp)
 abc:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 abe:	02051493          	slli	s1,a0,0x20
 ac2:	9081                	srli	s1,s1,0x20
 ac4:	04bd                	addi	s1,s1,15
 ac6:	8091                	srli	s1,s1,0x4
 ac8:	0014899b          	addiw	s3,s1,1
 acc:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 ace:	00001517          	auipc	a0,0x1
 ad2:	53253503          	ld	a0,1330(a0) # 2000 <freep>
 ad6:	c915                	beqz	a0,b0a <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ad8:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 ada:	4798                	lw	a4,8(a5)
 adc:	08977a63          	bgeu	a4,s1,b70 <malloc+0xbe>
 ae0:	f04a                	sd	s2,32(sp)
 ae2:	e852                	sd	s4,16(sp)
 ae4:	e456                	sd	s5,8(sp)
 ae6:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 ae8:	8a4e                	mv	s4,s3
 aea:	0009871b          	sext.w	a4,s3
 aee:	6685                	lui	a3,0x1
 af0:	00d77363          	bgeu	a4,a3,af6 <malloc+0x44>
 af4:	6a05                	lui	s4,0x1
 af6:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 afa:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 afe:	00001917          	auipc	s2,0x1
 b02:	50290913          	addi	s2,s2,1282 # 2000 <freep>
  if(p == SBRK_ERROR)
 b06:	5afd                	li	s5,-1
 b08:	a081                	j	b48 <malloc+0x96>
 b0a:	f04a                	sd	s2,32(sp)
 b0c:	e852                	sd	s4,16(sp)
 b0e:	e456                	sd	s5,8(sp)
 b10:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 b12:	00001797          	auipc	a5,0x1
 b16:	4fe78793          	addi	a5,a5,1278 # 2010 <base>
 b1a:	00001717          	auipc	a4,0x1
 b1e:	4ef73323          	sd	a5,1254(a4) # 2000 <freep>
 b22:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b24:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b28:	b7c1                	j	ae8 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 b2a:	6398                	ld	a4,0(a5)
 b2c:	e118                	sd	a4,0(a0)
 b2e:	a8a9                	j	b88 <malloc+0xd6>
  hp->s.size = nu;
 b30:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 b34:	0541                	addi	a0,a0,16
 b36:	efbff0ef          	jal	a30 <free>
  return freep;
 b3a:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 b3e:	c12d                	beqz	a0,ba0 <malloc+0xee>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b40:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b42:	4798                	lw	a4,8(a5)
 b44:	02977263          	bgeu	a4,s1,b68 <malloc+0xb6>
    if(p == freep)
 b48:	00093703          	ld	a4,0(s2)
 b4c:	853e                	mv	a0,a5
 b4e:	fef719e3          	bne	a4,a5,b40 <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 b52:	8552                	mv	a0,s4
 b54:	a47ff0ef          	jal	59a <sbrk>
  if(p == SBRK_ERROR)
 b58:	fd551ce3          	bne	a0,s5,b30 <malloc+0x7e>
        return 0;
 b5c:	4501                	li	a0,0
 b5e:	7902                	ld	s2,32(sp)
 b60:	6a42                	ld	s4,16(sp)
 b62:	6aa2                	ld	s5,8(sp)
 b64:	6b02                	ld	s6,0(sp)
 b66:	a03d                	j	b94 <malloc+0xe2>
 b68:	7902                	ld	s2,32(sp)
 b6a:	6a42                	ld	s4,16(sp)
 b6c:	6aa2                	ld	s5,8(sp)
 b6e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 b70:	fae48de3          	beq	s1,a4,b2a <malloc+0x78>
        p->s.size -= nunits;
 b74:	4137073b          	subw	a4,a4,s3
 b78:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b7a:	02071693          	slli	a3,a4,0x20
 b7e:	01c6d713          	srli	a4,a3,0x1c
 b82:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 b84:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 b88:	00001717          	auipc	a4,0x1
 b8c:	46a73c23          	sd	a0,1144(a4) # 2000 <freep>
      return (void*)(p + 1);
 b90:	01078513          	addi	a0,a5,16
  }
}
 b94:	70e2                	ld	ra,56(sp)
 b96:	7442                	ld	s0,48(sp)
 b98:	74a2                	ld	s1,40(sp)
 b9a:	69e2                	ld	s3,24(sp)
 b9c:	6121                	addi	sp,sp,64
 b9e:	8082                	ret
 ba0:	7902                	ld	s2,32(sp)
 ba2:	6a42                	ld	s4,16(sp)
 ba4:	6aa2                	ld	s5,8(sp)
 ba6:	6b02                	ld	s6,0(sp)
 ba8:	b7f5                	j	b94 <malloc+0xe2>
