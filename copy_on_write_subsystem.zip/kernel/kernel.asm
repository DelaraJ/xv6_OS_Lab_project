
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	40813103          	ld	sp,1032(sp) # 8000a408 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04a000ef          	jal	80000060 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	stimecmp,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffbb08f>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	ffa78793          	addi	a5,a5,-6 # 8000107a <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a2:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	7119                	addi	sp,sp,-128
    800000d2:	fc86                	sd	ra,120(sp)
    800000d4:	f8a2                	sd	s0,112(sp)
    800000d6:	f4a6                	sd	s1,104(sp)
    800000d8:	0100                	addi	s0,sp,128
  char buf[32];
  int i = 0;

  while(i < n){
    800000da:	06c05a63          	blez	a2,8000014e <consolewrite+0x7e>
    800000de:	f0ca                	sd	s2,96(sp)
    800000e0:	ecce                	sd	s3,88(sp)
    800000e2:	e8d2                	sd	s4,80(sp)
    800000e4:	e4d6                	sd	s5,72(sp)
    800000e6:	e0da                	sd	s6,64(sp)
    800000e8:	fc5e                	sd	s7,56(sp)
    800000ea:	f862                	sd	s8,48(sp)
    800000ec:	f466                	sd	s9,40(sp)
    800000ee:	8aaa                	mv	s5,a0
    800000f0:	8b2e                	mv	s6,a1
    800000f2:	8a32                	mv	s4,a2
  int i = 0;
    800000f4:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000f6:	02000c13          	li	s8,32
    800000fa:	02000c93          	li	s9,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    800000fe:	5bfd                	li	s7,-1
    80000100:	a035                	j	8000012c <consolewrite+0x5c>
    if(nn > n - i)
    80000102:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000106:	86ce                	mv	a3,s3
    80000108:	01648633          	add	a2,s1,s6
    8000010c:	85d6                	mv	a1,s5
    8000010e:	f8040513          	addi	a0,s0,-128
    80000112:	454020ef          	jal	80002566 <either_copyin>
    80000116:	03750e63          	beq	a0,s7,80000152 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011a:	85ce                	mv	a1,s3
    8000011c:	f8040513          	addi	a0,s0,-128
    80000120:	778000ef          	jal	80000898 <uartwrite>
    i += nn;
    80000124:	009904bb          	addw	s1,s2,s1
  while(i < n){
    80000128:	0144da63          	bge	s1,s4,8000013c <consolewrite+0x6c>
    if(nn > n - i)
    8000012c:	409a093b          	subw	s2,s4,s1
    80000130:	0009079b          	sext.w	a5,s2
    80000134:	fcfc57e3          	bge	s8,a5,80000102 <consolewrite+0x32>
    80000138:	8966                	mv	s2,s9
    8000013a:	b7e1                	j	80000102 <consolewrite+0x32>
    8000013c:	7906                	ld	s2,96(sp)
    8000013e:	69e6                	ld	s3,88(sp)
    80000140:	6a46                	ld	s4,80(sp)
    80000142:	6aa6                	ld	s5,72(sp)
    80000144:	6b06                	ld	s6,64(sp)
    80000146:	7be2                	ld	s7,56(sp)
    80000148:	7c42                	ld	s8,48(sp)
    8000014a:	7ca2                	ld	s9,40(sp)
    8000014c:	a819                	j	80000162 <consolewrite+0x92>
  int i = 0;
    8000014e:	4481                	li	s1,0
    80000150:	a809                	j	80000162 <consolewrite+0x92>
    80000152:	7906                	ld	s2,96(sp)
    80000154:	69e6                	ld	s3,88(sp)
    80000156:	6a46                	ld	s4,80(sp)
    80000158:	6aa6                	ld	s5,72(sp)
    8000015a:	6b06                	ld	s6,64(sp)
    8000015c:	7be2                	ld	s7,56(sp)
    8000015e:	7c42                	ld	s8,48(sp)
    80000160:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000162:	8526                	mv	a0,s1
    80000164:	70e6                	ld	ra,120(sp)
    80000166:	7446                	ld	s0,112(sp)
    80000168:	74a6                	ld	s1,104(sp)
    8000016a:	6109                	addi	sp,sp,128
    8000016c:	8082                	ret

000000008000016e <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000016e:	711d                	addi	sp,sp,-96
    80000170:	ec86                	sd	ra,88(sp)
    80000172:	e8a2                	sd	s0,80(sp)
    80000174:	e4a6                	sd	s1,72(sp)
    80000176:	e0ca                	sd	s2,64(sp)
    80000178:	fc4e                	sd	s3,56(sp)
    8000017a:	f852                	sd	s4,48(sp)
    8000017c:	f456                	sd	s5,40(sp)
    8000017e:	f05a                	sd	s6,32(sp)
    80000180:	1080                	addi	s0,sp,96
    80000182:	8aaa                	mv	s5,a0
    80000184:	8a2e                	mv	s4,a1
    80000186:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000188:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018c:	00012517          	auipc	a0,0x12
    80000190:	2c450513          	addi	a0,a0,708 # 80012450 <cons>
    80000194:	479000ef          	jal	80000e0c <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000198:	00012497          	auipc	s1,0x12
    8000019c:	2b848493          	addi	s1,s1,696 # 80012450 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a0:	00012917          	auipc	s2,0x12
    800001a4:	34890913          	addi	s2,s2,840 # 800124e8 <cons+0x98>
  while(n > 0){
    800001a8:	0b305d63          	blez	s3,80000262 <consoleread+0xf4>
    while(cons.r == cons.w){
    800001ac:	0984a783          	lw	a5,152(s1)
    800001b0:	09c4a703          	lw	a4,156(s1)
    800001b4:	0af71263          	bne	a4,a5,80000258 <consoleread+0xea>
      if(killed(myproc())){
    800001b8:	211010ef          	jal	80001bc8 <myproc>
    800001bc:	23c020ef          	jal	800023f8 <killed>
    800001c0:	e12d                	bnez	a0,80000222 <consoleread+0xb4>
      sleep(&cons.r, &cons.lock);
    800001c2:	85a6                	mv	a1,s1
    800001c4:	854a                	mv	a0,s2
    800001c6:	7fb010ef          	jal	800021c0 <sleep>
    while(cons.r == cons.w){
    800001ca:	0984a783          	lw	a5,152(s1)
    800001ce:	09c4a703          	lw	a4,156(s1)
    800001d2:	fef703e3          	beq	a4,a5,800001b8 <consoleread+0x4a>
    800001d6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001d8:	00012717          	auipc	a4,0x12
    800001dc:	27870713          	addi	a4,a4,632 # 80012450 <cons>
    800001e0:	0017869b          	addiw	a3,a5,1
    800001e4:	08d72c23          	sw	a3,152(a4)
    800001e8:	07f7f693          	andi	a3,a5,127
    800001ec:	9736                	add	a4,a4,a3
    800001ee:	01874703          	lbu	a4,24(a4)
    800001f2:	00070b9b          	sext.w	s7,a4

    if(c == C('D')){  // end-of-file
    800001f6:	4691                	li	a3,4
    800001f8:	04db8663          	beq	s7,a3,80000244 <consoleread+0xd6>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001fc:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000200:	4685                	li	a3,1
    80000202:	faf40613          	addi	a2,s0,-81
    80000206:	85d2                	mv	a1,s4
    80000208:	8556                	mv	a0,s5
    8000020a:	312020ef          	jal	8000251c <either_copyout>
    8000020e:	57fd                	li	a5,-1
    80000210:	04f50863          	beq	a0,a5,80000260 <consoleread+0xf2>
      break;

    dst++;
    80000214:	0a05                	addi	s4,s4,1
    --n;
    80000216:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80000218:	47a9                	li	a5,10
    8000021a:	04fb8d63          	beq	s7,a5,80000274 <consoleread+0x106>
    8000021e:	6be2                	ld	s7,24(sp)
    80000220:	b761                	j	800001a8 <consoleread+0x3a>
        release(&cons.lock);
    80000222:	00012517          	auipc	a0,0x12
    80000226:	22e50513          	addi	a0,a0,558 # 80012450 <cons>
    8000022a:	47b000ef          	jal	80000ea4 <release>
        return -1;
    8000022e:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000230:	60e6                	ld	ra,88(sp)
    80000232:	6446                	ld	s0,80(sp)
    80000234:	64a6                	ld	s1,72(sp)
    80000236:	6906                	ld	s2,64(sp)
    80000238:	79e2                	ld	s3,56(sp)
    8000023a:	7a42                	ld	s4,48(sp)
    8000023c:	7aa2                	ld	s5,40(sp)
    8000023e:	7b02                	ld	s6,32(sp)
    80000240:	6125                	addi	sp,sp,96
    80000242:	8082                	ret
      if(n < target){
    80000244:	0009871b          	sext.w	a4,s3
    80000248:	01677a63          	bgeu	a4,s6,8000025c <consoleread+0xee>
        cons.r--;
    8000024c:	00012717          	auipc	a4,0x12
    80000250:	28f72e23          	sw	a5,668(a4) # 800124e8 <cons+0x98>
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	a031                	j	80000262 <consoleread+0xf4>
    80000258:	ec5e                	sd	s7,24(sp)
    8000025a:	bfbd                	j	800001d8 <consoleread+0x6a>
    8000025c:	6be2                	ld	s7,24(sp)
    8000025e:	a011                	j	80000262 <consoleread+0xf4>
    80000260:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000262:	00012517          	auipc	a0,0x12
    80000266:	1ee50513          	addi	a0,a0,494 # 80012450 <cons>
    8000026a:	43b000ef          	jal	80000ea4 <release>
  return target - n;
    8000026e:	413b053b          	subw	a0,s6,s3
    80000272:	bf7d                	j	80000230 <consoleread+0xc2>
    80000274:	6be2                	ld	s7,24(sp)
    80000276:	b7f5                	j	80000262 <consoleread+0xf4>

0000000080000278 <consputc>:
{
    80000278:	1141                	addi	sp,sp,-16
    8000027a:	e406                	sd	ra,8(sp)
    8000027c:	e022                	sd	s0,0(sp)
    8000027e:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000280:	10000793          	li	a5,256
    80000284:	00f50863          	beq	a0,a5,80000294 <consputc+0x1c>
    uartputc_sync(c);
    80000288:	6a4000ef          	jal	8000092c <uartputc_sync>
}
    8000028c:	60a2                	ld	ra,8(sp)
    8000028e:	6402                	ld	s0,0(sp)
    80000290:	0141                	addi	sp,sp,16
    80000292:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000294:	4521                	li	a0,8
    80000296:	696000ef          	jal	8000092c <uartputc_sync>
    8000029a:	02000513          	li	a0,32
    8000029e:	68e000ef          	jal	8000092c <uartputc_sync>
    800002a2:	4521                	li	a0,8
    800002a4:	688000ef          	jal	8000092c <uartputc_sync>
    800002a8:	b7d5                	j	8000028c <consputc+0x14>

00000000800002aa <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002aa:	1101                	addi	sp,sp,-32
    800002ac:	ec06                	sd	ra,24(sp)
    800002ae:	e822                	sd	s0,16(sp)
    800002b0:	e426                	sd	s1,8(sp)
    800002b2:	1000                	addi	s0,sp,32
    800002b4:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b6:	00012517          	auipc	a0,0x12
    800002ba:	19a50513          	addi	a0,a0,410 # 80012450 <cons>
    800002be:	34f000ef          	jal	80000e0c <acquire>

  switch(c){
    800002c2:	47d5                	li	a5,21
    800002c4:	08f48f63          	beq	s1,a5,80000362 <consoleintr+0xb8>
    800002c8:	0297c563          	blt	a5,s1,800002f2 <consoleintr+0x48>
    800002cc:	47a1                	li	a5,8
    800002ce:	0ef48463          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    800002d2:	47c1                	li	a5,16
    800002d4:	10f49563          	bne	s1,a5,800003de <consoleintr+0x134>
  case C('P'):  // Print process list.
    procdump();
    800002d8:	2d8020ef          	jal	800025b0 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002dc:	00012517          	auipc	a0,0x12
    800002e0:	17450513          	addi	a0,a0,372 # 80012450 <cons>
    800002e4:	3c1000ef          	jal	80000ea4 <release>
}
    800002e8:	60e2                	ld	ra,24(sp)
    800002ea:	6442                	ld	s0,16(sp)
    800002ec:	64a2                	ld	s1,8(sp)
    800002ee:	6105                	addi	sp,sp,32
    800002f0:	8082                	ret
  switch(c){
    800002f2:	07f00793          	li	a5,127
    800002f6:	0cf48063          	beq	s1,a5,800003b6 <consoleintr+0x10c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fa:	00012717          	auipc	a4,0x12
    800002fe:	15670713          	addi	a4,a4,342 # 80012450 <cons>
    80000302:	0a072783          	lw	a5,160(a4)
    80000306:	09872703          	lw	a4,152(a4)
    8000030a:	9f99                	subw	a5,a5,a4
    8000030c:	07f00713          	li	a4,127
    80000310:	fcf766e3          	bltu	a4,a5,800002dc <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000314:	47b5                	li	a5,13
    80000316:	0cf48763          	beq	s1,a5,800003e4 <consoleintr+0x13a>
      consputc(c);
    8000031a:	8526                	mv	a0,s1
    8000031c:	f5dff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000320:	00012797          	auipc	a5,0x12
    80000324:	13078793          	addi	a5,a5,304 # 80012450 <cons>
    80000328:	0a07a683          	lw	a3,160(a5)
    8000032c:	0016871b          	addiw	a4,a3,1
    80000330:	0007061b          	sext.w	a2,a4
    80000334:	0ae7a023          	sw	a4,160(a5)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	97b6                	add	a5,a5,a3
    8000033e:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	47a9                	li	a5,10
    80000344:	0cf48563          	beq	s1,a5,8000040e <consoleintr+0x164>
    80000348:	4791                	li	a5,4
    8000034a:	0cf48263          	beq	s1,a5,8000040e <consoleintr+0x164>
    8000034e:	00012797          	auipc	a5,0x12
    80000352:	19a7a783          	lw	a5,410(a5) # 800124e8 <cons+0x98>
    80000356:	9f1d                	subw	a4,a4,a5
    80000358:	08000793          	li	a5,128
    8000035c:	f8f710e3          	bne	a4,a5,800002dc <consoleintr+0x32>
    80000360:	a07d                	j	8000040e <consoleintr+0x164>
    80000362:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000364:	00012717          	auipc	a4,0x12
    80000368:	0ec70713          	addi	a4,a4,236 # 80012450 <cons>
    8000036c:	0a072783          	lw	a5,160(a4)
    80000370:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000374:	00012497          	auipc	s1,0x12
    80000378:	0dc48493          	addi	s1,s1,220 # 80012450 <cons>
    while(cons.e != cons.w &&
    8000037c:	4929                	li	s2,10
    8000037e:	02f70863          	beq	a4,a5,800003ae <consoleintr+0x104>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000382:	37fd                	addiw	a5,a5,-1
    80000384:	07f7f713          	andi	a4,a5,127
    80000388:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000038a:	01874703          	lbu	a4,24(a4)
    8000038e:	03270263          	beq	a4,s2,800003b2 <consoleintr+0x108>
      cons.e--;
    80000392:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000396:	10000513          	li	a0,256
    8000039a:	edfff0ef          	jal	80000278 <consputc>
    while(cons.e != cons.w &&
    8000039e:	0a04a783          	lw	a5,160(s1)
    800003a2:	09c4a703          	lw	a4,156(s1)
    800003a6:	fcf71ee3          	bne	a4,a5,80000382 <consoleintr+0xd8>
    800003aa:	6902                	ld	s2,0(sp)
    800003ac:	bf05                	j	800002dc <consoleintr+0x32>
    800003ae:	6902                	ld	s2,0(sp)
    800003b0:	b735                	j	800002dc <consoleintr+0x32>
    800003b2:	6902                	ld	s2,0(sp)
    800003b4:	b725                	j	800002dc <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b6:	00012717          	auipc	a4,0x12
    800003ba:	09a70713          	addi	a4,a4,154 # 80012450 <cons>
    800003be:	0a072783          	lw	a5,160(a4)
    800003c2:	09c72703          	lw	a4,156(a4)
    800003c6:	f0f70be3          	beq	a4,a5,800002dc <consoleintr+0x32>
      cons.e--;
    800003ca:	37fd                	addiw	a5,a5,-1
    800003cc:	00012717          	auipc	a4,0x12
    800003d0:	12f72223          	sw	a5,292(a4) # 800124f0 <cons+0xa0>
      consputc(BACKSPACE);
    800003d4:	10000513          	li	a0,256
    800003d8:	ea1ff0ef          	jal	80000278 <consputc>
    800003dc:	b701                	j	800002dc <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003de:	ee048fe3          	beqz	s1,800002dc <consoleintr+0x32>
    800003e2:	bf21                	j	800002fa <consoleintr+0x50>
      consputc(c);
    800003e4:	4529                	li	a0,10
    800003e6:	e93ff0ef          	jal	80000278 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003ea:	00012797          	auipc	a5,0x12
    800003ee:	06678793          	addi	a5,a5,102 # 80012450 <cons>
    800003f2:	0a07a703          	lw	a4,160(a5)
    800003f6:	0017069b          	addiw	a3,a4,1
    800003fa:	0006861b          	sext.w	a2,a3
    800003fe:	0ad7a023          	sw	a3,160(a5)
    80000402:	07f77713          	andi	a4,a4,127
    80000406:	97ba                	add	a5,a5,a4
    80000408:	4729                	li	a4,10
    8000040a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040e:	00012797          	auipc	a5,0x12
    80000412:	0cc7af23          	sw	a2,222(a5) # 800124ec <cons+0x9c>
        wakeup(&cons.r);
    80000416:	00012517          	auipc	a0,0x12
    8000041a:	0d250513          	addi	a0,a0,210 # 800124e8 <cons+0x98>
    8000041e:	5ef010ef          	jal	8000220c <wakeup>
    80000422:	bd6d                	j	800002dc <consoleintr+0x32>

0000000080000424 <consoleinit>:

void
consoleinit(void)
{
    80000424:	1141                	addi	sp,sp,-16
    80000426:	e406                	sd	ra,8(sp)
    80000428:	e022                	sd	s0,0(sp)
    8000042a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000042c:	00007597          	auipc	a1,0x7
    80000430:	bd458593          	addi	a1,a1,-1068 # 80007000 <etext>
    80000434:	00012517          	auipc	a0,0x12
    80000438:	01c50513          	addi	a0,a0,28 # 80012450 <cons>
    8000043c:	151000ef          	jal	80000d8c <initlock>

  uartinit();
    80000440:	400000ef          	jal	80000840 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000444:	00042797          	auipc	a5,0x42
    80000448:	19478793          	addi	a5,a5,404 # 800425d8 <devsw>
    8000044c:	00000717          	auipc	a4,0x0
    80000450:	d2270713          	addi	a4,a4,-734 # 8000016e <consoleread>
    80000454:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000456:	00000717          	auipc	a4,0x0
    8000045a:	c7a70713          	addi	a4,a4,-902 # 800000d0 <consolewrite>
    8000045e:	ef98                	sd	a4,24(a5)
}
    80000460:	60a2                	ld	ra,8(sp)
    80000462:	6402                	ld	s0,0(sp)
    80000464:	0141                	addi	sp,sp,16
    80000466:	8082                	ret

0000000080000468 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000468:	7139                	addi	sp,sp,-64
    8000046a:	fc06                	sd	ra,56(sp)
    8000046c:	f822                	sd	s0,48(sp)
    8000046e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000470:	c219                	beqz	a2,80000476 <printint+0xe>
    80000472:	08054063          	bltz	a0,800004f2 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000476:	4881                	li	a7,0
    80000478:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000047c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007617          	auipc	a2,0x7
    80000482:	3f260613          	addi	a2,a2,1010 # 80007870 <digits>
    80000486:	883e                	mv	a6,a5
    80000488:	2785                	addiw	a5,a5,1
    8000048a:	02b57733          	remu	a4,a0,a1
    8000048e:	9732                	add	a4,a4,a2
    80000490:	00074703          	lbu	a4,0(a4)
    80000494:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000498:	872a                	mv	a4,a0
    8000049a:	02b55533          	divu	a0,a0,a1
    8000049e:	0685                	addi	a3,a3,1
    800004a0:	feb773e3          	bgeu	a4,a1,80000486 <printint+0x1e>

  if(sign)
    800004a4:	00088a63          	beqz	a7,800004b8 <printint+0x50>
    buf[i++] = '-';
    800004a8:	1781                	addi	a5,a5,-32
    800004aa:	97a2                	add	a5,a5,s0
    800004ac:	02d00713          	li	a4,45
    800004b0:	fee78423          	sb	a4,-24(a5)
    800004b4:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    800004b8:	02f05963          	blez	a5,800004ea <printint+0x82>
    800004bc:	f426                	sd	s1,40(sp)
    800004be:	f04a                	sd	s2,32(sp)
    800004c0:	fc840713          	addi	a4,s0,-56
    800004c4:	00f704b3          	add	s1,a4,a5
    800004c8:	fff70913          	addi	s2,a4,-1
    800004cc:	993e                	add	s2,s2,a5
    800004ce:	37fd                	addiw	a5,a5,-1
    800004d0:	1782                	slli	a5,a5,0x20
    800004d2:	9381                	srli	a5,a5,0x20
    800004d4:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004d8:	fff4c503          	lbu	a0,-1(s1)
    800004dc:	d9dff0ef          	jal	80000278 <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x70>
    800004e6:	74a2                	ld	s1,40(sp)
    800004e8:	7902                	ld	s2,32(sp)
}
    800004ea:	70e2                	ld	ra,56(sp)
    800004ec:	7442                	ld	s0,48(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4885                	li	a7,1
    x = -xx;
    800004f8:	b741                	j	80000478 <printint+0x10>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	e8d2                	sd	s4,80(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	8a2a                	mv	s4,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	0000a797          	auipc	a5,0xa
    8000051c:	f0c7a783          	lw	a5,-244(a5) # 8000a424 <panicking>
    80000520:	c3a1                	beqz	a5,80000560 <printf+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	000a4503          	lbu	a0,0(s4)
    8000052e:	28050763          	beqz	a0,800007bc <printf+0x2c2>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	f0ca                	sd	s2,96(sp)
    80000536:	ecce                	sd	s3,88(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	f862                	sd	s8,48(sp)
    8000053e:	f466                	sd	s9,40(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4981                	li	s3,0
    if(cx != '%'){
    80000546:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    8000054a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    8000054e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000552:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000556:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    8000055a:	07000d93          	li	s11,112
    8000055e:	a01d                	j	80000584 <printf+0x8a>
    acquire(&pr.lock);
    80000560:	00012517          	auipc	a0,0x12
    80000564:	f9850513          	addi	a0,a0,-104 # 800124f8 <pr>
    80000568:	0a5000ef          	jal	80000e0c <acquire>
    8000056c:	bf5d                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056e:	d0bff0ef          	jal	80000278 <consputc>
      continue;
    80000572:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000574:	0014899b          	addiw	s3,s1,1
    80000578:	013a07b3          	add	a5,s4,s3
    8000057c:	0007c503          	lbu	a0,0(a5)
    80000580:	20050b63          	beqz	a0,80000796 <printf+0x29c>
    if(cx != '%'){
    80000584:	ff5515e3          	bne	a0,s5,8000056e <printf+0x74>
    i++;
    80000588:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000058c:	009a07b3          	add	a5,s4,s1
    80000590:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000594:	20090b63          	beqz	s2,800007aa <printf+0x2b0>
    80000598:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000059c:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059e:	c789                	beqz	a5,800005a8 <printf+0xae>
    800005a0:	009a0733          	add	a4,s4,s1
    800005a4:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    800005a8:	03690963          	beq	s2,s6,800005da <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    800005ac:	05890363          	beq	s2,s8,800005f2 <printf+0xf8>
    } else if(c0 == 'u'){
    800005b0:	0d990663          	beq	s2,s9,8000067c <printf+0x182>
    } else if(c0 == 'x'){
    800005b4:	11a90d63          	beq	s2,s10,800006ce <printf+0x1d4>
    } else if(c0 == 'p'){
    800005b8:	15b90663          	beq	s2,s11,80000704 <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    800005bc:	06300793          	li	a5,99
    800005c0:	18f90563          	beq	s2,a5,8000074a <printf+0x250>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    800005c4:	07300793          	li	a5,115
    800005c8:	18f90b63          	beq	s2,a5,8000075e <printf+0x264>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    800005cc:	03591b63          	bne	s2,s5,80000602 <printf+0x108>
      consputc('%');
    800005d0:	02500513          	li	a0,37
    800005d4:	ca5ff0ef          	jal	80000278 <consputc>
    800005d8:	bf71                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005da:	f8843783          	ld	a5,-120(s0)
    800005de:	00878713          	addi	a4,a5,8
    800005e2:	f8e43423          	sd	a4,-120(s0)
    800005e6:	4605                	li	a2,1
    800005e8:	45a9                	li	a1,10
    800005ea:	4388                	lw	a0,0(a5)
    800005ec:	e7dff0ef          	jal	80000468 <printint>
    800005f0:	b751                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'd'){
    800005f2:	01678f63          	beq	a5,s6,80000610 <printf+0x116>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005f6:	03878b63          	beq	a5,s8,8000062c <printf+0x132>
    } else if(c0 == 'l' && c1 == 'u'){
    800005fa:	09978e63          	beq	a5,s9,80000696 <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'x'){
    800005fe:	0fa78563          	beq	a5,s10,800006e8 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000602:	8556                	mv	a0,s5
    80000604:	c75ff0ef          	jal	80000278 <consputc>
      consputc(c0);
    80000608:	854a                	mv	a0,s2
    8000060a:	c6fff0ef          	jal	80000278 <consputc>
    8000060e:	b79d                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000610:	f8843783          	ld	a5,-120(s0)
    80000614:	00878713          	addi	a4,a5,8
    80000618:	f8e43423          	sd	a4,-120(s0)
    8000061c:	4605                	li	a2,1
    8000061e:	45a9                	li	a1,10
    80000620:	6388                	ld	a0,0(a5)
    80000622:	e47ff0ef          	jal	80000468 <printint>
      i += 1;
    80000626:	0029849b          	addiw	s1,s3,2
    8000062a:	b7a9                	j	80000574 <printf+0x7a>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000062c:	06400793          	li	a5,100
    80000630:	02f68863          	beq	a3,a5,80000660 <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000634:	07500793          	li	a5,117
    80000638:	06f68d63          	beq	a3,a5,800006b2 <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    8000063c:	07800793          	li	a5,120
    80000640:	fcf691e3          	bne	a3,a5,80000602 <printf+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000644:	f8843783          	ld	a5,-120(s0)
    80000648:	00878713          	addi	a4,a5,8
    8000064c:	f8e43423          	sd	a4,-120(s0)
    80000650:	4601                	li	a2,0
    80000652:	45c1                	li	a1,16
    80000654:	6388                	ld	a0,0(a5)
    80000656:	e13ff0ef          	jal	80000468 <printint>
      i += 2;
    8000065a:	0039849b          	addiw	s1,s3,3
    8000065e:	bf19                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000660:	f8843783          	ld	a5,-120(s0)
    80000664:	00878713          	addi	a4,a5,8
    80000668:	f8e43423          	sd	a4,-120(s0)
    8000066c:	4605                	li	a2,1
    8000066e:	45a9                	li	a1,10
    80000670:	6388                	ld	a0,0(a5)
    80000672:	df7ff0ef          	jal	80000468 <printint>
      i += 2;
    80000676:	0039849b          	addiw	s1,s3,3
    8000067a:	bded                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000067c:	f8843783          	ld	a5,-120(s0)
    80000680:	00878713          	addi	a4,a5,8
    80000684:	f8e43423          	sd	a4,-120(s0)
    80000688:	4601                	li	a2,0
    8000068a:	45a9                	li	a1,10
    8000068c:	0007e503          	lwu	a0,0(a5)
    80000690:	dd9ff0ef          	jal	80000468 <printint>
    80000694:	b5c5                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    80000696:	f8843783          	ld	a5,-120(s0)
    8000069a:	00878713          	addi	a4,a5,8
    8000069e:	f8e43423          	sd	a4,-120(s0)
    800006a2:	4601                	li	a2,0
    800006a4:	45a9                	li	a1,10
    800006a6:	6388                	ld	a0,0(a5)
    800006a8:	dc1ff0ef          	jal	80000468 <printint>
      i += 1;
    800006ac:	0029849b          	addiw	s1,s3,2
    800006b0:	b5d1                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006b2:	f8843783          	ld	a5,-120(s0)
    800006b6:	00878713          	addi	a4,a5,8
    800006ba:	f8e43423          	sd	a4,-120(s0)
    800006be:	4601                	li	a2,0
    800006c0:	45a9                	li	a1,10
    800006c2:	6388                	ld	a0,0(a5)
    800006c4:	da5ff0ef          	jal	80000468 <printint>
      i += 2;
    800006c8:	0039849b          	addiw	s1,s3,3
    800006cc:	b565                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	4601                	li	a2,0
    800006dc:	45c1                	li	a1,16
    800006de:	0007e503          	lwu	a0,0(a5)
    800006e2:	d87ff0ef          	jal	80000468 <printint>
    800006e6:	b579                	j	80000574 <printf+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006e8:	f8843783          	ld	a5,-120(s0)
    800006ec:	00878713          	addi	a4,a5,8
    800006f0:	f8e43423          	sd	a4,-120(s0)
    800006f4:	4601                	li	a2,0
    800006f6:	45c1                	li	a1,16
    800006f8:	6388                	ld	a0,0(a5)
    800006fa:	d6fff0ef          	jal	80000468 <printint>
      i += 1;
    800006fe:	0029849b          	addiw	s1,s3,2
    80000702:	bd8d                	j	80000574 <printf+0x7a>
    80000704:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000706:	f8843783          	ld	a5,-120(s0)
    8000070a:	00878713          	addi	a4,a5,8
    8000070e:	f8e43423          	sd	a4,-120(s0)
    80000712:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000716:	03000513          	li	a0,48
    8000071a:	b5fff0ef          	jal	80000278 <consputc>
  consputc('x');
    8000071e:	07800513          	li	a0,120
    80000722:	b57ff0ef          	jal	80000278 <consputc>
    80000726:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000728:	00007b97          	auipc	s7,0x7
    8000072c:	148b8b93          	addi	s7,s7,328 # 80007870 <digits>
    80000730:	03c9d793          	srli	a5,s3,0x3c
    80000734:	97de                	add	a5,a5,s7
    80000736:	0007c503          	lbu	a0,0(a5)
    8000073a:	b3fff0ef          	jal	80000278 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000073e:	0992                	slli	s3,s3,0x4
    80000740:	397d                	addiw	s2,s2,-1
    80000742:	fe0917e3          	bnez	s2,80000730 <printf+0x236>
    80000746:	7be2                	ld	s7,56(sp)
    80000748:	b535                	j	80000574 <printf+0x7a>
      consputc(va_arg(ap, uint));
    8000074a:	f8843783          	ld	a5,-120(s0)
    8000074e:	00878713          	addi	a4,a5,8
    80000752:	f8e43423          	sd	a4,-120(s0)
    80000756:	4388                	lw	a0,0(a5)
    80000758:	b21ff0ef          	jal	80000278 <consputc>
    8000075c:	bd21                	j	80000574 <printf+0x7a>
      if((s = va_arg(ap, char*)) == 0)
    8000075e:	f8843783          	ld	a5,-120(s0)
    80000762:	00878713          	addi	a4,a5,8
    80000766:	f8e43423          	sd	a4,-120(s0)
    8000076a:	0007b903          	ld	s2,0(a5)
    8000076e:	00090d63          	beqz	s2,80000788 <printf+0x28e>
      for(; *s; s++)
    80000772:	00094503          	lbu	a0,0(s2)
    80000776:	de050fe3          	beqz	a0,80000574 <printf+0x7a>
        consputc(*s);
    8000077a:	affff0ef          	jal	80000278 <consputc>
      for(; *s; s++)
    8000077e:	0905                	addi	s2,s2,1
    80000780:	00094503          	lbu	a0,0(s2)
    80000784:	f97d                	bnez	a0,8000077a <printf+0x280>
    80000786:	b3fd                	j	80000574 <printf+0x7a>
        s = "(null)";
    80000788:	00007917          	auipc	s2,0x7
    8000078c:	88090913          	addi	s2,s2,-1920 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000790:	02800513          	li	a0,40
    80000794:	b7dd                	j	8000077a <printf+0x280>
    80000796:	74a6                	ld	s1,104(sp)
    80000798:	7906                	ld	s2,96(sp)
    8000079a:	69e6                	ld	s3,88(sp)
    8000079c:	6aa6                	ld	s5,72(sp)
    8000079e:	6b06                	ld	s6,64(sp)
    800007a0:	7c42                	ld	s8,48(sp)
    800007a2:	7ca2                	ld	s9,40(sp)
    800007a4:	7d02                	ld	s10,32(sp)
    800007a6:	6de2                	ld	s11,24(sp)
    800007a8:	a811                	j	800007bc <printf+0x2c2>
    800007aa:	74a6                	ld	s1,104(sp)
    800007ac:	7906                	ld	s2,96(sp)
    800007ae:	69e6                	ld	s3,88(sp)
    800007b0:	6aa6                	ld	s5,72(sp)
    800007b2:	6b06                	ld	s6,64(sp)
    800007b4:	7c42                	ld	s8,48(sp)
    800007b6:	7ca2                	ld	s9,40(sp)
    800007b8:	7d02                	ld	s10,32(sp)
    800007ba:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    800007bc:	0000a797          	auipc	a5,0xa
    800007c0:	c687a783          	lw	a5,-920(a5) # 8000a424 <panicking>
    800007c4:	c799                	beqz	a5,800007d2 <printf+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007c6:	4501                	li	a0,0
    800007c8:	70e6                	ld	ra,120(sp)
    800007ca:	7446                	ld	s0,112(sp)
    800007cc:	6a46                	ld	s4,80(sp)
    800007ce:	6129                	addi	sp,sp,192
    800007d0:	8082                	ret
    release(&pr.lock);
    800007d2:	00012517          	auipc	a0,0x12
    800007d6:	d2650513          	addi	a0,a0,-730 # 800124f8 <pr>
    800007da:	6ca000ef          	jal	80000ea4 <release>
  return 0;
    800007de:	b7e5                	j	800007c6 <printf+0x2cc>

00000000800007e0 <panic>:

void
panic(char *s)
{
    800007e0:	1101                	addi	sp,sp,-32
    800007e2:	ec06                	sd	ra,24(sp)
    800007e4:	e822                	sd	s0,16(sp)
    800007e6:	e426                	sd	s1,8(sp)
    800007e8:	e04a                	sd	s2,0(sp)
    800007ea:	1000                	addi	s0,sp,32
    800007ec:	84aa                	mv	s1,a0
  panicking = 1;
    800007ee:	4905                	li	s2,1
    800007f0:	0000a797          	auipc	a5,0xa
    800007f4:	c327aa23          	sw	s2,-972(a5) # 8000a424 <panicking>
  printf("panic: ");
    800007f8:	00007517          	auipc	a0,0x7
    800007fc:	82050513          	addi	a0,a0,-2016 # 80007018 <etext+0x18>
    80000800:	cfbff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000804:	85a6                	mv	a1,s1
    80000806:	00007517          	auipc	a0,0x7
    8000080a:	81a50513          	addi	a0,a0,-2022 # 80007020 <etext+0x20>
    8000080e:	cedff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000812:	0000a797          	auipc	a5,0xa
    80000816:	c127a723          	sw	s2,-1010(a5) # 8000a420 <panicked>
  for(;;)
    8000081a:	a001                	j	8000081a <panic+0x3a>

000000008000081c <printfinit>:
    ;
}

void
printfinit(void)
{
    8000081c:	1141                	addi	sp,sp,-16
    8000081e:	e406                	sd	ra,8(sp)
    80000820:	e022                	sd	s0,0(sp)
    80000822:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000824:	00007597          	auipc	a1,0x7
    80000828:	80458593          	addi	a1,a1,-2044 # 80007028 <etext+0x28>
    8000082c:	00012517          	auipc	a0,0x12
    80000830:	ccc50513          	addi	a0,a0,-820 # 800124f8 <pr>
    80000834:	558000ef          	jal	80000d8c <initlock>
}
    80000838:	60a2                	ld	ra,8(sp)
    8000083a:	6402                	ld	s0,0(sp)
    8000083c:	0141                	addi	sp,sp,16
    8000083e:	8082                	ret

0000000080000840 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000840:	1141                	addi	sp,sp,-16
    80000842:	e406                	sd	ra,8(sp)
    80000844:	e022                	sd	s0,0(sp)
    80000846:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000848:	100007b7          	lui	a5,0x10000
    8000084c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000850:	10000737          	lui	a4,0x10000
    80000854:	f8000693          	li	a3,-128
    80000858:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000085c:	468d                	li	a3,3
    8000085e:	10000637          	lui	a2,0x10000
    80000862:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000866:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000086a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000086e:	10000737          	lui	a4,0x10000
    80000872:	461d                	li	a2,7
    80000874:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000878:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    8000087c:	00006597          	auipc	a1,0x6
    80000880:	7b458593          	addi	a1,a1,1972 # 80007030 <etext+0x30>
    80000884:	00012517          	auipc	a0,0x12
    80000888:	c8c50513          	addi	a0,a0,-884 # 80012510 <tx_lock>
    8000088c:	500000ef          	jal	80000d8c <initlock>
}
    80000890:	60a2                	ld	ra,8(sp)
    80000892:	6402                	ld	s0,0(sp)
    80000894:	0141                	addi	sp,sp,16
    80000896:	8082                	ret

0000000080000898 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    80000898:	715d                	addi	sp,sp,-80
    8000089a:	e486                	sd	ra,72(sp)
    8000089c:	e0a2                	sd	s0,64(sp)
    8000089e:	fc26                	sd	s1,56(sp)
    800008a0:	ec56                	sd	s5,24(sp)
    800008a2:	0880                	addi	s0,sp,80
    800008a4:	8aaa                	mv	s5,a0
    800008a6:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008a8:	00012517          	auipc	a0,0x12
    800008ac:	c6850513          	addi	a0,a0,-920 # 80012510 <tx_lock>
    800008b0:	55c000ef          	jal	80000e0c <acquire>

  int i = 0;
  while(i < n){ 
    800008b4:	06905063          	blez	s1,80000914 <uartwrite+0x7c>
    800008b8:	f84a                	sd	s2,48(sp)
    800008ba:	f44e                	sd	s3,40(sp)
    800008bc:	f052                	sd	s4,32(sp)
    800008be:	e85a                	sd	s6,16(sp)
    800008c0:	e45e                	sd	s7,8(sp)
    800008c2:	8a56                	mv	s4,s5
    800008c4:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    800008c6:	0000a497          	auipc	s1,0xa
    800008ca:	b6648493          	addi	s1,s1,-1178 # 8000a42c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    800008ce:	00012997          	auipc	s3,0x12
    800008d2:	c4298993          	addi	s3,s3,-958 # 80012510 <tx_lock>
    800008d6:	0000a917          	auipc	s2,0xa
    800008da:	b5290913          	addi	s2,s2,-1198 # 8000a428 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    800008de:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    800008e2:	4b05                	li	s6,1
    800008e4:	a005                	j	80000904 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    800008e6:	85ce                	mv	a1,s3
    800008e8:	854a                	mv	a0,s2
    800008ea:	0d7010ef          	jal	800021c0 <sleep>
    while(tx_busy != 0){
    800008ee:	409c                	lw	a5,0(s1)
    800008f0:	fbfd                	bnez	a5,800008e6 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    800008f2:	000a4783          	lbu	a5,0(s4)
    800008f6:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    800008fa:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    800008fe:	0a05                	addi	s4,s4,1
    80000900:	015a0563          	beq	s4,s5,8000090a <uartwrite+0x72>
    while(tx_busy != 0){
    80000904:	409c                	lw	a5,0(s1)
    80000906:	f3e5                	bnez	a5,800008e6 <uartwrite+0x4e>
    80000908:	b7ed                	j	800008f2 <uartwrite+0x5a>
    8000090a:	7942                	ld	s2,48(sp)
    8000090c:	79a2                	ld	s3,40(sp)
    8000090e:	7a02                	ld	s4,32(sp)
    80000910:	6b42                	ld	s6,16(sp)
    80000912:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000914:	00012517          	auipc	a0,0x12
    80000918:	bfc50513          	addi	a0,a0,-1028 # 80012510 <tx_lock>
    8000091c:	588000ef          	jal	80000ea4 <release>
}
    80000920:	60a6                	ld	ra,72(sp)
    80000922:	6406                	ld	s0,64(sp)
    80000924:	74e2                	ld	s1,56(sp)
    80000926:	6ae2                	ld	s5,24(sp)
    80000928:	6161                	addi	sp,sp,80
    8000092a:	8082                	ret

000000008000092c <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000092c:	1101                	addi	sp,sp,-32
    8000092e:	ec06                	sd	ra,24(sp)
    80000930:	e822                	sd	s0,16(sp)
    80000932:	e426                	sd	s1,8(sp)
    80000934:	1000                	addi	s0,sp,32
    80000936:	84aa                	mv	s1,a0
  if(panicking == 0)
    80000938:	0000a797          	auipc	a5,0xa
    8000093c:	aec7a783          	lw	a5,-1300(a5) # 8000a424 <panicking>
    80000940:	cf95                	beqz	a5,8000097c <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000942:	0000a797          	auipc	a5,0xa
    80000946:	ade7a783          	lw	a5,-1314(a5) # 8000a420 <panicked>
    8000094a:	ef85                	bnez	a5,80000982 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000094c:	10000737          	lui	a4,0x10000
    80000950:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000952:	00074783          	lbu	a5,0(a4)
    80000956:	0207f793          	andi	a5,a5,32
    8000095a:	dfe5                	beqz	a5,80000952 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000095c:	0ff4f513          	zext.b	a0,s1
    80000960:	100007b7          	lui	a5,0x10000
    80000964:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    80000968:	0000a797          	auipc	a5,0xa
    8000096c:	abc7a783          	lw	a5,-1348(a5) # 8000a424 <panicking>
    80000970:	cb91                	beqz	a5,80000984 <uartputc_sync+0x58>
    pop_off();
}
    80000972:	60e2                	ld	ra,24(sp)
    80000974:	6442                	ld	s0,16(sp)
    80000976:	64a2                	ld	s1,8(sp)
    80000978:	6105                	addi	sp,sp,32
    8000097a:	8082                	ret
    push_off();
    8000097c:	450000ef          	jal	80000dcc <push_off>
    80000980:	b7c9                	j	80000942 <uartputc_sync+0x16>
    for(;;)
    80000982:	a001                	j	80000982 <uartputc_sync+0x56>
    pop_off();
    80000984:	4cc000ef          	jal	80000e50 <pop_off>
}
    80000988:	b7ed                	j	80000972 <uartputc_sync+0x46>

000000008000098a <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    8000098a:	1141                	addi	sp,sp,-16
    8000098c:	e422                	sd	s0,8(sp)
    8000098e:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    80000990:	100007b7          	lui	a5,0x10000
    80000994:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    80000996:	0007c783          	lbu	a5,0(a5)
    8000099a:	8b85                	andi	a5,a5,1
    8000099c:	cb81                	beqz	a5,800009ac <uartgetc+0x22>
    // input data is ready.
    return ReadReg(RHR);
    8000099e:	100007b7          	lui	a5,0x10000
    800009a2:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009a6:	6422                	ld	s0,8(sp)
    800009a8:	0141                	addi	sp,sp,16
    800009aa:	8082                	ret
    return -1;
    800009ac:	557d                	li	a0,-1
    800009ae:	bfe5                	j	800009a6 <uartgetc+0x1c>

00000000800009b0 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009b0:	1101                	addi	sp,sp,-32
    800009b2:	ec06                	sd	ra,24(sp)
    800009b4:	e822                	sd	s0,16(sp)
    800009b6:	e426                	sd	s1,8(sp)
    800009b8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009ba:	100007b7          	lui	a5,0x10000
    800009be:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    800009c0:	0007c783          	lbu	a5,0(a5)

  acquire(&tx_lock);
    800009c4:	00012517          	auipc	a0,0x12
    800009c8:	b4c50513          	addi	a0,a0,-1204 # 80012510 <tx_lock>
    800009cc:	440000ef          	jal	80000e0c <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    800009d0:	100007b7          	lui	a5,0x10000
    800009d4:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009d6:	0007c783          	lbu	a5,0(a5)
    800009da:	0207f793          	andi	a5,a5,32
    800009de:	eb89                	bnez	a5,800009f0 <uartintr+0x40>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    800009e0:	00012517          	auipc	a0,0x12
    800009e4:	b3050513          	addi	a0,a0,-1232 # 80012510 <tx_lock>
    800009e8:	4bc000ef          	jal	80000ea4 <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009ec:	54fd                	li	s1,-1
    800009ee:	a831                	j	80000a0a <uartintr+0x5a>
    tx_busy = 0;
    800009f0:	0000a797          	auipc	a5,0xa
    800009f4:	a207ae23          	sw	zero,-1476(a5) # 8000a42c <tx_busy>
    wakeup(&tx_chan);
    800009f8:	0000a517          	auipc	a0,0xa
    800009fc:	a3050513          	addi	a0,a0,-1488 # 8000a428 <tx_chan>
    80000a00:	00d010ef          	jal	8000220c <wakeup>
    80000a04:	bff1                	j	800009e0 <uartintr+0x30>
      break;
    consoleintr(c);
    80000a06:	8a5ff0ef          	jal	800002aa <consoleintr>
    int c = uartgetc();
    80000a0a:	f81ff0ef          	jal	8000098a <uartgetc>
    if(c == -1)
    80000a0e:	fe951ce3          	bne	a0,s1,80000a06 <uartintr+0x56>
  }
}
    80000a12:	60e2                	ld	ra,24(sp)
    80000a14:	6442                	ld	s0,16(sp)
    80000a16:	64a2                	ld	s1,8(sp)
    80000a18:	6105                	addi	sp,sp,32
    80000a1a:	8082                	ret

0000000080000a1c <incref>:
#define PA2IDX(pa) (((uint64)(pa) - KERNBASE) / PGSIZE)

// Increment the reference count of the physical page at pa.
void
incref(uint64 pa)
{
    80000a1c:	1101                	addi	sp,sp,-32
    80000a1e:	ec06                	sd	ra,24(sp)
    80000a20:	e822                	sd	s0,16(sp)
    80000a22:	e426                	sd	s1,8(sp)
    80000a24:	e04a                	sd	s2,0(sp)
    80000a26:	1000                	addi	s0,sp,32
  if(pa < KERNBASE || pa >= PHYSTOP)
    80000a28:	800007b7          	lui	a5,0x80000
    80000a2c:	00f504b3          	add	s1,a0,a5
    80000a30:	080007b7          	lui	a5,0x8000
    80000a34:	02f4fc63          	bgeu	s1,a5,80000a6c <incref+0x50>
    panic("incref: bad pa");

  acquire(&reflock);
    80000a38:	00012917          	auipc	s2,0x12
    80000a3c:	af090913          	addi	s2,s2,-1296 # 80012528 <reflock>
    80000a40:	854a                	mv	a0,s2
    80000a42:	3ca000ef          	jal	80000e0c <acquire>
  page_ref[PA2IDX(pa)]++;
    80000a46:	80b1                	srli	s1,s1,0xc
    80000a48:	048a                	slli	s1,s1,0x2
    80000a4a:	00012797          	auipc	a5,0x12
    80000a4e:	b1678793          	addi	a5,a5,-1258 # 80012560 <page_ref>
    80000a52:	97a6                	add	a5,a5,s1
    80000a54:	4398                	lw	a4,0(a5)
    80000a56:	2705                	addiw	a4,a4,1
    80000a58:	c398                	sw	a4,0(a5)
  release(&reflock);
    80000a5a:	854a                	mv	a0,s2
    80000a5c:	448000ef          	jal	80000ea4 <release>
}
    80000a60:	60e2                	ld	ra,24(sp)
    80000a62:	6442                	ld	s0,16(sp)
    80000a64:	64a2                	ld	s1,8(sp)
    80000a66:	6902                	ld	s2,0(sp)
    80000a68:	6105                	addi	sp,sp,32
    80000a6a:	8082                	ret
    panic("incref: bad pa");
    80000a6c:	00006517          	auipc	a0,0x6
    80000a70:	5cc50513          	addi	a0,a0,1484 # 80007038 <etext+0x38>
    80000a74:	d6dff0ef          	jal	800007e0 <panic>

0000000080000a78 <getref>:
}

// Read the current reference count of the physical page at pa.
int
getref(uint64 pa)
{
    80000a78:	1101                	addi	sp,sp,-32
    80000a7a:	ec06                	sd	ra,24(sp)
    80000a7c:	e822                	sd	s0,16(sp)
    80000a7e:	e426                	sd	s1,8(sp)
    80000a80:	1000                	addi	s0,sp,32
  int c;

  if(pa < KERNBASE || pa >= PHYSTOP)
    80000a82:	800007b7          	lui	a5,0x80000
    80000a86:	00f504b3          	add	s1,a0,a5
    80000a8a:	080007b7          	lui	a5,0x8000
    80000a8e:	00f4e963          	bltu	s1,a5,80000aa0 <getref+0x28>
    return 0;
    80000a92:	4481                	li	s1,0

  acquire(&reflock);
  c = page_ref[PA2IDX(pa)];
  release(&reflock);
  return c;
}
    80000a94:	8526                	mv	a0,s1
    80000a96:	60e2                	ld	ra,24(sp)
    80000a98:	6442                	ld	s0,16(sp)
    80000a9a:	64a2                	ld	s1,8(sp)
    80000a9c:	6105                	addi	sp,sp,32
    80000a9e:	8082                	ret
    80000aa0:	e04a                	sd	s2,0(sp)
  acquire(&reflock);
    80000aa2:	00012917          	auipc	s2,0x12
    80000aa6:	a8690913          	addi	s2,s2,-1402 # 80012528 <reflock>
    80000aaa:	854a                	mv	a0,s2
    80000aac:	360000ef          	jal	80000e0c <acquire>
  c = page_ref[PA2IDX(pa)];
    80000ab0:	80b1                	srli	s1,s1,0xc
    80000ab2:	048a                	slli	s1,s1,0x2
    80000ab4:	00012797          	auipc	a5,0x12
    80000ab8:	aac78793          	addi	a5,a5,-1364 # 80012560 <page_ref>
    80000abc:	97a6                	add	a5,a5,s1
    80000abe:	4384                	lw	s1,0(a5)
  release(&reflock);
    80000ac0:	854a                	mv	a0,s2
    80000ac2:	3e2000ef          	jal	80000ea4 <release>
  return c;
    80000ac6:	6902                	ld	s2,0(sp)
    80000ac8:	b7f1                	j	80000a94 <getref+0x1c>

0000000080000aca <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000aca:	7179                	addi	sp,sp,-48
    80000acc:	f406                	sd	ra,40(sp)
    80000ace:	f022                	sd	s0,32(sp)
    80000ad0:	ec26                	sd	s1,24(sp)
    80000ad2:	e84a                	sd	s2,16(sp)
    80000ad4:	e44e                	sd	s3,8(sp)
    80000ad6:	1800                	addi	s0,sp,48
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000ad8:	03451793          	slli	a5,a0,0x34
    80000adc:	ebb1                	bnez	a5,80000b30 <kfree+0x66>
    80000ade:	84aa                	mv	s1,a0
    80000ae0:	00043797          	auipc	a5,0x43
    80000ae4:	c9078793          	addi	a5,a5,-880 # 80043770 <end>
    80000ae8:	04f56463          	bltu	a0,a5,80000b30 <kfree+0x66>
    80000aec:	47c5                	li	a5,17
    80000aee:	07ee                	slli	a5,a5,0x1b
    80000af0:	04f57063          	bgeu	a0,a5,80000b30 <kfree+0x66>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000af4:	6605                	lui	a2,0x1
    80000af6:	4585                	li	a1,1
    80000af8:	3e8000ef          	jal	80000ee0 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000afc:	00012997          	auipc	s3,0x12
    80000b00:	a2c98993          	addi	s3,s3,-1492 # 80012528 <reflock>
    80000b04:	00012917          	auipc	s2,0x12
    80000b08:	a3c90913          	addi	s2,s2,-1476 # 80012540 <kmem>
    80000b0c:	854a                	mv	a0,s2
    80000b0e:	2fe000ef          	jal	80000e0c <acquire>
  r->next = kmem.freelist;
    80000b12:	0309b783          	ld	a5,48(s3)
    80000b16:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000b18:	0299b823          	sd	s1,48(s3)
  release(&kmem.lock);
    80000b1c:	854a                	mv	a0,s2
    80000b1e:	386000ef          	jal	80000ea4 <release>
}
    80000b22:	70a2                	ld	ra,40(sp)
    80000b24:	7402                	ld	s0,32(sp)
    80000b26:	64e2                	ld	s1,24(sp)
    80000b28:	6942                	ld	s2,16(sp)
    80000b2a:	69a2                	ld	s3,8(sp)
    80000b2c:	6145                	addi	sp,sp,48
    80000b2e:	8082                	ret
    panic("kfree");
    80000b30:	00006517          	auipc	a0,0x6
    80000b34:	51850513          	addi	a0,a0,1304 # 80007048 <etext+0x48>
    80000b38:	ca9ff0ef          	jal	800007e0 <panic>

0000000080000b3c <decref>:
{
    80000b3c:	7179                	addi	sp,sp,-48
    80000b3e:	f406                	sd	ra,40(sp)
    80000b40:	f022                	sd	s0,32(sp)
    80000b42:	ec26                	sd	s1,24(sp)
    80000b44:	e84a                	sd	s2,16(sp)
    80000b46:	e44e                	sd	s3,8(sp)
    80000b48:	1800                	addi	s0,sp,48
  if(pa < KERNBASE || pa >= PHYSTOP)
    80000b4a:	800004b7          	lui	s1,0x80000
    80000b4e:	94aa                	add	s1,s1,a0
    80000b50:	080007b7          	lui	a5,0x8000
    80000b54:	04f4f363          	bgeu	s1,a5,80000b9a <decref+0x5e>
    80000b58:	892a                	mv	s2,a0
  acquire(&reflock);
    80000b5a:	00012997          	auipc	s3,0x12
    80000b5e:	9ce98993          	addi	s3,s3,-1586 # 80012528 <reflock>
    80000b62:	854e                	mv	a0,s3
    80000b64:	2a8000ef          	jal	80000e0c <acquire>
  c = --page_ref[PA2IDX(pa)];
    80000b68:	80b1                	srli	s1,s1,0xc
    80000b6a:	048a                	slli	s1,s1,0x2
    80000b6c:	00012797          	auipc	a5,0x12
    80000b70:	9f478793          	addi	a5,a5,-1548 # 80012560 <page_ref>
    80000b74:	97a6                	add	a5,a5,s1
    80000b76:	4398                	lw	a4,0(a5)
    80000b78:	377d                	addiw	a4,a4,-1
    80000b7a:	0007049b          	sext.w	s1,a4
    80000b7e:	c398                	sw	a4,0(a5)
  release(&reflock);
    80000b80:	854e                	mv	a0,s3
    80000b82:	322000ef          	jal	80000ea4 <release>
  if(c < 0)
    80000b86:	0204c063          	bltz	s1,80000ba6 <decref+0x6a>
  if(c == 0)
    80000b8a:	c485                	beqz	s1,80000bb2 <decref+0x76>
}
    80000b8c:	70a2                	ld	ra,40(sp)
    80000b8e:	7402                	ld	s0,32(sp)
    80000b90:	64e2                	ld	s1,24(sp)
    80000b92:	6942                	ld	s2,16(sp)
    80000b94:	69a2                	ld	s3,8(sp)
    80000b96:	6145                	addi	sp,sp,48
    80000b98:	8082                	ret
    panic("decref: bad pa");
    80000b9a:	00006517          	auipc	a0,0x6
    80000b9e:	4b650513          	addi	a0,a0,1206 # 80007050 <etext+0x50>
    80000ba2:	c3fff0ef          	jal	800007e0 <panic>
    panic("decref: negative refcount");
    80000ba6:	00006517          	auipc	a0,0x6
    80000baa:	4ba50513          	addi	a0,a0,1210 # 80007060 <etext+0x60>
    80000bae:	c33ff0ef          	jal	800007e0 <panic>
    kfree((void*)pa);
    80000bb2:	854a                	mv	a0,s2
    80000bb4:	f17ff0ef          	jal	80000aca <kfree>
}
    80000bb8:	bfd1                	j	80000b8c <decref+0x50>

0000000080000bba <freerange>:
{
    80000bba:	7179                	addi	sp,sp,-48
    80000bbc:	f406                	sd	ra,40(sp)
    80000bbe:	f022                	sd	s0,32(sp)
    80000bc0:	ec26                	sd	s1,24(sp)
    80000bc2:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000bc4:	6785                	lui	a5,0x1
    80000bc6:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000bca:	00e504b3          	add	s1,a0,a4
    80000bce:	777d                	lui	a4,0xfffff
    80000bd0:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000bd2:	94be                	add	s1,s1,a5
    80000bd4:	0295e263          	bltu	a1,s1,80000bf8 <freerange+0x3e>
    80000bd8:	e84a                	sd	s2,16(sp)
    80000bda:	e44e                	sd	s3,8(sp)
    80000bdc:	e052                	sd	s4,0(sp)
    80000bde:	892e                	mv	s2,a1
    kfree(p);
    80000be0:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000be2:	6985                	lui	s3,0x1
    kfree(p);
    80000be4:	01448533          	add	a0,s1,s4
    80000be8:	ee3ff0ef          	jal	80000aca <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000bec:	94ce                	add	s1,s1,s3
    80000bee:	fe997be3          	bgeu	s2,s1,80000be4 <freerange+0x2a>
    80000bf2:	6942                	ld	s2,16(sp)
    80000bf4:	69a2                	ld	s3,8(sp)
    80000bf6:	6a02                	ld	s4,0(sp)
}
    80000bf8:	70a2                	ld	ra,40(sp)
    80000bfa:	7402                	ld	s0,32(sp)
    80000bfc:	64e2                	ld	s1,24(sp)
    80000bfe:	6145                	addi	sp,sp,48
    80000c00:	8082                	ret

0000000080000c02 <kinit>:
{
    80000c02:	1141                	addi	sp,sp,-16
    80000c04:	e406                	sd	ra,8(sp)
    80000c06:	e022                	sd	s0,0(sp)
    80000c08:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000c0a:	00006597          	auipc	a1,0x6
    80000c0e:	47658593          	addi	a1,a1,1142 # 80007080 <etext+0x80>
    80000c12:	00012517          	auipc	a0,0x12
    80000c16:	92e50513          	addi	a0,a0,-1746 # 80012540 <kmem>
    80000c1a:	172000ef          	jal	80000d8c <initlock>
  initlock(&reflock, "reflock");
    80000c1e:	00006597          	auipc	a1,0x6
    80000c22:	46a58593          	addi	a1,a1,1130 # 80007088 <etext+0x88>
    80000c26:	00012517          	auipc	a0,0x12
    80000c2a:	90250513          	addi	a0,a0,-1790 # 80012528 <reflock>
    80000c2e:	15e000ef          	jal	80000d8c <initlock>
  freerange(end, (void*)PHYSTOP);
    80000c32:	45c5                	li	a1,17
    80000c34:	05ee                	slli	a1,a1,0x1b
    80000c36:	00043517          	auipc	a0,0x43
    80000c3a:	b3a50513          	addi	a0,a0,-1222 # 80043770 <end>
    80000c3e:	f7dff0ef          	jal	80000bba <freerange>
}
    80000c42:	60a2                	ld	ra,8(sp)
    80000c44:	6402                	ld	s0,0(sp)
    80000c46:	0141                	addi	sp,sp,16
    80000c48:	8082                	ret

0000000080000c4a <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000c4a:	1101                	addi	sp,sp,-32
    80000c4c:	ec06                	sd	ra,24(sp)
    80000c4e:	e822                	sd	s0,16(sp)
    80000c50:	e426                	sd	s1,8(sp)
    80000c52:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000c54:	00012517          	auipc	a0,0x12
    80000c58:	8ec50513          	addi	a0,a0,-1812 # 80012540 <kmem>
    80000c5c:	1b0000ef          	jal	80000e0c <acquire>
  r = kmem.freelist;
    80000c60:	00012497          	auipc	s1,0x12
    80000c64:	8f84b483          	ld	s1,-1800(s1) # 80012558 <kmem+0x18>
  if(r)
    80000c68:	c0b9                	beqz	s1,80000cae <kalloc+0x64>
    kmem.freelist = r->next;
    80000c6a:	609c                	ld	a5,0(s1)
    80000c6c:	00012717          	auipc	a4,0x12
    80000c70:	8ef73623          	sd	a5,-1812(a4) # 80012558 <kmem+0x18>
  release(&kmem.lock);
    80000c74:	00012517          	auipc	a0,0x12
    80000c78:	8cc50513          	addi	a0,a0,-1844 # 80012540 <kmem>
    80000c7c:	228000ef          	jal	80000ea4 <release>

  if(r) {
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000c80:	6605                	lui	a2,0x1
    80000c82:	4595                	li	a1,5
    80000c84:	8526                	mv	a0,s1
    80000c86:	25a000ef          	jal	80000ee0 <memset>
    page_ref[PA2IDX((uint64)r)] = 1;
    80000c8a:	800007b7          	lui	a5,0x80000
    80000c8e:	97a6                	add	a5,a5,s1
    80000c90:	83b1                	srli	a5,a5,0xc
    80000c92:	078a                	slli	a5,a5,0x2
    80000c94:	00012717          	auipc	a4,0x12
    80000c98:	8cc70713          	addi	a4,a4,-1844 # 80012560 <page_ref>
    80000c9c:	97ba                	add	a5,a5,a4
    80000c9e:	4705                	li	a4,1
    80000ca0:	c398                	sw	a4,0(a5)
  }
  return (void*)r;
}
    80000ca2:	8526                	mv	a0,s1
    80000ca4:	60e2                	ld	ra,24(sp)
    80000ca6:	6442                	ld	s0,16(sp)
    80000ca8:	64a2                	ld	s1,8(sp)
    80000caa:	6105                	addi	sp,sp,32
    80000cac:	8082                	ret
  release(&kmem.lock);
    80000cae:	00012517          	auipc	a0,0x12
    80000cb2:	89250513          	addi	a0,a0,-1902 # 80012540 <kmem>
    80000cb6:	1ee000ef          	jal	80000ea4 <release>
  if(r) {
    80000cba:	b7e5                	j	80000ca2 <kalloc+0x58>

0000000080000cbc <kreftest>:
// results so we can eyeball that incref/decref/getref behave.
// Safe to leave in the tree; it does not run unless kreftest() is
// called explicitly.
void
kreftest(void)
{
    80000cbc:	1101                	addi	sp,sp,-32
    80000cbe:	ec06                	sd	ra,24(sp)
    80000cc0:	e822                	sd	s0,16(sp)
    80000cc2:	e426                	sd	s1,8(sp)
    80000cc4:	e04a                	sd	s2,0(sp)
    80000cc6:	1000                	addi	s0,sp,32
  void *a = kalloc();
    80000cc8:	f83ff0ef          	jal	80000c4a <kalloc>
    80000ccc:	84aa                	mv	s1,a0
  void *b = kalloc();
    80000cce:	f7dff0ef          	jal	80000c4a <kalloc>
    80000cd2:	892a                	mv	s2,a0

  printf("kreftest: a=%p ref=%d (expect 1)\n", a, getref((uint64)a));
    80000cd4:	8526                	mv	a0,s1
    80000cd6:	da3ff0ef          	jal	80000a78 <getref>
    80000cda:	862a                	mv	a2,a0
    80000cdc:	85a6                	mv	a1,s1
    80000cde:	00006517          	auipc	a0,0x6
    80000ce2:	3b250513          	addi	a0,a0,946 # 80007090 <etext+0x90>
    80000ce6:	815ff0ef          	jal	800004fa <printf>
  printf("kreftest: b=%p ref=%d (expect 1)\n", b, getref((uint64)b));
    80000cea:	854a                	mv	a0,s2
    80000cec:	d8dff0ef          	jal	80000a78 <getref>
    80000cf0:	862a                	mv	a2,a0
    80000cf2:	85ca                	mv	a1,s2
    80000cf4:	00006517          	auipc	a0,0x6
    80000cf8:	3c450513          	addi	a0,a0,964 # 800070b8 <etext+0xb8>
    80000cfc:	ffeff0ef          	jal	800004fa <printf>

  incref((uint64)a);
    80000d00:	8526                	mv	a0,s1
    80000d02:	d1bff0ef          	jal	80000a1c <incref>
  incref((uint64)a);
    80000d06:	8526                	mv	a0,s1
    80000d08:	d15ff0ef          	jal	80000a1c <incref>
  printf("kreftest: after 2x incref(a) ref=%d (expect 3)\n", getref((uint64)a));
    80000d0c:	8526                	mv	a0,s1
    80000d0e:	d6bff0ef          	jal	80000a78 <getref>
    80000d12:	85aa                	mv	a1,a0
    80000d14:	00006517          	auipc	a0,0x6
    80000d18:	3cc50513          	addi	a0,a0,972 # 800070e0 <etext+0xe0>
    80000d1c:	fdeff0ef          	jal	800004fa <printf>

  decref((uint64)a);
    80000d20:	8526                	mv	a0,s1
    80000d22:	e1bff0ef          	jal	80000b3c <decref>
  printf("kreftest: after 1x decref(a) ref=%d (expect 2)\n", getref((uint64)a));
    80000d26:	8526                	mv	a0,s1
    80000d28:	d51ff0ef          	jal	80000a78 <getref>
    80000d2c:	85aa                	mv	a1,a0
    80000d2e:	00006517          	auipc	a0,0x6
    80000d32:	3e250513          	addi	a0,a0,994 # 80007110 <etext+0x110>
    80000d36:	fc4ff0ef          	jal	800004fa <printf>

  decref((uint64)a);
    80000d3a:	8526                	mv	a0,s1
    80000d3c:	e01ff0ef          	jal	80000b3c <decref>
  decref((uint64)a); // this last one should actually free the page
    80000d40:	8526                	mv	a0,s1
    80000d42:	dfbff0ef          	jal	80000b3c <decref>
  printf("kreftest: after dropping to 0, ref=%d (expect 0)\n", getref((uint64)a));
    80000d46:	8526                	mv	a0,s1
    80000d48:	d31ff0ef          	jal	80000a78 <getref>
    80000d4c:	85aa                	mv	a1,a0
    80000d4e:	00006517          	auipc	a0,0x6
    80000d52:	3f250513          	addi	a0,a0,1010 # 80007140 <etext+0x140>
    80000d56:	fa4ff0ef          	jal	800004fa <printf>

  decref((uint64)b); // b had ref=1, this frees it too
    80000d5a:	854a                	mv	a0,s2
    80000d5c:	de1ff0ef          	jal	80000b3c <decref>
  printf("kreftest: b freed, ref=%d (expect 0)\n", getref((uint64)b));
    80000d60:	854a                	mv	a0,s2
    80000d62:	d17ff0ef          	jal	80000a78 <getref>
    80000d66:	85aa                	mv	a1,a0
    80000d68:	00006517          	auipc	a0,0x6
    80000d6c:	41050513          	addi	a0,a0,1040 # 80007178 <etext+0x178>
    80000d70:	f8aff0ef          	jal	800004fa <printf>

  printf("kreftest: done\n");
    80000d74:	00006517          	auipc	a0,0x6
    80000d78:	42c50513          	addi	a0,a0,1068 # 800071a0 <etext+0x1a0>
    80000d7c:	f7eff0ef          	jal	800004fa <printf>
}
    80000d80:	60e2                	ld	ra,24(sp)
    80000d82:	6442                	ld	s0,16(sp)
    80000d84:	64a2                	ld	s1,8(sp)
    80000d86:	6902                	ld	s2,0(sp)
    80000d88:	6105                	addi	sp,sp,32
    80000d8a:	8082                	ret

0000000080000d8c <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000d8c:	1141                	addi	sp,sp,-16
    80000d8e:	e422                	sd	s0,8(sp)
    80000d90:	0800                	addi	s0,sp,16
  lk->name = name;
    80000d92:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000d94:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000d98:	00053823          	sd	zero,16(a0)
}
    80000d9c:	6422                	ld	s0,8(sp)
    80000d9e:	0141                	addi	sp,sp,16
    80000da0:	8082                	ret

0000000080000da2 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000da2:	411c                	lw	a5,0(a0)
    80000da4:	e399                	bnez	a5,80000daa <holding+0x8>
    80000da6:	4501                	li	a0,0
  return r;
}
    80000da8:	8082                	ret
{
    80000daa:	1101                	addi	sp,sp,-32
    80000dac:	ec06                	sd	ra,24(sp)
    80000dae:	e822                	sd	s0,16(sp)
    80000db0:	e426                	sd	s1,8(sp)
    80000db2:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000db4:	6904                	ld	s1,16(a0)
    80000db6:	5f7000ef          	jal	80001bac <mycpu>
    80000dba:	40a48533          	sub	a0,s1,a0
    80000dbe:	00153513          	seqz	a0,a0
}
    80000dc2:	60e2                	ld	ra,24(sp)
    80000dc4:	6442                	ld	s0,16(sp)
    80000dc6:	64a2                	ld	s1,8(sp)
    80000dc8:	6105                	addi	sp,sp,32
    80000dca:	8082                	ret

0000000080000dcc <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000dcc:	1101                	addi	sp,sp,-32
    80000dce:	ec06                	sd	ra,24(sp)
    80000dd0:	e822                	sd	s0,16(sp)
    80000dd2:	e426                	sd	s1,8(sp)
    80000dd4:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000dd6:	100024f3          	csrr	s1,sstatus
    80000dda:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000dde:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000de0:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000de4:	5c9000ef          	jal	80001bac <mycpu>
    80000de8:	5d3c                	lw	a5,120(a0)
    80000dea:	cb99                	beqz	a5,80000e00 <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000dec:	5c1000ef          	jal	80001bac <mycpu>
    80000df0:	5d3c                	lw	a5,120(a0)
    80000df2:	2785                	addiw	a5,a5,1 # ffffffff80000001 <end+0xfffffffefffbc891>
    80000df4:	dd3c                	sw	a5,120(a0)
}
    80000df6:	60e2                	ld	ra,24(sp)
    80000df8:	6442                	ld	s0,16(sp)
    80000dfa:	64a2                	ld	s1,8(sp)
    80000dfc:	6105                	addi	sp,sp,32
    80000dfe:	8082                	ret
    mycpu()->intena = old;
    80000e00:	5ad000ef          	jal	80001bac <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000e04:	8085                	srli	s1,s1,0x1
    80000e06:	8885                	andi	s1,s1,1
    80000e08:	dd64                	sw	s1,124(a0)
    80000e0a:	b7cd                	j	80000dec <push_off+0x20>

0000000080000e0c <acquire>:
{
    80000e0c:	1101                	addi	sp,sp,-32
    80000e0e:	ec06                	sd	ra,24(sp)
    80000e10:	e822                	sd	s0,16(sp)
    80000e12:	e426                	sd	s1,8(sp)
    80000e14:	1000                	addi	s0,sp,32
    80000e16:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000e18:	fb5ff0ef          	jal	80000dcc <push_off>
  if(holding(lk))
    80000e1c:	8526                	mv	a0,s1
    80000e1e:	f85ff0ef          	jal	80000da2 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000e22:	4705                	li	a4,1
  if(holding(lk))
    80000e24:	e105                	bnez	a0,80000e44 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000e26:	87ba                	mv	a5,a4
    80000e28:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000e2c:	2781                	sext.w	a5,a5
    80000e2e:	ffe5                	bnez	a5,80000e26 <acquire+0x1a>
  __sync_synchronize();
    80000e30:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000e34:	579000ef          	jal	80001bac <mycpu>
    80000e38:	e888                	sd	a0,16(s1)
}
    80000e3a:	60e2                	ld	ra,24(sp)
    80000e3c:	6442                	ld	s0,16(sp)
    80000e3e:	64a2                	ld	s1,8(sp)
    80000e40:	6105                	addi	sp,sp,32
    80000e42:	8082                	ret
    panic("acquire");
    80000e44:	00006517          	auipc	a0,0x6
    80000e48:	36c50513          	addi	a0,a0,876 # 800071b0 <etext+0x1b0>
    80000e4c:	995ff0ef          	jal	800007e0 <panic>

0000000080000e50 <pop_off>:

void
pop_off(void)
{
    80000e50:	1141                	addi	sp,sp,-16
    80000e52:	e406                	sd	ra,8(sp)
    80000e54:	e022                	sd	s0,0(sp)
    80000e56:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000e58:	555000ef          	jal	80001bac <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000e5c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000e60:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000e62:	e78d                	bnez	a5,80000e8c <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000e64:	5d3c                	lw	a5,120(a0)
    80000e66:	02f05963          	blez	a5,80000e98 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000e6a:	37fd                	addiw	a5,a5,-1
    80000e6c:	0007871b          	sext.w	a4,a5
    80000e70:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000e72:	eb09                	bnez	a4,80000e84 <pop_off+0x34>
    80000e74:	5d7c                	lw	a5,124(a0)
    80000e76:	c799                	beqz	a5,80000e84 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000e78:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000e7c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000e80:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000e84:	60a2                	ld	ra,8(sp)
    80000e86:	6402                	ld	s0,0(sp)
    80000e88:	0141                	addi	sp,sp,16
    80000e8a:	8082                	ret
    panic("pop_off - interruptible");
    80000e8c:	00006517          	auipc	a0,0x6
    80000e90:	32c50513          	addi	a0,a0,812 # 800071b8 <etext+0x1b8>
    80000e94:	94dff0ef          	jal	800007e0 <panic>
    panic("pop_off");
    80000e98:	00006517          	auipc	a0,0x6
    80000e9c:	33850513          	addi	a0,a0,824 # 800071d0 <etext+0x1d0>
    80000ea0:	941ff0ef          	jal	800007e0 <panic>

0000000080000ea4 <release>:
{
    80000ea4:	1101                	addi	sp,sp,-32
    80000ea6:	ec06                	sd	ra,24(sp)
    80000ea8:	e822                	sd	s0,16(sp)
    80000eaa:	e426                	sd	s1,8(sp)
    80000eac:	1000                	addi	s0,sp,32
    80000eae:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000eb0:	ef3ff0ef          	jal	80000da2 <holding>
    80000eb4:	c105                	beqz	a0,80000ed4 <release+0x30>
  lk->cpu = 0;
    80000eb6:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000eba:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000ebe:	0310000f          	fence	rw,w
    80000ec2:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000ec6:	f8bff0ef          	jal	80000e50 <pop_off>
}
    80000eca:	60e2                	ld	ra,24(sp)
    80000ecc:	6442                	ld	s0,16(sp)
    80000ece:	64a2                	ld	s1,8(sp)
    80000ed0:	6105                	addi	sp,sp,32
    80000ed2:	8082                	ret
    panic("release");
    80000ed4:	00006517          	auipc	a0,0x6
    80000ed8:	30450513          	addi	a0,a0,772 # 800071d8 <etext+0x1d8>
    80000edc:	905ff0ef          	jal	800007e0 <panic>

0000000080000ee0 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000ee0:	1141                	addi	sp,sp,-16
    80000ee2:	e422                	sd	s0,8(sp)
    80000ee4:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000ee6:	ca19                	beqz	a2,80000efc <memset+0x1c>
    80000ee8:	87aa                	mv	a5,a0
    80000eea:	1602                	slli	a2,a2,0x20
    80000eec:	9201                	srli	a2,a2,0x20
    80000eee:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000ef2:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000ef6:	0785                	addi	a5,a5,1
    80000ef8:	fee79de3          	bne	a5,a4,80000ef2 <memset+0x12>
  }
  return dst;
}
    80000efc:	6422                	ld	s0,8(sp)
    80000efe:	0141                	addi	sp,sp,16
    80000f00:	8082                	ret

0000000080000f02 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000f02:	1141                	addi	sp,sp,-16
    80000f04:	e422                	sd	s0,8(sp)
    80000f06:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000f08:	ca05                	beqz	a2,80000f38 <memcmp+0x36>
    80000f0a:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000f0e:	1682                	slli	a3,a3,0x20
    80000f10:	9281                	srli	a3,a3,0x20
    80000f12:	0685                	addi	a3,a3,1
    80000f14:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000f16:	00054783          	lbu	a5,0(a0)
    80000f1a:	0005c703          	lbu	a4,0(a1)
    80000f1e:	00e79863          	bne	a5,a4,80000f2e <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000f22:	0505                	addi	a0,a0,1
    80000f24:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000f26:	fed518e3          	bne	a0,a3,80000f16 <memcmp+0x14>
  }

  return 0;
    80000f2a:	4501                	li	a0,0
    80000f2c:	a019                	j	80000f32 <memcmp+0x30>
      return *s1 - *s2;
    80000f2e:	40e7853b          	subw	a0,a5,a4
}
    80000f32:	6422                	ld	s0,8(sp)
    80000f34:	0141                	addi	sp,sp,16
    80000f36:	8082                	ret
  return 0;
    80000f38:	4501                	li	a0,0
    80000f3a:	bfe5                	j	80000f32 <memcmp+0x30>

0000000080000f3c <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000f3c:	1141                	addi	sp,sp,-16
    80000f3e:	e422                	sd	s0,8(sp)
    80000f40:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000f42:	c205                	beqz	a2,80000f62 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000f44:	02a5e263          	bltu	a1,a0,80000f68 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000f48:	1602                	slli	a2,a2,0x20
    80000f4a:	9201                	srli	a2,a2,0x20
    80000f4c:	00c587b3          	add	a5,a1,a2
{
    80000f50:	872a                	mv	a4,a0
      *d++ = *s++;
    80000f52:	0585                	addi	a1,a1,1
    80000f54:	0705                	addi	a4,a4,1
    80000f56:	fff5c683          	lbu	a3,-1(a1)
    80000f5a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000f5e:	feb79ae3          	bne	a5,a1,80000f52 <memmove+0x16>

  return dst;
}
    80000f62:	6422                	ld	s0,8(sp)
    80000f64:	0141                	addi	sp,sp,16
    80000f66:	8082                	ret
  if(s < d && s + n > d){
    80000f68:	02061693          	slli	a3,a2,0x20
    80000f6c:	9281                	srli	a3,a3,0x20
    80000f6e:	00d58733          	add	a4,a1,a3
    80000f72:	fce57be3          	bgeu	a0,a4,80000f48 <memmove+0xc>
    d += n;
    80000f76:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000f78:	fff6079b          	addiw	a5,a2,-1
    80000f7c:	1782                	slli	a5,a5,0x20
    80000f7e:	9381                	srli	a5,a5,0x20
    80000f80:	fff7c793          	not	a5,a5
    80000f84:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000f86:	177d                	addi	a4,a4,-1
    80000f88:	16fd                	addi	a3,a3,-1
    80000f8a:	00074603          	lbu	a2,0(a4)
    80000f8e:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000f92:	fef71ae3          	bne	a4,a5,80000f86 <memmove+0x4a>
    80000f96:	b7f1                	j	80000f62 <memmove+0x26>

0000000080000f98 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000f98:	1141                	addi	sp,sp,-16
    80000f9a:	e406                	sd	ra,8(sp)
    80000f9c:	e022                	sd	s0,0(sp)
    80000f9e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000fa0:	f9dff0ef          	jal	80000f3c <memmove>
}
    80000fa4:	60a2                	ld	ra,8(sp)
    80000fa6:	6402                	ld	s0,0(sp)
    80000fa8:	0141                	addi	sp,sp,16
    80000faa:	8082                	ret

0000000080000fac <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000fac:	1141                	addi	sp,sp,-16
    80000fae:	e422                	sd	s0,8(sp)
    80000fb0:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000fb2:	ce11                	beqz	a2,80000fce <strncmp+0x22>
    80000fb4:	00054783          	lbu	a5,0(a0)
    80000fb8:	cf89                	beqz	a5,80000fd2 <strncmp+0x26>
    80000fba:	0005c703          	lbu	a4,0(a1)
    80000fbe:	00f71a63          	bne	a4,a5,80000fd2 <strncmp+0x26>
    n--, p++, q++;
    80000fc2:	367d                	addiw	a2,a2,-1
    80000fc4:	0505                	addi	a0,a0,1
    80000fc6:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000fc8:	f675                	bnez	a2,80000fb4 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000fca:	4501                	li	a0,0
    80000fcc:	a801                	j	80000fdc <strncmp+0x30>
    80000fce:	4501                	li	a0,0
    80000fd0:	a031                	j	80000fdc <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000fd2:	00054503          	lbu	a0,0(a0)
    80000fd6:	0005c783          	lbu	a5,0(a1)
    80000fda:	9d1d                	subw	a0,a0,a5
}
    80000fdc:	6422                	ld	s0,8(sp)
    80000fde:	0141                	addi	sp,sp,16
    80000fe0:	8082                	ret

0000000080000fe2 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000fe2:	1141                	addi	sp,sp,-16
    80000fe4:	e422                	sd	s0,8(sp)
    80000fe6:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000fe8:	87aa                	mv	a5,a0
    80000fea:	86b2                	mv	a3,a2
    80000fec:	367d                	addiw	a2,a2,-1
    80000fee:	02d05563          	blez	a3,80001018 <strncpy+0x36>
    80000ff2:	0785                	addi	a5,a5,1
    80000ff4:	0005c703          	lbu	a4,0(a1)
    80000ff8:	fee78fa3          	sb	a4,-1(a5)
    80000ffc:	0585                	addi	a1,a1,1
    80000ffe:	f775                	bnez	a4,80000fea <strncpy+0x8>
    ;
  while(n-- > 0)
    80001000:	873e                	mv	a4,a5
    80001002:	9fb5                	addw	a5,a5,a3
    80001004:	37fd                	addiw	a5,a5,-1
    80001006:	00c05963          	blez	a2,80001018 <strncpy+0x36>
    *s++ = 0;
    8000100a:	0705                	addi	a4,a4,1
    8000100c:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80001010:	40e786bb          	subw	a3,a5,a4
    80001014:	fed04be3          	bgtz	a3,8000100a <strncpy+0x28>
  return os;
}
    80001018:	6422                	ld	s0,8(sp)
    8000101a:	0141                	addi	sp,sp,16
    8000101c:	8082                	ret

000000008000101e <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    8000101e:	1141                	addi	sp,sp,-16
    80001020:	e422                	sd	s0,8(sp)
    80001022:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80001024:	02c05363          	blez	a2,8000104a <safestrcpy+0x2c>
    80001028:	fff6069b          	addiw	a3,a2,-1
    8000102c:	1682                	slli	a3,a3,0x20
    8000102e:	9281                	srli	a3,a3,0x20
    80001030:	96ae                	add	a3,a3,a1
    80001032:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80001034:	00d58963          	beq	a1,a3,80001046 <safestrcpy+0x28>
    80001038:	0585                	addi	a1,a1,1
    8000103a:	0785                	addi	a5,a5,1
    8000103c:	fff5c703          	lbu	a4,-1(a1)
    80001040:	fee78fa3          	sb	a4,-1(a5)
    80001044:	fb65                	bnez	a4,80001034 <safestrcpy+0x16>
    ;
  *s = 0;
    80001046:	00078023          	sb	zero,0(a5)
  return os;
}
    8000104a:	6422                	ld	s0,8(sp)
    8000104c:	0141                	addi	sp,sp,16
    8000104e:	8082                	ret

0000000080001050 <strlen>:

int
strlen(const char *s)
{
    80001050:	1141                	addi	sp,sp,-16
    80001052:	e422                	sd	s0,8(sp)
    80001054:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80001056:	00054783          	lbu	a5,0(a0)
    8000105a:	cf91                	beqz	a5,80001076 <strlen+0x26>
    8000105c:	0505                	addi	a0,a0,1
    8000105e:	87aa                	mv	a5,a0
    80001060:	86be                	mv	a3,a5
    80001062:	0785                	addi	a5,a5,1
    80001064:	fff7c703          	lbu	a4,-1(a5)
    80001068:	ff65                	bnez	a4,80001060 <strlen+0x10>
    8000106a:	40a6853b          	subw	a0,a3,a0
    8000106e:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80001070:	6422                	ld	s0,8(sp)
    80001072:	0141                	addi	sp,sp,16
    80001074:	8082                	ret
  for(n = 0; s[n]; n++)
    80001076:	4501                	li	a0,0
    80001078:	bfe5                	j	80001070 <strlen+0x20>

000000008000107a <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    8000107a:	1141                	addi	sp,sp,-16
    8000107c:	e406                	sd	ra,8(sp)
    8000107e:	e022                	sd	s0,0(sp)
    80001080:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80001082:	31b000ef          	jal	80001b9c <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80001086:	00009717          	auipc	a4,0x9
    8000108a:	3aa70713          	addi	a4,a4,938 # 8000a430 <started>
  if(cpuid() == 0){
    8000108e:	c51d                	beqz	a0,800010bc <main+0x42>
    while(started == 0)
    80001090:	431c                	lw	a5,0(a4)
    80001092:	2781                	sext.w	a5,a5
    80001094:	dff5                	beqz	a5,80001090 <main+0x16>
      ;
    __sync_synchronize();
    80001096:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    8000109a:	303000ef          	jal	80001b9c <cpuid>
    8000109e:	85aa                	mv	a1,a0
    800010a0:	00006517          	auipc	a0,0x6
    800010a4:	15850513          	addi	a0,a0,344 # 800071f8 <etext+0x1f8>
    800010a8:	c52ff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    800010ac:	084000ef          	jal	80001130 <kvminithart>
    trapinithart();   // install kernel trap vector
    800010b0:	632010ef          	jal	800026e2 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    800010b4:	624040ef          	jal	800056d8 <plicinithart>
  }

  scheduler();    // What proc is it going to call? Init with PID=0
    800010b8:	771000ef          	jal	80002028 <scheduler>
    consoleinit();
    800010bc:	b68ff0ef          	jal	80000424 <consoleinit>
    printfinit();
    800010c0:	f5cff0ef          	jal	8000081c <printfinit>
    printf("\n");
    800010c4:	00006517          	auipc	a0,0x6
    800010c8:	0ac50513          	addi	a0,a0,172 # 80007170 <etext+0x170>
    800010cc:	c2eff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    800010d0:	00006517          	auipc	a0,0x6
    800010d4:	11050513          	addi	a0,a0,272 # 800071e0 <etext+0x1e0>
    800010d8:	c22ff0ef          	jal	800004fa <printf>
    printf("\n");
    800010dc:	00006517          	auipc	a0,0x6
    800010e0:	09450513          	addi	a0,a0,148 # 80007170 <etext+0x170>
    800010e4:	c16ff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    800010e8:	b1bff0ef          	jal	80000c02 <kinit>
    kreftest();      // Phase 1: sanity-check page refcounting (remove/comment out later)
    800010ec:	bd1ff0ef          	jal	80000cbc <kreftest>
    kvminit();       // create kernel page table
    800010f0:	2ca000ef          	jal	800013ba <kvminit>
    kvminithart();   // turn on paging
    800010f4:	03c000ef          	jal	80001130 <kvminithart>
    procinit();      // process table
    800010f8:	1ef000ef          	jal	80001ae6 <procinit>
    trapinit();      // trap vectors
    800010fc:	5c2010ef          	jal	800026be <trapinit>
    trapinithart();  // install kernel trap vector
    80001100:	5e2010ef          	jal	800026e2 <trapinithart>
    plicinit();      // set up interrupt controller
    80001104:	5ba040ef          	jal	800056be <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80001108:	5d0040ef          	jal	800056d8 <plicinithart>
    binit();         // buffer cache
    8000110c:	49b010ef          	jal	80002da6 <binit>
    iinit();         // inode table
    80001110:	220020ef          	jal	80003330 <iinit>
    fileinit();      // file table
    80001114:	112030ef          	jal	80004226 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80001118:	6b0040ef          	jal	800057c8 <virtio_disk_init>
    userinit();      // first user process
    8000111c:	573000ef          	jal	80001e8e <userinit>
    __sync_synchronize();
    80001120:	0330000f          	fence	rw,rw
    started = 1;
    80001124:	4785                	li	a5,1
    80001126:	00009717          	auipc	a4,0x9
    8000112a:	30f72523          	sw	a5,778(a4) # 8000a430 <started>
    8000112e:	b769                	j	800010b8 <main+0x3e>

0000000080001130 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80001130:	1141                	addi	sp,sp,-16
    80001132:	e422                	sd	s0,8(sp)
    80001134:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80001136:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    8000113a:	00009797          	auipc	a5,0x9
    8000113e:	2fe7b783          	ld	a5,766(a5) # 8000a438 <kernel_pagetable>
    80001142:	83b1                	srli	a5,a5,0xc
    80001144:	577d                	li	a4,-1
    80001146:	177e                	slli	a4,a4,0x3f
    80001148:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    8000114a:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    8000114e:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80001152:	6422                	ld	s0,8(sp)
    80001154:	0141                	addi	sp,sp,16
    80001156:	8082                	ret

0000000080001158 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80001158:	7139                	addi	sp,sp,-64
    8000115a:	fc06                	sd	ra,56(sp)
    8000115c:	f822                	sd	s0,48(sp)
    8000115e:	f426                	sd	s1,40(sp)
    80001160:	f04a                	sd	s2,32(sp)
    80001162:	ec4e                	sd	s3,24(sp)
    80001164:	e852                	sd	s4,16(sp)
    80001166:	e456                	sd	s5,8(sp)
    80001168:	e05a                	sd	s6,0(sp)
    8000116a:	0080                	addi	s0,sp,64
    8000116c:	84aa                	mv	s1,a0
    8000116e:	89ae                	mv	s3,a1
    80001170:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80001172:	57fd                	li	a5,-1
    80001174:	83e9                	srli	a5,a5,0x1a
    80001176:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80001178:	4b31                	li	s6,12
  if(va >= MAXVA)
    8000117a:	02b7fc63          	bgeu	a5,a1,800011b2 <walk+0x5a>
    panic("walk");
    8000117e:	00006517          	auipc	a0,0x6
    80001182:	09250513          	addi	a0,a0,146 # 80007210 <etext+0x210>
    80001186:	e5aff0ef          	jal	800007e0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    8000118a:	060a8263          	beqz	s5,800011ee <walk+0x96>
    8000118e:	abdff0ef          	jal	80000c4a <kalloc>
    80001192:	84aa                	mv	s1,a0
    80001194:	c139                	beqz	a0,800011da <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80001196:	6605                	lui	a2,0x1
    80001198:	4581                	li	a1,0
    8000119a:	d47ff0ef          	jal	80000ee0 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000119e:	00c4d793          	srli	a5,s1,0xc
    800011a2:	07aa                	slli	a5,a5,0xa
    800011a4:	0017e793          	ori	a5,a5,1
    800011a8:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    800011ac:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffbb887>
    800011ae:	036a0063          	beq	s4,s6,800011ce <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    800011b2:	0149d933          	srl	s2,s3,s4
    800011b6:	1ff97913          	andi	s2,s2,511
    800011ba:	090e                	slli	s2,s2,0x3
    800011bc:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    800011be:	00093483          	ld	s1,0(s2)
    800011c2:	0014f793          	andi	a5,s1,1
    800011c6:	d3f1                	beqz	a5,8000118a <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    800011c8:	80a9                	srli	s1,s1,0xa
    800011ca:	04b2                	slli	s1,s1,0xc
    800011cc:	b7c5                	j	800011ac <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    800011ce:	00c9d513          	srli	a0,s3,0xc
    800011d2:	1ff57513          	andi	a0,a0,511
    800011d6:	050e                	slli	a0,a0,0x3
    800011d8:	9526                	add	a0,a0,s1
}
    800011da:	70e2                	ld	ra,56(sp)
    800011dc:	7442                	ld	s0,48(sp)
    800011de:	74a2                	ld	s1,40(sp)
    800011e0:	7902                	ld	s2,32(sp)
    800011e2:	69e2                	ld	s3,24(sp)
    800011e4:	6a42                	ld	s4,16(sp)
    800011e6:	6aa2                	ld	s5,8(sp)
    800011e8:	6b02                	ld	s6,0(sp)
    800011ea:	6121                	addi	sp,sp,64
    800011ec:	8082                	ret
        return 0;
    800011ee:	4501                	li	a0,0
    800011f0:	b7ed                	j	800011da <walk+0x82>

00000000800011f2 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    800011f2:	57fd                	li	a5,-1
    800011f4:	83e9                	srli	a5,a5,0x1a
    800011f6:	00b7f463          	bgeu	a5,a1,800011fe <walkaddr+0xc>
    return 0;
    800011fa:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    800011fc:	8082                	ret
{
    800011fe:	1141                	addi	sp,sp,-16
    80001200:	e406                	sd	ra,8(sp)
    80001202:	e022                	sd	s0,0(sp)
    80001204:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);    // Returns the entry in the third pt
    80001206:	4601                	li	a2,0
    80001208:	f51ff0ef          	jal	80001158 <walk>
  if(pte == 0)
    8000120c:	c105                	beqz	a0,8000122c <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    8000120e:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80001210:	0117f693          	andi	a3,a5,17
    80001214:	4745                	li	a4,17
    return 0;
    80001216:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80001218:	00e68663          	beq	a3,a4,80001224 <walkaddr+0x32>
}
    8000121c:	60a2                	ld	ra,8(sp)
    8000121e:	6402                	ld	s0,0(sp)
    80001220:	0141                	addi	sp,sp,16
    80001222:	8082                	ret
  pa = PTE2PA(*pte);
    80001224:	83a9                	srli	a5,a5,0xa
    80001226:	00c79513          	slli	a0,a5,0xc
  return pa;
    8000122a:	bfcd                	j	8000121c <walkaddr+0x2a>
    return 0;
    8000122c:	4501                	li	a0,0
    8000122e:	b7fd                	j	8000121c <walkaddr+0x2a>

0000000080001230 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001230:	715d                	addi	sp,sp,-80
    80001232:	e486                	sd	ra,72(sp)
    80001234:	e0a2                	sd	s0,64(sp)
    80001236:	fc26                	sd	s1,56(sp)
    80001238:	f84a                	sd	s2,48(sp)
    8000123a:	f44e                	sd	s3,40(sp)
    8000123c:	f052                	sd	s4,32(sp)
    8000123e:	ec56                	sd	s5,24(sp)
    80001240:	e85a                	sd	s6,16(sp)
    80001242:	e45e                	sd	s7,8(sp)
    80001244:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001246:	03459793          	slli	a5,a1,0x34
    8000124a:	e7a9                	bnez	a5,80001294 <mappages+0x64>
    8000124c:	8aaa                	mv	s5,a0
    8000124e:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80001250:	03461793          	slli	a5,a2,0x34
    80001254:	e7b1                	bnez	a5,800012a0 <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    80001256:	ca39                	beqz	a2,800012ac <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001258:	77fd                	lui	a5,0xfffff
    8000125a:	963e                	add	a2,a2,a5
    8000125c:	00b609b3          	add	s3,a2,a1
  a = va;
    80001260:	892e                	mv	s2,a1
    80001262:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80001266:	6b85                	lui	s7,0x1
    80001268:	014904b3          	add	s1,s2,s4
    if((pte = walk(pagetable, a, 1)) == 0)
    8000126c:	4605                	li	a2,1
    8000126e:	85ca                	mv	a1,s2
    80001270:	8556                	mv	a0,s5
    80001272:	ee7ff0ef          	jal	80001158 <walk>
    80001276:	c539                	beqz	a0,800012c4 <mappages+0x94>
    if(*pte & PTE_V)
    80001278:	611c                	ld	a5,0(a0)
    8000127a:	8b85                	andi	a5,a5,1
    8000127c:	ef95                	bnez	a5,800012b8 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000127e:	80b1                	srli	s1,s1,0xc
    80001280:	04aa                	slli	s1,s1,0xa
    80001282:	0164e4b3          	or	s1,s1,s6
    80001286:	0014e493          	ori	s1,s1,1
    8000128a:	e104                	sd	s1,0(a0)
    if(a == last)
    8000128c:	05390863          	beq	s2,s3,800012dc <mappages+0xac>
    a += PGSIZE;
    80001290:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001292:	bfd9                	j	80001268 <mappages+0x38>
    panic("mappages: va not aligned");
    80001294:	00006517          	auipc	a0,0x6
    80001298:	f8450513          	addi	a0,a0,-124 # 80007218 <etext+0x218>
    8000129c:	d44ff0ef          	jal	800007e0 <panic>
    panic("mappages: size not aligned");
    800012a0:	00006517          	auipc	a0,0x6
    800012a4:	f9850513          	addi	a0,a0,-104 # 80007238 <etext+0x238>
    800012a8:	d38ff0ef          	jal	800007e0 <panic>
    panic("mappages: size");
    800012ac:	00006517          	auipc	a0,0x6
    800012b0:	fac50513          	addi	a0,a0,-84 # 80007258 <etext+0x258>
    800012b4:	d2cff0ef          	jal	800007e0 <panic>
      panic("mappages: remap");
    800012b8:	00006517          	auipc	a0,0x6
    800012bc:	fb050513          	addi	a0,a0,-80 # 80007268 <etext+0x268>
    800012c0:	d20ff0ef          	jal	800007e0 <panic>
      return -1;
    800012c4:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800012c6:	60a6                	ld	ra,72(sp)
    800012c8:	6406                	ld	s0,64(sp)
    800012ca:	74e2                	ld	s1,56(sp)
    800012cc:	7942                	ld	s2,48(sp)
    800012ce:	79a2                	ld	s3,40(sp)
    800012d0:	7a02                	ld	s4,32(sp)
    800012d2:	6ae2                	ld	s5,24(sp)
    800012d4:	6b42                	ld	s6,16(sp)
    800012d6:	6ba2                	ld	s7,8(sp)
    800012d8:	6161                	addi	sp,sp,80
    800012da:	8082                	ret
  return 0;
    800012dc:	4501                	li	a0,0
    800012de:	b7e5                	j	800012c6 <mappages+0x96>

00000000800012e0 <kvmmap>:
{
    800012e0:	1141                	addi	sp,sp,-16
    800012e2:	e406                	sd	ra,8(sp)
    800012e4:	e022                	sd	s0,0(sp)
    800012e6:	0800                	addi	s0,sp,16
    800012e8:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800012ea:	86b2                	mv	a3,a2
    800012ec:	863e                	mv	a2,a5
    800012ee:	f43ff0ef          	jal	80001230 <mappages>
    800012f2:	e509                	bnez	a0,800012fc <kvmmap+0x1c>
}
    800012f4:	60a2                	ld	ra,8(sp)
    800012f6:	6402                	ld	s0,0(sp)
    800012f8:	0141                	addi	sp,sp,16
    800012fa:	8082                	ret
    panic("kvmmap");
    800012fc:	00006517          	auipc	a0,0x6
    80001300:	f7c50513          	addi	a0,a0,-132 # 80007278 <etext+0x278>
    80001304:	cdcff0ef          	jal	800007e0 <panic>

0000000080001308 <kvmmake>:
{
    80001308:	1101                	addi	sp,sp,-32
    8000130a:	ec06                	sd	ra,24(sp)
    8000130c:	e822                	sd	s0,16(sp)
    8000130e:	e426                	sd	s1,8(sp)
    80001310:	e04a                	sd	s2,0(sp)
    80001312:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001314:	937ff0ef          	jal	80000c4a <kalloc>
    80001318:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000131a:	6605                	lui	a2,0x1
    8000131c:	4581                	li	a1,0
    8000131e:	bc3ff0ef          	jal	80000ee0 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001322:	4719                	li	a4,6
    80001324:	6685                	lui	a3,0x1
    80001326:	10000637          	lui	a2,0x10000
    8000132a:	100005b7          	lui	a1,0x10000
    8000132e:	8526                	mv	a0,s1
    80001330:	fb1ff0ef          	jal	800012e0 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001334:	4719                	li	a4,6
    80001336:	6685                	lui	a3,0x1
    80001338:	10001637          	lui	a2,0x10001
    8000133c:	100015b7          	lui	a1,0x10001
    80001340:	8526                	mv	a0,s1
    80001342:	f9fff0ef          	jal	800012e0 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001346:	4719                	li	a4,6
    80001348:	040006b7          	lui	a3,0x4000
    8000134c:	0c000637          	lui	a2,0xc000
    80001350:	0c0005b7          	lui	a1,0xc000
    80001354:	8526                	mv	a0,s1
    80001356:	f8bff0ef          	jal	800012e0 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    8000135a:	00006917          	auipc	s2,0x6
    8000135e:	ca690913          	addi	s2,s2,-858 # 80007000 <etext>
    80001362:	4729                	li	a4,10
    80001364:	80006697          	auipc	a3,0x80006
    80001368:	c9c68693          	addi	a3,a3,-868 # 7000 <_entry-0x7fff9000>
    8000136c:	4605                	li	a2,1
    8000136e:	067e                	slli	a2,a2,0x1f
    80001370:	85b2                	mv	a1,a2
    80001372:	8526                	mv	a0,s1
    80001374:	f6dff0ef          	jal	800012e0 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80001378:	46c5                	li	a3,17
    8000137a:	06ee                	slli	a3,a3,0x1b
    8000137c:	4719                	li	a4,6
    8000137e:	412686b3          	sub	a3,a3,s2
    80001382:	864a                	mv	a2,s2
    80001384:	85ca                	mv	a1,s2
    80001386:	8526                	mv	a0,s1
    80001388:	f59ff0ef          	jal	800012e0 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000138c:	4729                	li	a4,10
    8000138e:	6685                	lui	a3,0x1
    80001390:	00005617          	auipc	a2,0x5
    80001394:	c7060613          	addi	a2,a2,-912 # 80006000 <_trampoline>
    80001398:	040005b7          	lui	a1,0x4000
    8000139c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000139e:	05b2                	slli	a1,a1,0xc
    800013a0:	8526                	mv	a0,s1
    800013a2:	f3fff0ef          	jal	800012e0 <kvmmap>
  proc_mapstacks(kpgtbl);
    800013a6:	8526                	mv	a0,s1
    800013a8:	6a6000ef          	jal	80001a4e <proc_mapstacks>
}
    800013ac:	8526                	mv	a0,s1
    800013ae:	60e2                	ld	ra,24(sp)
    800013b0:	6442                	ld	s0,16(sp)
    800013b2:	64a2                	ld	s1,8(sp)
    800013b4:	6902                	ld	s2,0(sp)
    800013b6:	6105                	addi	sp,sp,32
    800013b8:	8082                	ret

00000000800013ba <kvminit>:
{
    800013ba:	1141                	addi	sp,sp,-16
    800013bc:	e406                	sd	ra,8(sp)
    800013be:	e022                	sd	s0,0(sp)
    800013c0:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800013c2:	f47ff0ef          	jal	80001308 <kvmmake>
    800013c6:	00009797          	auipc	a5,0x9
    800013ca:	06a7b923          	sd	a0,114(a5) # 8000a438 <kernel_pagetable>
}
    800013ce:	60a2                	ld	ra,8(sp)
    800013d0:	6402                	ld	s0,0(sp)
    800013d2:	0141                	addi	sp,sp,16
    800013d4:	8082                	ret

00000000800013d6 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800013d6:	1101                	addi	sp,sp,-32
    800013d8:	ec06                	sd	ra,24(sp)
    800013da:	e822                	sd	s0,16(sp)
    800013dc:	e426                	sd	s1,8(sp)
    800013de:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    800013e0:	86bff0ef          	jal	80000c4a <kalloc>
    800013e4:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800013e6:	c509                	beqz	a0,800013f0 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800013e8:	6605                	lui	a2,0x1
    800013ea:	4581                	li	a1,0
    800013ec:	af5ff0ef          	jal	80000ee0 <memset>
  return pagetable;
}
    800013f0:	8526                	mv	a0,s1
    800013f2:	60e2                	ld	ra,24(sp)
    800013f4:	6442                	ld	s0,16(sp)
    800013f6:	64a2                	ld	s1,8(sp)
    800013f8:	6105                	addi	sp,sp,32
    800013fa:	8082                	ret

00000000800013fc <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800013fc:	7139                	addi	sp,sp,-64
    800013fe:	fc06                	sd	ra,56(sp)
    80001400:	f822                	sd	s0,48(sp)
    80001402:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001404:	03459793          	slli	a5,a1,0x34
    80001408:	e38d                	bnez	a5,8000142a <uvmunmap+0x2e>
    8000140a:	f04a                	sd	s2,32(sp)
    8000140c:	ec4e                	sd	s3,24(sp)
    8000140e:	e852                	sd	s4,16(sp)
    80001410:	e456                	sd	s5,8(sp)
    80001412:	e05a                	sd	s6,0(sp)
    80001414:	8a2a                	mv	s4,a0
    80001416:	892e                	mv	s2,a1
    80001418:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000141a:	0632                	slli	a2,a2,0xc
    8000141c:	00b609b3          	add	s3,a2,a1
    80001420:	6b05                	lui	s6,0x1
    80001422:	0535f963          	bgeu	a1,s3,80001474 <uvmunmap+0x78>
    80001426:	f426                	sd	s1,40(sp)
    80001428:	a015                	j	8000144c <uvmunmap+0x50>
    8000142a:	f426                	sd	s1,40(sp)
    8000142c:	f04a                	sd	s2,32(sp)
    8000142e:	ec4e                	sd	s3,24(sp)
    80001430:	e852                	sd	s4,16(sp)
    80001432:	e456                	sd	s5,8(sp)
    80001434:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001436:	00006517          	auipc	a0,0x6
    8000143a:	e4a50513          	addi	a0,a0,-438 # 80007280 <etext+0x280>
    8000143e:	ba2ff0ef          	jal	800007e0 <panic>
      // Phase 2: pages may be shared (COW), so drop a reference
      // instead of unconditionally freeing; decref() only calls
      // kfree() once the refcount actually reaches zero.
      decref(pa);
    }
    *pte = 0;
    80001442:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001446:	995a                	add	s2,s2,s6
    80001448:	03397563          	bgeu	s2,s3,80001472 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000144c:	4601                	li	a2,0
    8000144e:	85ca                	mv	a1,s2
    80001450:	8552                	mv	a0,s4
    80001452:	d07ff0ef          	jal	80001158 <walk>
    80001456:	84aa                	mv	s1,a0
    80001458:	d57d                	beqz	a0,80001446 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    8000145a:	611c                	ld	a5,0(a0)
    8000145c:	0017f713          	andi	a4,a5,1
    80001460:	d37d                	beqz	a4,80001446 <uvmunmap+0x4a>
    if(do_free){
    80001462:	fe0a80e3          	beqz	s5,80001442 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001466:	83a9                	srli	a5,a5,0xa
      decref(pa);
    80001468:	00c79513          	slli	a0,a5,0xc
    8000146c:	ed0ff0ef          	jal	80000b3c <decref>
    80001470:	bfc9                	j	80001442 <uvmunmap+0x46>
    80001472:	74a2                	ld	s1,40(sp)
    80001474:	7902                	ld	s2,32(sp)
    80001476:	69e2                	ld	s3,24(sp)
    80001478:	6a42                	ld	s4,16(sp)
    8000147a:	6aa2                	ld	s5,8(sp)
    8000147c:	6b02                	ld	s6,0(sp)
  }
}
    8000147e:	70e2                	ld	ra,56(sp)
    80001480:	7442                	ld	s0,48(sp)
    80001482:	6121                	addi	sp,sp,64
    80001484:	8082                	ret

0000000080001486 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001486:	1101                	addi	sp,sp,-32
    80001488:	ec06                	sd	ra,24(sp)
    8000148a:	e822                	sd	s0,16(sp)
    8000148c:	e426                	sd	s1,8(sp)
    8000148e:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80001490:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    80001492:	00b67d63          	bgeu	a2,a1,800014ac <uvmdealloc+0x26>
    80001496:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001498:	6785                	lui	a5,0x1
    8000149a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000149c:	00f60733          	add	a4,a2,a5
    800014a0:	76fd                	lui	a3,0xfffff
    800014a2:	8f75                	and	a4,a4,a3
    800014a4:	97ae                	add	a5,a5,a1
    800014a6:	8ff5                	and	a5,a5,a3
    800014a8:	00f76863          	bltu	a4,a5,800014b8 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800014ac:	8526                	mv	a0,s1
    800014ae:	60e2                	ld	ra,24(sp)
    800014b0:	6442                	ld	s0,16(sp)
    800014b2:	64a2                	ld	s1,8(sp)
    800014b4:	6105                	addi	sp,sp,32
    800014b6:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800014b8:	8f99                	sub	a5,a5,a4
    800014ba:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800014bc:	4685                	li	a3,1
    800014be:	0007861b          	sext.w	a2,a5
    800014c2:	85ba                	mv	a1,a4
    800014c4:	f39ff0ef          	jal	800013fc <uvmunmap>
    800014c8:	b7d5                	j	800014ac <uvmdealloc+0x26>

00000000800014ca <uvmalloc>:
  if(newsz < oldsz)
    800014ca:	08b66f63          	bltu	a2,a1,80001568 <uvmalloc+0x9e>
{
    800014ce:	7139                	addi	sp,sp,-64
    800014d0:	fc06                	sd	ra,56(sp)
    800014d2:	f822                	sd	s0,48(sp)
    800014d4:	ec4e                	sd	s3,24(sp)
    800014d6:	e852                	sd	s4,16(sp)
    800014d8:	e456                	sd	s5,8(sp)
    800014da:	0080                	addi	s0,sp,64
    800014dc:	8aaa                	mv	s5,a0
    800014de:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800014e0:	6785                	lui	a5,0x1
    800014e2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800014e4:	95be                	add	a1,a1,a5
    800014e6:	77fd                	lui	a5,0xfffff
    800014e8:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    800014ec:	08c9f063          	bgeu	s3,a2,8000156c <uvmalloc+0xa2>
    800014f0:	f426                	sd	s1,40(sp)
    800014f2:	f04a                	sd	s2,32(sp)
    800014f4:	e05a                	sd	s6,0(sp)
    800014f6:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800014f8:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800014fc:	f4eff0ef          	jal	80000c4a <kalloc>
    80001500:	84aa                	mv	s1,a0
    if(mem == 0){
    80001502:	c515                	beqz	a0,8000152e <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    80001504:	6605                	lui	a2,0x1
    80001506:	4581                	li	a1,0
    80001508:	9d9ff0ef          	jal	80000ee0 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000150c:	875a                	mv	a4,s6
    8000150e:	86a6                	mv	a3,s1
    80001510:	6605                	lui	a2,0x1
    80001512:	85ca                	mv	a1,s2
    80001514:	8556                	mv	a0,s5
    80001516:	d1bff0ef          	jal	80001230 <mappages>
    8000151a:	e915                	bnez	a0,8000154e <uvmalloc+0x84>
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000151c:	6785                	lui	a5,0x1
    8000151e:	993e                	add	s2,s2,a5
    80001520:	fd496ee3          	bltu	s2,s4,800014fc <uvmalloc+0x32>
  return newsz;
    80001524:	8552                	mv	a0,s4
    80001526:	74a2                	ld	s1,40(sp)
    80001528:	7902                	ld	s2,32(sp)
    8000152a:	6b02                	ld	s6,0(sp)
    8000152c:	a811                	j	80001540 <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    8000152e:	864e                	mv	a2,s3
    80001530:	85ca                	mv	a1,s2
    80001532:	8556                	mv	a0,s5
    80001534:	f53ff0ef          	jal	80001486 <uvmdealloc>
      return 0;
    80001538:	4501                	li	a0,0
    8000153a:	74a2                	ld	s1,40(sp)
    8000153c:	7902                	ld	s2,32(sp)
    8000153e:	6b02                	ld	s6,0(sp)
}
    80001540:	70e2                	ld	ra,56(sp)
    80001542:	7442                	ld	s0,48(sp)
    80001544:	69e2                	ld	s3,24(sp)
    80001546:	6a42                	ld	s4,16(sp)
    80001548:	6aa2                	ld	s5,8(sp)
    8000154a:	6121                	addi	sp,sp,64
    8000154c:	8082                	ret
      kfree(mem);
    8000154e:	8526                	mv	a0,s1
    80001550:	d7aff0ef          	jal	80000aca <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001554:	864e                	mv	a2,s3
    80001556:	85ca                	mv	a1,s2
    80001558:	8556                	mv	a0,s5
    8000155a:	f2dff0ef          	jal	80001486 <uvmdealloc>
      return 0;
    8000155e:	4501                	li	a0,0
    80001560:	74a2                	ld	s1,40(sp)
    80001562:	7902                	ld	s2,32(sp)
    80001564:	6b02                	ld	s6,0(sp)
    80001566:	bfe9                	j	80001540 <uvmalloc+0x76>
    return oldsz;
    80001568:	852e                	mv	a0,a1
}
    8000156a:	8082                	ret
  return newsz;
    8000156c:	8532                	mv	a0,a2
    8000156e:	bfc9                	j	80001540 <uvmalloc+0x76>

0000000080001570 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001570:	7179                	addi	sp,sp,-48
    80001572:	f406                	sd	ra,40(sp)
    80001574:	f022                	sd	s0,32(sp)
    80001576:	ec26                	sd	s1,24(sp)
    80001578:	e84a                	sd	s2,16(sp)
    8000157a:	e44e                	sd	s3,8(sp)
    8000157c:	e052                	sd	s4,0(sp)
    8000157e:	1800                	addi	s0,sp,48
    80001580:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80001582:	84aa                	mv	s1,a0
    80001584:	6905                	lui	s2,0x1
    80001586:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001588:	4985                	li	s3,1
    8000158a:	a819                	j	800015a0 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    8000158c:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    8000158e:	00c79513          	slli	a0,a5,0xc
    80001592:	fdfff0ef          	jal	80001570 <freewalk>
      pagetable[i] = 0;
    80001596:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    8000159a:	04a1                	addi	s1,s1,8
    8000159c:	01248f63          	beq	s1,s2,800015ba <freewalk+0x4a>
    pte_t pte = pagetable[i];
    800015a0:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800015a2:	00f7f713          	andi	a4,a5,15
    800015a6:	ff3703e3          	beq	a4,s3,8000158c <freewalk+0x1c>
    } else if(pte & PTE_V){
    800015aa:	8b85                	andi	a5,a5,1
    800015ac:	d7fd                	beqz	a5,8000159a <freewalk+0x2a>
      panic("freewalk: leaf");
    800015ae:	00006517          	auipc	a0,0x6
    800015b2:	cea50513          	addi	a0,a0,-790 # 80007298 <etext+0x298>
    800015b6:	a2aff0ef          	jal	800007e0 <panic>
    }
  }
  kfree((void*)pagetable);
    800015ba:	8552                	mv	a0,s4
    800015bc:	d0eff0ef          	jal	80000aca <kfree>
}
    800015c0:	70a2                	ld	ra,40(sp)
    800015c2:	7402                	ld	s0,32(sp)
    800015c4:	64e2                	ld	s1,24(sp)
    800015c6:	6942                	ld	s2,16(sp)
    800015c8:	69a2                	ld	s3,8(sp)
    800015ca:	6a02                	ld	s4,0(sp)
    800015cc:	6145                	addi	sp,sp,48
    800015ce:	8082                	ret

00000000800015d0 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800015d0:	1101                	addi	sp,sp,-32
    800015d2:	ec06                	sd	ra,24(sp)
    800015d4:	e822                	sd	s0,16(sp)
    800015d6:	e426                	sd	s1,8(sp)
    800015d8:	1000                	addi	s0,sp,32
    800015da:	84aa                	mv	s1,a0
  if(sz > 0)
    800015dc:	e989                	bnez	a1,800015ee <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800015de:	8526                	mv	a0,s1
    800015e0:	f91ff0ef          	jal	80001570 <freewalk>
}
    800015e4:	60e2                	ld	ra,24(sp)
    800015e6:	6442                	ld	s0,16(sp)
    800015e8:	64a2                	ld	s1,8(sp)
    800015ea:	6105                	addi	sp,sp,32
    800015ec:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800015ee:	6785                	lui	a5,0x1
    800015f0:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800015f2:	95be                	add	a1,a1,a5
    800015f4:	4685                	li	a3,1
    800015f6:	00c5d613          	srli	a2,a1,0xc
    800015fa:	4581                	li	a1,0
    800015fc:	e01ff0ef          	jal	800013fc <uvmunmap>
    80001600:	bff9                	j	800015de <uvmfree+0xe>

0000000080001602 <uvmcopy>:
{
  pte_t *pte;
  uint64 pa, i;
  uint flags;

  for(i = 0; i < sz; i += PGSIZE){
    80001602:	ca41                	beqz	a2,80001692 <uvmcopy+0x90>
{
    80001604:	7139                	addi	sp,sp,-64
    80001606:	fc06                	sd	ra,56(sp)
    80001608:	f822                	sd	s0,48(sp)
    8000160a:	f426                	sd	s1,40(sp)
    8000160c:	f04a                	sd	s2,32(sp)
    8000160e:	ec4e                	sd	s3,24(sp)
    80001610:	e852                	sd	s4,16(sp)
    80001612:	e456                	sd	s5,8(sp)
    80001614:	0080                	addi	s0,sp,64
    80001616:	8a2a                	mv	s4,a0
    80001618:	8aae                	mv	s5,a1
    8000161a:	89b2                	mv	s3,a2
  for(i = 0; i < sz; i += PGSIZE){
    8000161c:	4481                	li	s1,0
    8000161e:	a015                	j	80001642 <uvmcopy+0x40>
    // (e.g. read-only text) can just be shared as-is, no COW needed.
    if(*pte & PTE_W){
      *pte &= ~PTE_W;
      *pte |= PTE_COW;
    }
    flags = PTE_FLAGS(*pte);
    80001620:	6118                	ld	a4,0(a0)

    if(mappages(new, i, PGSIZE, pa, flags) != 0){
    80001622:	3ff77713          	andi	a4,a4,1023
    80001626:	86ca                	mv	a3,s2
    80001628:	6605                	lui	a2,0x1
    8000162a:	85a6                	mv	a1,s1
    8000162c:	8556                	mv	a0,s5
    8000162e:	c03ff0ef          	jal	80001230 <mappages>
    80001632:	ed0d                	bnez	a0,8000166c <uvmcopy+0x6a>
      goto err;
    }
    incref(pa);
    80001634:	854a                	mv	a0,s2
    80001636:	be6ff0ef          	jal	80000a1c <incref>
  for(i = 0; i < sz; i += PGSIZE){
    8000163a:	6785                	lui	a5,0x1
    8000163c:	94be                	add	s1,s1,a5
    8000163e:	0534f063          	bgeu	s1,s3,8000167e <uvmcopy+0x7c>
    if((pte = walk(old, i, 0)) == 0)
    80001642:	4601                	li	a2,0
    80001644:	85a6                	mv	a1,s1
    80001646:	8552                	mv	a0,s4
    80001648:	b11ff0ef          	jal	80001158 <walk>
    8000164c:	d57d                	beqz	a0,8000163a <uvmcopy+0x38>
    if((*pte & PTE_V) == 0)
    8000164e:	611c                	ld	a5,0(a0)
    80001650:	0017f713          	andi	a4,a5,1
    80001654:	d37d                	beqz	a4,8000163a <uvmcopy+0x38>
    pa = PTE2PA(*pte);
    80001656:	00a7d913          	srli	s2,a5,0xa
    8000165a:	0932                	slli	s2,s2,0xc
    if(*pte & PTE_W){
    8000165c:	0047f713          	andi	a4,a5,4
    80001660:	d361                	beqz	a4,80001620 <uvmcopy+0x1e>
      *pte &= ~PTE_W;
    80001662:	9bed                	andi	a5,a5,-5
      *pte |= PTE_COW;
    80001664:	1007e793          	ori	a5,a5,256
    80001668:	e11c                	sd	a5,0(a0)
    8000166a:	bf5d                	j	80001620 <uvmcopy+0x1e>
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000166c:	4685                	li	a3,1
    8000166e:	00c4d613          	srli	a2,s1,0xc
    80001672:	4581                	li	a1,0
    80001674:	8556                	mv	a0,s5
    80001676:	d87ff0ef          	jal	800013fc <uvmunmap>
  return -1;
    8000167a:	557d                	li	a0,-1
    8000167c:	a011                	j	80001680 <uvmcopy+0x7e>
  return 0;
    8000167e:	4501                	li	a0,0
}
    80001680:	70e2                	ld	ra,56(sp)
    80001682:	7442                	ld	s0,48(sp)
    80001684:	74a2                	ld	s1,40(sp)
    80001686:	7902                	ld	s2,32(sp)
    80001688:	69e2                	ld	s3,24(sp)
    8000168a:	6a42                	ld	s4,16(sp)
    8000168c:	6aa2                	ld	s5,8(sp)
    8000168e:	6121                	addi	sp,sp,64
    80001690:	8082                	ret
  return 0;
    80001692:	4501                	li	a0,0
}
    80001694:	8082                	ret

0000000080001696 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001696:	1141                	addi	sp,sp,-16
    80001698:	e406                	sd	ra,8(sp)
    8000169a:	e022                	sd	s0,0(sp)
    8000169c:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    8000169e:	4601                	li	a2,0
    800016a0:	ab9ff0ef          	jal	80001158 <walk>
  if(pte == 0)
    800016a4:	c901                	beqz	a0,800016b4 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800016a6:	611c                	ld	a5,0(a0)
    800016a8:	9bbd                	andi	a5,a5,-17
    800016aa:	e11c                	sd	a5,0(a0)
}
    800016ac:	60a2                	ld	ra,8(sp)
    800016ae:	6402                	ld	s0,0(sp)
    800016b0:	0141                	addi	sp,sp,16
    800016b2:	8082                	ret
    panic("uvmclear");
    800016b4:	00006517          	auipc	a0,0x6
    800016b8:	bf450513          	addi	a0,a0,-1036 # 800072a8 <etext+0x2a8>
    800016bc:	924ff0ef          	jal	800007e0 <panic>

00000000800016c0 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800016c0:	c6dd                	beqz	a3,8000176e <copyinstr+0xae>
{
    800016c2:	715d                	addi	sp,sp,-80
    800016c4:	e486                	sd	ra,72(sp)
    800016c6:	e0a2                	sd	s0,64(sp)
    800016c8:	fc26                	sd	s1,56(sp)
    800016ca:	f84a                	sd	s2,48(sp)
    800016cc:	f44e                	sd	s3,40(sp)
    800016ce:	f052                	sd	s4,32(sp)
    800016d0:	ec56                	sd	s5,24(sp)
    800016d2:	e85a                	sd	s6,16(sp)
    800016d4:	e45e                	sd	s7,8(sp)
    800016d6:	0880                	addi	s0,sp,80
    800016d8:	8a2a                	mv	s4,a0
    800016da:	8b2e                	mv	s6,a1
    800016dc:	8bb2                	mv	s7,a2
    800016de:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    800016e0:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800016e2:	6985                	lui	s3,0x1
    800016e4:	a825                	j	8000171c <copyinstr+0x5c>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800016e6:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800016ea:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800016ec:	37fd                	addiw	a5,a5,-1
    800016ee:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800016f2:	60a6                	ld	ra,72(sp)
    800016f4:	6406                	ld	s0,64(sp)
    800016f6:	74e2                	ld	s1,56(sp)
    800016f8:	7942                	ld	s2,48(sp)
    800016fa:	79a2                	ld	s3,40(sp)
    800016fc:	7a02                	ld	s4,32(sp)
    800016fe:	6ae2                	ld	s5,24(sp)
    80001700:	6b42                	ld	s6,16(sp)
    80001702:	6ba2                	ld	s7,8(sp)
    80001704:	6161                	addi	sp,sp,80
    80001706:	8082                	ret
    80001708:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    8000170c:	9742                	add	a4,a4,a6
      --max;
    8000170e:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    80001712:	01348bb3          	add	s7,s1,s3
  while(got_null == 0 && max > 0){
    80001716:	04e58463          	beq	a1,a4,8000175e <copyinstr+0x9e>
{
    8000171a:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    8000171c:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    80001720:	85a6                	mv	a1,s1
    80001722:	8552                	mv	a0,s4
    80001724:	acfff0ef          	jal	800011f2 <walkaddr>
    if(pa0 == 0)
    80001728:	cd0d                	beqz	a0,80001762 <copyinstr+0xa2>
    n = PGSIZE - (srcva - va0);
    8000172a:	417486b3          	sub	a3,s1,s7
    8000172e:	96ce                	add	a3,a3,s3
    if(n > max)
    80001730:	00d97363          	bgeu	s2,a3,80001736 <copyinstr+0x76>
    80001734:	86ca                	mv	a3,s2
    char *p = (char *) (pa0 + (srcva - va0));
    80001736:	955e                	add	a0,a0,s7
    80001738:	8d05                	sub	a0,a0,s1
    while(n > 0){
    8000173a:	c695                	beqz	a3,80001766 <copyinstr+0xa6>
    8000173c:	87da                	mv	a5,s6
    8000173e:	885a                	mv	a6,s6
      if(*p == '\0'){
    80001740:	41650633          	sub	a2,a0,s6
    while(n > 0){
    80001744:	96da                	add	a3,a3,s6
    80001746:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001748:	00f60733          	add	a4,a2,a5
    8000174c:	00074703          	lbu	a4,0(a4)
    80001750:	db59                	beqz	a4,800016e6 <copyinstr+0x26>
        *dst = *p;
    80001752:	00e78023          	sb	a4,0(a5)
      dst++;
    80001756:	0785                	addi	a5,a5,1
    while(n > 0){
    80001758:	fed797e3          	bne	a5,a3,80001746 <copyinstr+0x86>
    8000175c:	b775                	j	80001708 <copyinstr+0x48>
    8000175e:	4781                	li	a5,0
    80001760:	b771                	j	800016ec <copyinstr+0x2c>
      return -1;
    80001762:	557d                	li	a0,-1
    80001764:	b779                	j	800016f2 <copyinstr+0x32>
    srcva = va0 + PGSIZE;
    80001766:	6b85                	lui	s7,0x1
    80001768:	9ba6                	add	s7,s7,s1
    8000176a:	87da                	mv	a5,s6
    8000176c:	b77d                	j	8000171a <copyinstr+0x5a>
  int got_null = 0;
    8000176e:	4781                	li	a5,0
  if(got_null){
    80001770:	37fd                	addiw	a5,a5,-1
    80001772:	0007851b          	sext.w	a0,a5
}
    80001776:	8082                	ret

0000000080001778 <vmfault>:
//
// returns 0 on failure (invalid va, or out of memory), and the
// physical address of the now-usable page on success.
uint64
vmfault(pagetable_t pagetable, uint64 va, int read)
{
    80001778:	7139                	addi	sp,sp,-64
    8000177a:	fc06                	sd	ra,56(sp)
    8000177c:	f822                	sd	s0,48(sp)
    8000177e:	f426                	sd	s1,40(sp)
    80001780:	ec4e                	sd	s3,24(sp)
    80001782:	e456                	sd	s5,8(sp)
    80001784:	0080                	addi	s0,sp,64
    80001786:	89aa                	mv	s3,a0
    80001788:	84ae                	mv	s1,a1
    8000178a:	8ab2                	mv	s5,a2
  uint64 mem;
  struct proc *p = myproc();
    8000178c:	43c000ef          	jal	80001bc8 <myproc>
  pte_t *pte;
  uint64 pa;
  uint flags;

  if (va >= p->sz)
    80001790:	653c                	ld	a5,72(a0)
    80001792:	00f4eb63          	bltu	s1,a5,800017a8 <vmfault+0x30>
    return 0;
    80001796:	4981                	li	s3,0

  flags = (flags & ~PTE_COW) | PTE_W;
  *pte = PA2PTE(mem) | flags;
  decref(pa);
  return mem;
}
    80001798:	854e                	mv	a0,s3
    8000179a:	70e2                	ld	ra,56(sp)
    8000179c:	7442                	ld	s0,48(sp)
    8000179e:	74a2                	ld	s1,40(sp)
    800017a0:	69e2                	ld	s3,24(sp)
    800017a2:	6aa2                	ld	s5,8(sp)
    800017a4:	6121                	addi	sp,sp,64
    800017a6:	8082                	ret
    800017a8:	f04a                	sd	s2,32(sp)
    800017aa:	e852                	sd	s4,16(sp)
    800017ac:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    800017ae:	77fd                	lui	a5,0xfffff
    800017b0:	8cfd                	and	s1,s1,a5
  pte = walk(pagetable, va, 0);
    800017b2:	4601                	li	a2,0
    800017b4:	85a6                	mv	a1,s1
    800017b6:	854e                	mv	a0,s3
    800017b8:	9a1ff0ef          	jal	80001158 <walk>
    800017bc:	8a2a                	mv	s4,a0
  if(pte == 0 || (*pte & PTE_V) == 0) {
    800017be:	c901                	beqz	a0,800017ce <vmfault+0x56>
    800017c0:	e05a                	sd	s6,0(sp)
    800017c2:	00053b03          	ld	s6,0(a0)
    800017c6:	001b7793          	andi	a5,s6,1
    800017ca:	ef9d                	bnez	a5,80001808 <vmfault+0x90>
    800017cc:	6b02                	ld	s6,0(sp)
    mem = (uint64) kalloc();
    800017ce:	c7cff0ef          	jal	80000c4a <kalloc>
    800017d2:	8a2a                	mv	s4,a0
      return 0;
    800017d4:	4981                	li	s3,0
    if(mem == 0)
    800017d6:	c555                	beqz	a0,80001882 <vmfault+0x10a>
    mem = (uint64) kalloc();
    800017d8:	89aa                	mv	s3,a0
    memset((void *) mem, 0, PGSIZE);
    800017da:	6605                	lui	a2,0x1
    800017dc:	4581                	li	a1,0
    800017de:	f02ff0ef          	jal	80000ee0 <memset>
    if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    800017e2:	4759                	li	a4,22
    800017e4:	86d2                	mv	a3,s4
    800017e6:	6605                	lui	a2,0x1
    800017e8:	85a6                	mv	a1,s1
    800017ea:	05093503          	ld	a0,80(s2)
    800017ee:	a43ff0ef          	jal	80001230 <mappages>
    800017f2:	e501                	bnez	a0,800017fa <vmfault+0x82>
    800017f4:	7902                	ld	s2,32(sp)
    800017f6:	6a42                	ld	s4,16(sp)
    800017f8:	b745                	j	80001798 <vmfault+0x20>
      kfree((void *)mem);
    800017fa:	8552                	mv	a0,s4
    800017fc:	aceff0ef          	jal	80000aca <kfree>
      return 0;
    80001800:	4981                	li	s3,0
    80001802:	7902                	ld	s2,32(sp)
    80001804:	6a42                	ld	s4,16(sp)
    80001806:	bf49                	j	80001798 <vmfault+0x20>
    return 0;
    80001808:	4981                	li	s3,0
  if(read || (*pte & PTE_COW) == 0)
    8000180a:	060a9f63          	bnez	s5,80001888 <vmfault+0x110>
    8000180e:	100b7993          	andi	s3,s6,256
    80001812:	00099663          	bnez	s3,8000181e <vmfault+0xa6>
    80001816:	7902                	ld	s2,32(sp)
    80001818:	6a42                	ld	s4,16(sp)
    8000181a:	6b02                	ld	s6,0(sp)
    8000181c:	bfb5                	j	80001798 <vmfault+0x20>
  pa = PTE2PA(*pte);
    8000181e:	00ab5913          	srli	s2,s6,0xa
    80001822:	0932                	slli	s2,s2,0xc
  if(getref(pa) == 1){
    80001824:	854a                	mv	a0,s2
    80001826:	a52ff0ef          	jal	80000a78 <getref>
    8000182a:	4785                	li	a5,1
    8000182c:	02f50e63          	beq	a0,a5,80001868 <vmfault+0xf0>
  mem = (uint64) kalloc();
    80001830:	c1aff0ef          	jal	80000c4a <kalloc>
    80001834:	84aa                	mv	s1,a0
    return 0;
    80001836:	4981                	li	s3,0
  if(mem == 0)
    80001838:	cd21                	beqz	a0,80001890 <vmfault+0x118>
  mem = (uint64) kalloc();
    8000183a:	89aa                	mv	s3,a0
  memmove((void*)mem, (void*)pa, PGSIZE);
    8000183c:	6605                	lui	a2,0x1
    8000183e:	85ca                	mv	a1,s2
    80001840:	efcff0ef          	jal	80000f3c <memmove>
  *pte = PA2PTE(mem) | flags;
    80001844:	00c4d793          	srli	a5,s1,0xc
    80001848:	07aa                	slli	a5,a5,0xa
    8000184a:	2fbb7b13          	andi	s6,s6,763
    8000184e:	004b6b13          	ori	s6,s6,4
    80001852:	0167e7b3          	or	a5,a5,s6
    80001856:	00fa3023          	sd	a5,0(s4)
  decref(pa);
    8000185a:	854a                	mv	a0,s2
    8000185c:	ae0ff0ef          	jal	80000b3c <decref>
  return mem;
    80001860:	7902                	ld	s2,32(sp)
    80001862:	6a42                	ld	s4,16(sp)
    80001864:	6b02                	ld	s6,0(sp)
    80001866:	bf0d                	j	80001798 <vmfault+0x20>
    *pte = (*pte & ~PTE_COW) | PTE_W;
    80001868:	000a3783          	ld	a5,0(s4)
    8000186c:	efb7f793          	andi	a5,a5,-261
    80001870:	0047e793          	ori	a5,a5,4
    80001874:	00fa3023          	sd	a5,0(s4)
    return pa;
    80001878:	89ca                	mv	s3,s2
    8000187a:	7902                	ld	s2,32(sp)
    8000187c:	6a42                	ld	s4,16(sp)
    8000187e:	6b02                	ld	s6,0(sp)
    80001880:	bf21                	j	80001798 <vmfault+0x20>
    80001882:	7902                	ld	s2,32(sp)
    80001884:	6a42                	ld	s4,16(sp)
    80001886:	bf09                	j	80001798 <vmfault+0x20>
    80001888:	7902                	ld	s2,32(sp)
    8000188a:	6a42                	ld	s4,16(sp)
    8000188c:	6b02                	ld	s6,0(sp)
    8000188e:	b729                	j	80001798 <vmfault+0x20>
    80001890:	7902                	ld	s2,32(sp)
    80001892:	6a42                	ld	s4,16(sp)
    80001894:	6b02                	ld	s6,0(sp)
    80001896:	b709                	j	80001798 <vmfault+0x20>

0000000080001898 <copyout>:
  while(len > 0){
    80001898:	c2e1                	beqz	a3,80001958 <copyout+0xc0>
{
    8000189a:	7159                	addi	sp,sp,-112
    8000189c:	f486                	sd	ra,104(sp)
    8000189e:	f0a2                	sd	s0,96(sp)
    800018a0:	eca6                	sd	s1,88(sp)
    800018a2:	e0d2                	sd	s4,64(sp)
    800018a4:	f85a                	sd	s6,48(sp)
    800018a6:	f45e                	sd	s7,40(sp)
    800018a8:	f062                	sd	s8,32(sp)
    800018aa:	1880                	addi	s0,sp,112
    800018ac:	8c2a                	mv	s8,a0
    800018ae:	8b2e                	mv	s6,a1
    800018b0:	8bb2                	mv	s7,a2
    800018b2:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800018b4:	74fd                	lui	s1,0xfffff
    800018b6:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    800018b8:	57fd                	li	a5,-1
    800018ba:	83e9                	srli	a5,a5,0x1a
    800018bc:	0a97e063          	bltu	a5,s1,8000195c <copyout+0xc4>
    800018c0:	e8ca                	sd	s2,80(sp)
    800018c2:	e4ce                	sd	s3,72(sp)
    800018c4:	fc56                	sd	s5,56(sp)
    800018c6:	ec66                	sd	s9,24(sp)
    800018c8:	e86a                	sd	s10,16(sp)
    800018ca:	e46e                	sd	s11,8(sp)
    if((*pte & PTE_W) == 0 || (*pte & PTE_U) == 0)
    800018cc:	4d51                	li	s10,20
    800018ce:	6d85                	lui	s11,0x1
    if(va0 >= MAXVA)
    800018d0:	8cbe                	mv	s9,a5
    800018d2:	a035                	j	800018fe <copyout+0x66>
      pa0 = PTE2PA(*pte);
    800018d4:	00a95913          	srli	s2,s2,0xa
    800018d8:	0932                	slli	s2,s2,0xc
    800018da:	a899                	j	80001930 <copyout+0x98>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800018dc:	409b0533          	sub	a0,s6,s1
    800018e0:	0009861b          	sext.w	a2,s3
    800018e4:	85de                	mv	a1,s7
    800018e6:	954a                	add	a0,a0,s2
    800018e8:	e54ff0ef          	jal	80000f3c <memmove>
    len -= n;
    800018ec:	413a0a33          	sub	s4,s4,s3
    src += n;
    800018f0:	9bce                	add	s7,s7,s3
  while(len > 0){
    800018f2:	040a0b63          	beqz	s4,80001948 <copyout+0xb0>
    if(va0 >= MAXVA)
    800018f6:	075ce563          	bltu	s9,s5,80001960 <copyout+0xc8>
    800018fa:	84d6                	mv	s1,s5
    800018fc:	8b56                	mv	s6,s5
    pte = walk(pagetable, va0, 0);
    800018fe:	4601                	li	a2,0
    80001900:	85a6                	mv	a1,s1
    80001902:	8562                	mv	a0,s8
    80001904:	855ff0ef          	jal	80001158 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80001908:	c901                	beqz	a0,80001918 <copyout+0x80>
    8000190a:	00053903          	ld	s2,0(a0)
    8000190e:	01597793          	andi	a5,s2,21
    80001912:	4755                	li	a4,21
    80001914:	fce780e3          	beq	a5,a4,800018d4 <copyout+0x3c>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001918:	4601                	li	a2,0
    8000191a:	85a6                	mv	a1,s1
    8000191c:	8562                	mv	a0,s8
    8000191e:	e5bff0ef          	jal	80001778 <vmfault>
    80001922:	892a                	mv	s2,a0
    80001924:	c531                	beqz	a0,80001970 <copyout+0xd8>
      pte = walk(pagetable, va0, 0);
    80001926:	4601                	li	a2,0
    80001928:	85a6                	mv	a1,s1
    8000192a:	8562                	mv	a0,s8
    8000192c:	82dff0ef          	jal	80001158 <walk>
    if((*pte & PTE_W) == 0 || (*pte & PTE_U) == 0)
    80001930:	611c                	ld	a5,0(a0)
    80001932:	8bd1                	andi	a5,a5,20
    80001934:	05a79663          	bne	a5,s10,80001980 <copyout+0xe8>
    n = PGSIZE - (dstva - va0);
    80001938:	01b48ab3          	add	s5,s1,s11
    8000193c:	416a89b3          	sub	s3,s5,s6
    if(n > len)
    80001940:	f93a7ee3          	bgeu	s4,s3,800018dc <copyout+0x44>
    80001944:	89d2                	mv	s3,s4
    80001946:	bf59                	j	800018dc <copyout+0x44>
  return 0;
    80001948:	4501                	li	a0,0
    8000194a:	6946                	ld	s2,80(sp)
    8000194c:	69a6                	ld	s3,72(sp)
    8000194e:	7ae2                	ld	s5,56(sp)
    80001950:	6ce2                	ld	s9,24(sp)
    80001952:	6d42                	ld	s10,16(sp)
    80001954:	6da2                	ld	s11,8(sp)
    80001956:	a825                	j	8000198e <copyout+0xf6>
    80001958:	4501                	li	a0,0
}
    8000195a:	8082                	ret
      return -1;
    8000195c:	557d                	li	a0,-1
    8000195e:	a805                	j	8000198e <copyout+0xf6>
    80001960:	557d                	li	a0,-1
    80001962:	6946                	ld	s2,80(sp)
    80001964:	69a6                	ld	s3,72(sp)
    80001966:	7ae2                	ld	s5,56(sp)
    80001968:	6ce2                	ld	s9,24(sp)
    8000196a:	6d42                	ld	s10,16(sp)
    8000196c:	6da2                	ld	s11,8(sp)
    8000196e:	a005                	j	8000198e <copyout+0xf6>
        return -1;
    80001970:	557d                	li	a0,-1
    80001972:	6946                	ld	s2,80(sp)
    80001974:	69a6                	ld	s3,72(sp)
    80001976:	7ae2                	ld	s5,56(sp)
    80001978:	6ce2                	ld	s9,24(sp)
    8000197a:	6d42                	ld	s10,16(sp)
    8000197c:	6da2                	ld	s11,8(sp)
    8000197e:	a801                	j	8000198e <copyout+0xf6>
      return -1;
    80001980:	557d                	li	a0,-1
    80001982:	6946                	ld	s2,80(sp)
    80001984:	69a6                	ld	s3,72(sp)
    80001986:	7ae2                	ld	s5,56(sp)
    80001988:	6ce2                	ld	s9,24(sp)
    8000198a:	6d42                	ld	s10,16(sp)
    8000198c:	6da2                	ld	s11,8(sp)
}
    8000198e:	70a6                	ld	ra,104(sp)
    80001990:	7406                	ld	s0,96(sp)
    80001992:	64e6                	ld	s1,88(sp)
    80001994:	6a06                	ld	s4,64(sp)
    80001996:	7b42                	ld	s6,48(sp)
    80001998:	7ba2                	ld	s7,40(sp)
    8000199a:	7c02                	ld	s8,32(sp)
    8000199c:	6165                	addi	sp,sp,112
    8000199e:	8082                	ret

00000000800019a0 <copyin>:
  while(len > 0){
    800019a0:	c6c9                	beqz	a3,80001a2a <copyin+0x8a>
{
    800019a2:	715d                	addi	sp,sp,-80
    800019a4:	e486                	sd	ra,72(sp)
    800019a6:	e0a2                	sd	s0,64(sp)
    800019a8:	fc26                	sd	s1,56(sp)
    800019aa:	f84a                	sd	s2,48(sp)
    800019ac:	f44e                	sd	s3,40(sp)
    800019ae:	f052                	sd	s4,32(sp)
    800019b0:	ec56                	sd	s5,24(sp)
    800019b2:	e85a                	sd	s6,16(sp)
    800019b4:	e45e                	sd	s7,8(sp)
    800019b6:	e062                	sd	s8,0(sp)
    800019b8:	0880                	addi	s0,sp,80
    800019ba:	8baa                	mv	s7,a0
    800019bc:	8aae                	mv	s5,a1
    800019be:	8932                	mv	s2,a2
    800019c0:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);    // Removes the offset
    800019c2:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800019c4:	6b05                	lui	s6,0x1
    800019c6:	a035                	j	800019f2 <copyin+0x52>
    800019c8:	412984b3          	sub	s1,s3,s2
    800019cc:	94da                	add	s1,s1,s6
    if(n > len)
    800019ce:	009a7363          	bgeu	s4,s1,800019d4 <copyin+0x34>
    800019d2:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800019d4:	413905b3          	sub	a1,s2,s3
    800019d8:	0004861b          	sext.w	a2,s1
    800019dc:	95aa                	add	a1,a1,a0
    800019de:	8556                	mv	a0,s5
    800019e0:	d5cff0ef          	jal	80000f3c <memmove>
    len -= n;
    800019e4:	409a0a33          	sub	s4,s4,s1
    dst += n;
    800019e8:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    800019ea:	01698933          	add	s2,s3,s6
  while(len > 0){
    800019ee:	020a0163          	beqz	s4,80001a10 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);    // Removes the offset
    800019f2:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);    // Returns the physical page address (Flags are already removed)
    800019f6:	85ce                	mv	a1,s3
    800019f8:	855e                	mv	a0,s7
    800019fa:	ff8ff0ef          	jal	800011f2 <walkaddr>
    if(pa0 == 0) {
    800019fe:	f569                	bnez	a0,800019c8 <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001a00:	4601                	li	a2,0
    80001a02:	85ce                	mv	a1,s3
    80001a04:	855e                	mv	a0,s7
    80001a06:	d73ff0ef          	jal	80001778 <vmfault>
    80001a0a:	fd5d                	bnez	a0,800019c8 <copyin+0x28>
        return -1;
    80001a0c:	557d                	li	a0,-1
    80001a0e:	a011                	j	80001a12 <copyin+0x72>
  return 0;
    80001a10:	4501                	li	a0,0
}
    80001a12:	60a6                	ld	ra,72(sp)
    80001a14:	6406                	ld	s0,64(sp)
    80001a16:	74e2                	ld	s1,56(sp)
    80001a18:	7942                	ld	s2,48(sp)
    80001a1a:	79a2                	ld	s3,40(sp)
    80001a1c:	7a02                	ld	s4,32(sp)
    80001a1e:	6ae2                	ld	s5,24(sp)
    80001a20:	6b42                	ld	s6,16(sp)
    80001a22:	6ba2                	ld	s7,8(sp)
    80001a24:	6c02                	ld	s8,0(sp)
    80001a26:	6161                	addi	sp,sp,80
    80001a28:	8082                	ret
  return 0;
    80001a2a:	4501                	li	a0,0
}
    80001a2c:	8082                	ret

0000000080001a2e <ismapped>:

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001a2e:	1141                	addi	sp,sp,-16
    80001a30:	e406                	sd	ra,8(sp)
    80001a32:	e022                	sd	s0,0(sp)
    80001a34:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001a36:	4601                	li	a2,0
    80001a38:	f20ff0ef          	jal	80001158 <walk>
  if (pte == 0) {
    80001a3c:	c519                	beqz	a0,80001a4a <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    80001a3e:	6108                	ld	a0,0(a0)
    80001a40:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001a42:	60a2                	ld	ra,8(sp)
    80001a44:	6402                	ld	s0,0(sp)
    80001a46:	0141                	addi	sp,sp,16
    80001a48:	8082                	ret
    return 0;
    80001a4a:	4501                	li	a0,0
    80001a4c:	bfdd                	j	80001a42 <ismapped+0x14>

0000000080001a4e <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001a4e:	7139                	addi	sp,sp,-64
    80001a50:	fc06                	sd	ra,56(sp)
    80001a52:	f822                	sd	s0,48(sp)
    80001a54:	f426                	sd	s1,40(sp)
    80001a56:	f04a                	sd	s2,32(sp)
    80001a58:	ec4e                	sd	s3,24(sp)
    80001a5a:	e852                	sd	s4,16(sp)
    80001a5c:	e456                	sd	s5,8(sp)
    80001a5e:	e05a                	sd	s6,0(sp)
    80001a60:	0080                	addi	s0,sp,64
    80001a62:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a64:	00031497          	auipc	s1,0x31
    80001a68:	f2c48493          	addi	s1,s1,-212 # 80032990 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80001a6c:	8b26                	mv	s6,s1
    80001a6e:	04fa5937          	lui	s2,0x4fa5
    80001a72:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001a76:	0932                	slli	s2,s2,0xc
    80001a78:	fa590913          	addi	s2,s2,-91
    80001a7c:	0932                	slli	s2,s2,0xc
    80001a7e:	fa590913          	addi	s2,s2,-91
    80001a82:	0932                	slli	s2,s2,0xc
    80001a84:	fa590913          	addi	s2,s2,-91
    80001a88:	040009b7          	lui	s3,0x4000
    80001a8c:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001a8e:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a90:	00037a97          	auipc	s5,0x37
    80001a94:	900a8a93          	addi	s5,s5,-1792 # 80038390 <tickslock>
    char *pa = kalloc();
    80001a98:	9b2ff0ef          	jal	80000c4a <kalloc>
    80001a9c:	862a                	mv	a2,a0
    if(pa == 0)
    80001a9e:	cd15                	beqz	a0,80001ada <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int) (p - proc));
    80001aa0:	416485b3          	sub	a1,s1,s6
    80001aa4:	858d                	srai	a1,a1,0x3
    80001aa6:	032585b3          	mul	a1,a1,s2
    80001aaa:	2585                	addiw	a1,a1,1
    80001aac:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001ab0:	4719                	li	a4,6
    80001ab2:	6685                	lui	a3,0x1
    80001ab4:	40b985b3          	sub	a1,s3,a1
    80001ab8:	8552                	mv	a0,s4
    80001aba:	827ff0ef          	jal	800012e0 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001abe:	16848493          	addi	s1,s1,360
    80001ac2:	fd549be3          	bne	s1,s5,80001a98 <proc_mapstacks+0x4a>
  }
}
    80001ac6:	70e2                	ld	ra,56(sp)
    80001ac8:	7442                	ld	s0,48(sp)
    80001aca:	74a2                	ld	s1,40(sp)
    80001acc:	7902                	ld	s2,32(sp)
    80001ace:	69e2                	ld	s3,24(sp)
    80001ad0:	6a42                	ld	s4,16(sp)
    80001ad2:	6aa2                	ld	s5,8(sp)
    80001ad4:	6b02                	ld	s6,0(sp)
    80001ad6:	6121                	addi	sp,sp,64
    80001ad8:	8082                	ret
      panic("kalloc");
    80001ada:	00005517          	auipc	a0,0x5
    80001ade:	7de50513          	addi	a0,a0,2014 # 800072b8 <etext+0x2b8>
    80001ae2:	cfffe0ef          	jal	800007e0 <panic>

0000000080001ae6 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001ae6:	7139                	addi	sp,sp,-64
    80001ae8:	fc06                	sd	ra,56(sp)
    80001aea:	f822                	sd	s0,48(sp)
    80001aec:	f426                	sd	s1,40(sp)
    80001aee:	f04a                	sd	s2,32(sp)
    80001af0:	ec4e                	sd	s3,24(sp)
    80001af2:	e852                	sd	s4,16(sp)
    80001af4:	e456                	sd	s5,8(sp)
    80001af6:	e05a                	sd	s6,0(sp)
    80001af8:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001afa:	00005597          	auipc	a1,0x5
    80001afe:	7c658593          	addi	a1,a1,1990 # 800072c0 <etext+0x2c0>
    80001b02:	00031517          	auipc	a0,0x31
    80001b06:	a5e50513          	addi	a0,a0,-1442 # 80032560 <pid_lock>
    80001b0a:	a82ff0ef          	jal	80000d8c <initlock>
  initlock(&wait_lock, "wait_lock");
    80001b0e:	00005597          	auipc	a1,0x5
    80001b12:	7ba58593          	addi	a1,a1,1978 # 800072c8 <etext+0x2c8>
    80001b16:	00031517          	auipc	a0,0x31
    80001b1a:	a6250513          	addi	a0,a0,-1438 # 80032578 <wait_lock>
    80001b1e:	a6eff0ef          	jal	80000d8c <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b22:	00031497          	auipc	s1,0x31
    80001b26:	e6e48493          	addi	s1,s1,-402 # 80032990 <proc>
      initlock(&p->lock, "proc");
    80001b2a:	00005b17          	auipc	s6,0x5
    80001b2e:	7aeb0b13          	addi	s6,s6,1966 # 800072d8 <etext+0x2d8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001b32:	8aa6                	mv	s5,s1
    80001b34:	04fa5937          	lui	s2,0x4fa5
    80001b38:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001b3c:	0932                	slli	s2,s2,0xc
    80001b3e:	fa590913          	addi	s2,s2,-91
    80001b42:	0932                	slli	s2,s2,0xc
    80001b44:	fa590913          	addi	s2,s2,-91
    80001b48:	0932                	slli	s2,s2,0xc
    80001b4a:	fa590913          	addi	s2,s2,-91
    80001b4e:	040009b7          	lui	s3,0x4000
    80001b52:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001b54:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b56:	00037a17          	auipc	s4,0x37
    80001b5a:	83aa0a13          	addi	s4,s4,-1990 # 80038390 <tickslock>
      initlock(&p->lock, "proc");
    80001b5e:	85da                	mv	a1,s6
    80001b60:	8526                	mv	a0,s1
    80001b62:	a2aff0ef          	jal	80000d8c <initlock>
      p->state = UNUSED;
    80001b66:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001b6a:	415487b3          	sub	a5,s1,s5
    80001b6e:	878d                	srai	a5,a5,0x3
    80001b70:	032787b3          	mul	a5,a5,s2
    80001b74:	2785                	addiw	a5,a5,1 # fffffffffffff001 <end+0xffffffff7ffbb891>
    80001b76:	00d7979b          	slliw	a5,a5,0xd
    80001b7a:	40f987b3          	sub	a5,s3,a5
    80001b7e:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b80:	16848493          	addi	s1,s1,360
    80001b84:	fd449de3          	bne	s1,s4,80001b5e <procinit+0x78>
  }
}
    80001b88:	70e2                	ld	ra,56(sp)
    80001b8a:	7442                	ld	s0,48(sp)
    80001b8c:	74a2                	ld	s1,40(sp)
    80001b8e:	7902                	ld	s2,32(sp)
    80001b90:	69e2                	ld	s3,24(sp)
    80001b92:	6a42                	ld	s4,16(sp)
    80001b94:	6aa2                	ld	s5,8(sp)
    80001b96:	6b02                	ld	s6,0(sp)
    80001b98:	6121                	addi	sp,sp,64
    80001b9a:	8082                	ret

0000000080001b9c <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001b9c:	1141                	addi	sp,sp,-16
    80001b9e:	e422                	sd	s0,8(sp)
    80001ba0:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001ba2:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001ba4:	2501                	sext.w	a0,a0
    80001ba6:	6422                	ld	s0,8(sp)
    80001ba8:	0141                	addi	sp,sp,16
    80001baa:	8082                	ret

0000000080001bac <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001bac:	1141                	addi	sp,sp,-16
    80001bae:	e422                	sd	s0,8(sp)
    80001bb0:	0800                	addi	s0,sp,16
    80001bb2:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001bb4:	2781                	sext.w	a5,a5
    80001bb6:	079e                	slli	a5,a5,0x7
  return c;
}
    80001bb8:	00031517          	auipc	a0,0x31
    80001bbc:	9d850513          	addi	a0,a0,-1576 # 80032590 <cpus>
    80001bc0:	953e                	add	a0,a0,a5
    80001bc2:	6422                	ld	s0,8(sp)
    80001bc4:	0141                	addi	sp,sp,16
    80001bc6:	8082                	ret

0000000080001bc8 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001bc8:	1101                	addi	sp,sp,-32
    80001bca:	ec06                	sd	ra,24(sp)
    80001bcc:	e822                	sd	s0,16(sp)
    80001bce:	e426                	sd	s1,8(sp)
    80001bd0:	1000                	addi	s0,sp,32
  push_off();
    80001bd2:	9faff0ef          	jal	80000dcc <push_off>
    80001bd6:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001bd8:	2781                	sext.w	a5,a5
    80001bda:	079e                	slli	a5,a5,0x7
    80001bdc:	00031717          	auipc	a4,0x31
    80001be0:	98470713          	addi	a4,a4,-1660 # 80032560 <pid_lock>
    80001be4:	97ba                	add	a5,a5,a4
    80001be6:	7b84                	ld	s1,48(a5)
  pop_off();
    80001be8:	a68ff0ef          	jal	80000e50 <pop_off>
  return p;
}
    80001bec:	8526                	mv	a0,s1
    80001bee:	60e2                	ld	ra,24(sp)
    80001bf0:	6442                	ld	s0,16(sp)
    80001bf2:	64a2                	ld	s1,8(sp)
    80001bf4:	6105                	addi	sp,sp,32
    80001bf6:	8082                	ret

0000000080001bf8 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001bf8:	7179                	addi	sp,sp,-48
    80001bfa:	f406                	sd	ra,40(sp)
    80001bfc:	f022                	sd	s0,32(sp)
    80001bfe:	ec26                	sd	s1,24(sp)
    80001c00:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001c02:	fc7ff0ef          	jal	80001bc8 <myproc>
    80001c06:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001c08:	a9cff0ef          	jal	80000ea4 <release>

  if (first) {
    80001c0c:	00008797          	auipc	a5,0x8
    80001c10:	7e47a783          	lw	a5,2020(a5) # 8000a3f0 <first.1>
    80001c14:	cf8d                	beqz	a5,80001c4e <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001c16:	4505                	li	a0,1
    80001c18:	3d5010ef          	jal	800037ec <fsinit>

    first = 0;
    80001c1c:	00008797          	auipc	a5,0x8
    80001c20:	7c07aa23          	sw	zero,2004(a5) # 8000a3f0 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    80001c24:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001c28:	00005517          	auipc	a0,0x5
    80001c2c:	6b850513          	addi	a0,a0,1720 # 800072e0 <etext+0x2e0>
    80001c30:	fca43823          	sd	a0,-48(s0)
    80001c34:	fc043c23          	sd	zero,-40(s0)
    80001c38:	fd040593          	addi	a1,s0,-48
    80001c3c:	4b1020ef          	jal	800048ec <kexec>
    80001c40:	6cbc                	ld	a5,88(s1)
    80001c42:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001c44:	6cbc                	ld	a5,88(s1)
    80001c46:	7bb8                	ld	a4,112(a5)
    80001c48:	57fd                	li	a5,-1
    80001c4a:	02f70d63          	beq	a4,a5,80001c84 <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001c4e:	2ad000ef          	jal	800026fa <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001c52:	68a8                	ld	a0,80(s1)
    80001c54:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001c56:	04000737          	lui	a4,0x4000
    80001c5a:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001c5c:	0732                	slli	a4,a4,0xc
    80001c5e:	00004797          	auipc	a5,0x4
    80001c62:	43e78793          	addi	a5,a5,1086 # 8000609c <userret>
    80001c66:	00004697          	auipc	a3,0x4
    80001c6a:	39a68693          	addi	a3,a3,922 # 80006000 <_trampoline>
    80001c6e:	8f95                	sub	a5,a5,a3
    80001c70:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001c72:	577d                	li	a4,-1
    80001c74:	177e                	slli	a4,a4,0x3f
    80001c76:	8d59                	or	a0,a0,a4
    80001c78:	9782                	jalr	a5
}
    80001c7a:	70a2                	ld	ra,40(sp)
    80001c7c:	7402                	ld	s0,32(sp)
    80001c7e:	64e2                	ld	s1,24(sp)
    80001c80:	6145                	addi	sp,sp,48
    80001c82:	8082                	ret
      panic("exec");
    80001c84:	00005517          	auipc	a0,0x5
    80001c88:	66450513          	addi	a0,a0,1636 # 800072e8 <etext+0x2e8>
    80001c8c:	b55fe0ef          	jal	800007e0 <panic>

0000000080001c90 <allocpid>:
{
    80001c90:	1101                	addi	sp,sp,-32
    80001c92:	ec06                	sd	ra,24(sp)
    80001c94:	e822                	sd	s0,16(sp)
    80001c96:	e426                	sd	s1,8(sp)
    80001c98:	e04a                	sd	s2,0(sp)
    80001c9a:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001c9c:	00031917          	auipc	s2,0x31
    80001ca0:	8c490913          	addi	s2,s2,-1852 # 80032560 <pid_lock>
    80001ca4:	854a                	mv	a0,s2
    80001ca6:	966ff0ef          	jal	80000e0c <acquire>
  pid = nextpid;
    80001caa:	00008797          	auipc	a5,0x8
    80001cae:	74a78793          	addi	a5,a5,1866 # 8000a3f4 <nextpid>
    80001cb2:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001cb4:	0014871b          	addiw	a4,s1,1
    80001cb8:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001cba:	854a                	mv	a0,s2
    80001cbc:	9e8ff0ef          	jal	80000ea4 <release>
}
    80001cc0:	8526                	mv	a0,s1
    80001cc2:	60e2                	ld	ra,24(sp)
    80001cc4:	6442                	ld	s0,16(sp)
    80001cc6:	64a2                	ld	s1,8(sp)
    80001cc8:	6902                	ld	s2,0(sp)
    80001cca:	6105                	addi	sp,sp,32
    80001ccc:	8082                	ret

0000000080001cce <proc_pagetable>:
{
    80001cce:	1101                	addi	sp,sp,-32
    80001cd0:	ec06                	sd	ra,24(sp)
    80001cd2:	e822                	sd	s0,16(sp)
    80001cd4:	e426                	sd	s1,8(sp)
    80001cd6:	e04a                	sd	s2,0(sp)
    80001cd8:	1000                	addi	s0,sp,32
    80001cda:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001cdc:	efaff0ef          	jal	800013d6 <uvmcreate>
    80001ce0:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001ce2:	cd05                	beqz	a0,80001d1a <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001ce4:	4729                	li	a4,10
    80001ce6:	00004697          	auipc	a3,0x4
    80001cea:	31a68693          	addi	a3,a3,794 # 80006000 <_trampoline>
    80001cee:	6605                	lui	a2,0x1
    80001cf0:	040005b7          	lui	a1,0x4000
    80001cf4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001cf6:	05b2                	slli	a1,a1,0xc
    80001cf8:	d38ff0ef          	jal	80001230 <mappages>
    80001cfc:	02054663          	bltz	a0,80001d28 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001d00:	4719                	li	a4,6
    80001d02:	05893683          	ld	a3,88(s2)
    80001d06:	6605                	lui	a2,0x1
    80001d08:	020005b7          	lui	a1,0x2000
    80001d0c:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001d0e:	05b6                	slli	a1,a1,0xd
    80001d10:	8526                	mv	a0,s1
    80001d12:	d1eff0ef          	jal	80001230 <mappages>
    80001d16:	00054f63          	bltz	a0,80001d34 <proc_pagetable+0x66>
}
    80001d1a:	8526                	mv	a0,s1
    80001d1c:	60e2                	ld	ra,24(sp)
    80001d1e:	6442                	ld	s0,16(sp)
    80001d20:	64a2                	ld	s1,8(sp)
    80001d22:	6902                	ld	s2,0(sp)
    80001d24:	6105                	addi	sp,sp,32
    80001d26:	8082                	ret
    uvmfree(pagetable, 0);
    80001d28:	4581                	li	a1,0
    80001d2a:	8526                	mv	a0,s1
    80001d2c:	8a5ff0ef          	jal	800015d0 <uvmfree>
    return 0;
    80001d30:	4481                	li	s1,0
    80001d32:	b7e5                	j	80001d1a <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001d34:	4681                	li	a3,0
    80001d36:	4605                	li	a2,1
    80001d38:	040005b7          	lui	a1,0x4000
    80001d3c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001d3e:	05b2                	slli	a1,a1,0xc
    80001d40:	8526                	mv	a0,s1
    80001d42:	ebaff0ef          	jal	800013fc <uvmunmap>
    uvmfree(pagetable, 0);
    80001d46:	4581                	li	a1,0
    80001d48:	8526                	mv	a0,s1
    80001d4a:	887ff0ef          	jal	800015d0 <uvmfree>
    return 0;
    80001d4e:	4481                	li	s1,0
    80001d50:	b7e9                	j	80001d1a <proc_pagetable+0x4c>

0000000080001d52 <proc_freepagetable>:
{
    80001d52:	1101                	addi	sp,sp,-32
    80001d54:	ec06                	sd	ra,24(sp)
    80001d56:	e822                	sd	s0,16(sp)
    80001d58:	e426                	sd	s1,8(sp)
    80001d5a:	e04a                	sd	s2,0(sp)
    80001d5c:	1000                	addi	s0,sp,32
    80001d5e:	84aa                	mv	s1,a0
    80001d60:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001d62:	4681                	li	a3,0
    80001d64:	4605                	li	a2,1
    80001d66:	040005b7          	lui	a1,0x4000
    80001d6a:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001d6c:	05b2                	slli	a1,a1,0xc
    80001d6e:	e8eff0ef          	jal	800013fc <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001d72:	4681                	li	a3,0
    80001d74:	4605                	li	a2,1
    80001d76:	020005b7          	lui	a1,0x2000
    80001d7a:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001d7c:	05b6                	slli	a1,a1,0xd
    80001d7e:	8526                	mv	a0,s1
    80001d80:	e7cff0ef          	jal	800013fc <uvmunmap>
  uvmfree(pagetable, sz);
    80001d84:	85ca                	mv	a1,s2
    80001d86:	8526                	mv	a0,s1
    80001d88:	849ff0ef          	jal	800015d0 <uvmfree>
}
    80001d8c:	60e2                	ld	ra,24(sp)
    80001d8e:	6442                	ld	s0,16(sp)
    80001d90:	64a2                	ld	s1,8(sp)
    80001d92:	6902                	ld	s2,0(sp)
    80001d94:	6105                	addi	sp,sp,32
    80001d96:	8082                	ret

0000000080001d98 <freeproc>:
{
    80001d98:	1101                	addi	sp,sp,-32
    80001d9a:	ec06                	sd	ra,24(sp)
    80001d9c:	e822                	sd	s0,16(sp)
    80001d9e:	e426                	sd	s1,8(sp)
    80001da0:	1000                	addi	s0,sp,32
    80001da2:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001da4:	6d28                	ld	a0,88(a0)
    80001da6:	c119                	beqz	a0,80001dac <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001da8:	d23fe0ef          	jal	80000aca <kfree>
  p->trapframe = 0;
    80001dac:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001db0:	68a8                	ld	a0,80(s1)
    80001db2:	c501                	beqz	a0,80001dba <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001db4:	64ac                	ld	a1,72(s1)
    80001db6:	f9dff0ef          	jal	80001d52 <proc_freepagetable>
  p->pagetable = 0;
    80001dba:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001dbe:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001dc2:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001dc6:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001dca:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001dce:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001dd2:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001dd6:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001dda:	0004ac23          	sw	zero,24(s1)
}
    80001dde:	60e2                	ld	ra,24(sp)
    80001de0:	6442                	ld	s0,16(sp)
    80001de2:	64a2                	ld	s1,8(sp)
    80001de4:	6105                	addi	sp,sp,32
    80001de6:	8082                	ret

0000000080001de8 <allocproc>:
{
    80001de8:	1101                	addi	sp,sp,-32
    80001dea:	ec06                	sd	ra,24(sp)
    80001dec:	e822                	sd	s0,16(sp)
    80001dee:	e426                	sd	s1,8(sp)
    80001df0:	e04a                	sd	s2,0(sp)
    80001df2:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001df4:	00031497          	auipc	s1,0x31
    80001df8:	b9c48493          	addi	s1,s1,-1124 # 80032990 <proc>
    80001dfc:	00036917          	auipc	s2,0x36
    80001e00:	59490913          	addi	s2,s2,1428 # 80038390 <tickslock>
    acquire(&p->lock);
    80001e04:	8526                	mv	a0,s1
    80001e06:	806ff0ef          	jal	80000e0c <acquire>
    if(p->state == UNUSED) {
    80001e0a:	4c9c                	lw	a5,24(s1)
    80001e0c:	cb91                	beqz	a5,80001e20 <allocproc+0x38>
      release(&p->lock);
    80001e0e:	8526                	mv	a0,s1
    80001e10:	894ff0ef          	jal	80000ea4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001e14:	16848493          	addi	s1,s1,360
    80001e18:	ff2496e3          	bne	s1,s2,80001e04 <allocproc+0x1c>
  return 0;
    80001e1c:	4481                	li	s1,0
    80001e1e:	a089                	j	80001e60 <allocproc+0x78>
  p->pid = allocpid();
    80001e20:	e71ff0ef          	jal	80001c90 <allocpid>
    80001e24:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001e26:	4785                	li	a5,1
    80001e28:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001e2a:	e21fe0ef          	jal	80000c4a <kalloc>
    80001e2e:	892a                	mv	s2,a0
    80001e30:	eca8                	sd	a0,88(s1)
    80001e32:	cd15                	beqz	a0,80001e6e <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001e34:	8526                	mv	a0,s1
    80001e36:	e99ff0ef          	jal	80001cce <proc_pagetable>
    80001e3a:	892a                	mv	s2,a0
    80001e3c:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001e3e:	c121                	beqz	a0,80001e7e <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001e40:	07000613          	li	a2,112
    80001e44:	4581                	li	a1,0
    80001e46:	06048513          	addi	a0,s1,96
    80001e4a:	896ff0ef          	jal	80000ee0 <memset>
  p->context.ra = (uint64)forkret;
    80001e4e:	00000797          	auipc	a5,0x0
    80001e52:	daa78793          	addi	a5,a5,-598 # 80001bf8 <forkret>
    80001e56:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;    // kstack usually gets filled from its end. So we find the address of its end and use a reverse loop to get back.
    80001e58:	60bc                	ld	a5,64(s1)
    80001e5a:	6705                	lui	a4,0x1
    80001e5c:	97ba                	add	a5,a5,a4
    80001e5e:	f4bc                	sd	a5,104(s1)
}
    80001e60:	8526                	mv	a0,s1
    80001e62:	60e2                	ld	ra,24(sp)
    80001e64:	6442                	ld	s0,16(sp)
    80001e66:	64a2                	ld	s1,8(sp)
    80001e68:	6902                	ld	s2,0(sp)
    80001e6a:	6105                	addi	sp,sp,32
    80001e6c:	8082                	ret
    freeproc(p);
    80001e6e:	8526                	mv	a0,s1
    80001e70:	f29ff0ef          	jal	80001d98 <freeproc>
    release(&p->lock);
    80001e74:	8526                	mv	a0,s1
    80001e76:	82eff0ef          	jal	80000ea4 <release>
    return 0;
    80001e7a:	84ca                	mv	s1,s2
    80001e7c:	b7d5                	j	80001e60 <allocproc+0x78>
    freeproc(p);
    80001e7e:	8526                	mv	a0,s1
    80001e80:	f19ff0ef          	jal	80001d98 <freeproc>
    release(&p->lock);
    80001e84:	8526                	mv	a0,s1
    80001e86:	81eff0ef          	jal	80000ea4 <release>
    return 0;
    80001e8a:	84ca                	mv	s1,s2
    80001e8c:	bfd1                	j	80001e60 <allocproc+0x78>

0000000080001e8e <userinit>:
{
    80001e8e:	1101                	addi	sp,sp,-32
    80001e90:	ec06                	sd	ra,24(sp)
    80001e92:	e822                	sd	s0,16(sp)
    80001e94:	e426                	sd	s1,8(sp)
    80001e96:	1000                	addi	s0,sp,32
  p = allocproc();
    80001e98:	f51ff0ef          	jal	80001de8 <allocproc>
    80001e9c:	84aa                	mv	s1,a0
  initproc = p;
    80001e9e:	00008797          	auipc	a5,0x8
    80001ea2:	5aa7b123          	sd	a0,1442(a5) # 8000a440 <initproc>
  p->cwd = namei("/");
    80001ea6:	00005517          	auipc	a0,0x5
    80001eaa:	44a50513          	addi	a0,a0,1098 # 800072f0 <etext+0x2f0>
    80001eae:	661010ef          	jal	80003d0e <namei>
    80001eb2:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001eb6:	478d                	li	a5,3
    80001eb8:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001eba:	8526                	mv	a0,s1
    80001ebc:	fe9fe0ef          	jal	80000ea4 <release>
}
    80001ec0:	60e2                	ld	ra,24(sp)
    80001ec2:	6442                	ld	s0,16(sp)
    80001ec4:	64a2                	ld	s1,8(sp)
    80001ec6:	6105                	addi	sp,sp,32
    80001ec8:	8082                	ret

0000000080001eca <growproc>:
{
    80001eca:	1101                	addi	sp,sp,-32
    80001ecc:	ec06                	sd	ra,24(sp)
    80001ece:	e822                	sd	s0,16(sp)
    80001ed0:	e426                	sd	s1,8(sp)
    80001ed2:	e04a                	sd	s2,0(sp)
    80001ed4:	1000                	addi	s0,sp,32
    80001ed6:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001ed8:	cf1ff0ef          	jal	80001bc8 <myproc>
    80001edc:	84aa                	mv	s1,a0
  sz = p->sz;
    80001ede:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001ee0:	01204c63          	bgtz	s2,80001ef8 <growproc+0x2e>
  } else if(n < 0){
    80001ee4:	02094463          	bltz	s2,80001f0c <growproc+0x42>
  p->sz = sz;
    80001ee8:	e4ac                	sd	a1,72(s1)
  return 0;
    80001eea:	4501                	li	a0,0
}
    80001eec:	60e2                	ld	ra,24(sp)
    80001eee:	6442                	ld	s0,16(sp)
    80001ef0:	64a2                	ld	s1,8(sp)
    80001ef2:	6902                	ld	s2,0(sp)
    80001ef4:	6105                	addi	sp,sp,32
    80001ef6:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001ef8:	4691                	li	a3,4
    80001efa:	00b90633          	add	a2,s2,a1
    80001efe:	6928                	ld	a0,80(a0)
    80001f00:	dcaff0ef          	jal	800014ca <uvmalloc>
    80001f04:	85aa                	mv	a1,a0
    80001f06:	f16d                	bnez	a0,80001ee8 <growproc+0x1e>
      return -1;
    80001f08:	557d                	li	a0,-1
    80001f0a:	b7cd                	j	80001eec <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001f0c:	00b90633          	add	a2,s2,a1
    80001f10:	6928                	ld	a0,80(a0)
    80001f12:	d74ff0ef          	jal	80001486 <uvmdealloc>
    80001f16:	85aa                	mv	a1,a0
    80001f18:	bfc1                	j	80001ee8 <growproc+0x1e>

0000000080001f1a <kfork>:
{
    80001f1a:	7139                	addi	sp,sp,-64
    80001f1c:	fc06                	sd	ra,56(sp)
    80001f1e:	f822                	sd	s0,48(sp)
    80001f20:	f04a                	sd	s2,32(sp)
    80001f22:	e456                	sd	s5,8(sp)
    80001f24:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001f26:	ca3ff0ef          	jal	80001bc8 <myproc>
    80001f2a:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001f2c:	ebdff0ef          	jal	80001de8 <allocproc>
    80001f30:	0e050a63          	beqz	a0,80002024 <kfork+0x10a>
    80001f34:	e852                	sd	s4,16(sp)
    80001f36:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001f38:	048ab603          	ld	a2,72(s5)
    80001f3c:	692c                	ld	a1,80(a0)
    80001f3e:	050ab503          	ld	a0,80(s5)
    80001f42:	ec0ff0ef          	jal	80001602 <uvmcopy>
    80001f46:	04054a63          	bltz	a0,80001f9a <kfork+0x80>
    80001f4a:	f426                	sd	s1,40(sp)
    80001f4c:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001f4e:	048ab783          	ld	a5,72(s5)
    80001f52:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001f56:	058ab683          	ld	a3,88(s5)
    80001f5a:	87b6                	mv	a5,a3
    80001f5c:	058a3703          	ld	a4,88(s4)
    80001f60:	12068693          	addi	a3,a3,288
    80001f64:	0007b803          	ld	a6,0(a5)
    80001f68:	6788                	ld	a0,8(a5)
    80001f6a:	6b8c                	ld	a1,16(a5)
    80001f6c:	6f90                	ld	a2,24(a5)
    80001f6e:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001f72:	e708                	sd	a0,8(a4)
    80001f74:	eb0c                	sd	a1,16(a4)
    80001f76:	ef10                	sd	a2,24(a4)
    80001f78:	02078793          	addi	a5,a5,32
    80001f7c:	02070713          	addi	a4,a4,32
    80001f80:	fed792e3          	bne	a5,a3,80001f64 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001f84:	058a3783          	ld	a5,88(s4)
    80001f88:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001f8c:	0d0a8493          	addi	s1,s5,208
    80001f90:	0d0a0913          	addi	s2,s4,208
    80001f94:	150a8993          	addi	s3,s5,336
    80001f98:	a831                	j	80001fb4 <kfork+0x9a>
    freeproc(np);
    80001f9a:	8552                	mv	a0,s4
    80001f9c:	dfdff0ef          	jal	80001d98 <freeproc>
    release(&np->lock);
    80001fa0:	8552                	mv	a0,s4
    80001fa2:	f03fe0ef          	jal	80000ea4 <release>
    return -1;
    80001fa6:	597d                	li	s2,-1
    80001fa8:	6a42                	ld	s4,16(sp)
    80001faa:	a0b5                	j	80002016 <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001fac:	04a1                	addi	s1,s1,8
    80001fae:	0921                	addi	s2,s2,8
    80001fb0:	01348963          	beq	s1,s3,80001fc2 <kfork+0xa8>
    if(p->ofile[i])
    80001fb4:	6088                	ld	a0,0(s1)
    80001fb6:	d97d                	beqz	a0,80001fac <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001fb8:	2f0020ef          	jal	800042a8 <filedup>
    80001fbc:	00a93023          	sd	a0,0(s2)
    80001fc0:	b7f5                	j	80001fac <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001fc2:	150ab503          	ld	a0,336(s5)
    80001fc6:	4fc010ef          	jal	800034c2 <idup>
    80001fca:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001fce:	4641                	li	a2,16
    80001fd0:	158a8593          	addi	a1,s5,344
    80001fd4:	158a0513          	addi	a0,s4,344
    80001fd8:	846ff0ef          	jal	8000101e <safestrcpy>
  pid = np->pid;
    80001fdc:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001fe0:	8552                	mv	a0,s4
    80001fe2:	ec3fe0ef          	jal	80000ea4 <release>
  acquire(&wait_lock);
    80001fe6:	00030497          	auipc	s1,0x30
    80001fea:	59248493          	addi	s1,s1,1426 # 80032578 <wait_lock>
    80001fee:	8526                	mv	a0,s1
    80001ff0:	e1dfe0ef          	jal	80000e0c <acquire>
  np->parent = p;
    80001ff4:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001ff8:	8526                	mv	a0,s1
    80001ffa:	eabfe0ef          	jal	80000ea4 <release>
  acquire(&np->lock);
    80001ffe:	8552                	mv	a0,s4
    80002000:	e0dfe0ef          	jal	80000e0c <acquire>
  np->state = RUNNABLE;
    80002004:	478d                	li	a5,3
    80002006:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    8000200a:	8552                	mv	a0,s4
    8000200c:	e99fe0ef          	jal	80000ea4 <release>
  return pid;
    80002010:	74a2                	ld	s1,40(sp)
    80002012:	69e2                	ld	s3,24(sp)
    80002014:	6a42                	ld	s4,16(sp)
}
    80002016:	854a                	mv	a0,s2
    80002018:	70e2                	ld	ra,56(sp)
    8000201a:	7442                	ld	s0,48(sp)
    8000201c:	7902                	ld	s2,32(sp)
    8000201e:	6aa2                	ld	s5,8(sp)
    80002020:	6121                	addi	sp,sp,64
    80002022:	8082                	ret
    return -1;
    80002024:	597d                	li	s2,-1
    80002026:	bfc5                	j	80002016 <kfork+0xfc>

0000000080002028 <scheduler>:
{
    80002028:	715d                	addi	sp,sp,-80
    8000202a:	e486                	sd	ra,72(sp)
    8000202c:	e0a2                	sd	s0,64(sp)
    8000202e:	fc26                	sd	s1,56(sp)
    80002030:	f84a                	sd	s2,48(sp)
    80002032:	f44e                	sd	s3,40(sp)
    80002034:	f052                	sd	s4,32(sp)
    80002036:	ec56                	sd	s5,24(sp)
    80002038:	e85a                	sd	s6,16(sp)
    8000203a:	e45e                	sd	s7,8(sp)
    8000203c:	e062                	sd	s8,0(sp)
    8000203e:	0880                	addi	s0,sp,80
    80002040:	8792                	mv	a5,tp
  int id = r_tp();
    80002042:	2781                	sext.w	a5,a5
  c->proc = 0;
    80002044:	00779b13          	slli	s6,a5,0x7
    80002048:	00030717          	auipc	a4,0x30
    8000204c:	51870713          	addi	a4,a4,1304 # 80032560 <pid_lock>
    80002050:	975a                	add	a4,a4,s6
    80002052:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);    // From this point on, the the proc takes the control of CPU, until something happens (like an interrupt)
    80002056:	00030717          	auipc	a4,0x30
    8000205a:	54270713          	addi	a4,a4,1346 # 80032598 <cpus+0x8>
    8000205e:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80002060:	4c11                	li	s8,4
        c->proc = p;
    80002062:	079e                	slli	a5,a5,0x7
    80002064:	00030a17          	auipc	s4,0x30
    80002068:	4fca0a13          	addi	s4,s4,1276 # 80032560 <pid_lock>
    8000206c:	9a3e                	add	s4,s4,a5
        found = 1;
    8000206e:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80002070:	00036997          	auipc	s3,0x36
    80002074:	32098993          	addi	s3,s3,800 # 80038390 <tickslock>
    80002078:	a83d                	j	800020b6 <scheduler+0x8e>
      release(&p->lock);
    8000207a:	8526                	mv	a0,s1
    8000207c:	e29fe0ef          	jal	80000ea4 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80002080:	16848493          	addi	s1,s1,360
    80002084:	03348563          	beq	s1,s3,800020ae <scheduler+0x86>
      acquire(&p->lock);
    80002088:	8526                	mv	a0,s1
    8000208a:	d83fe0ef          	jal	80000e0c <acquire>
      if(p->state == RUNNABLE) {
    8000208e:	4c9c                	lw	a5,24(s1)
    80002090:	ff2795e3          	bne	a5,s2,8000207a <scheduler+0x52>
        p->state = RUNNING;
    80002094:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80002098:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);    // From this point on, the the proc takes the control of CPU, until something happens (like an interrupt)
    8000209c:	06048593          	addi	a1,s1,96
    800020a0:	855a                	mv	a0,s6
    800020a2:	5b2000ef          	jal	80002654 <swtch>
        c->proc = 0;    // No process is running on the core, gives back control to OS
    800020a6:	020a3823          	sd	zero,48(s4)
        found = 1;
    800020aa:	8ade                	mv	s5,s7
    800020ac:	b7f9                	j	8000207a <scheduler+0x52>
    if(found == 0) {
    800020ae:	000a9463          	bnez	s5,800020b6 <scheduler+0x8e>
      asm volatile("wfi");    // Cuts the CPU power usage
    800020b2:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800020b6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800020ba:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800020be:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800020c2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800020c6:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800020c8:	10079073          	csrw	sstatus,a5
    int found = 0;
    800020cc:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    800020ce:	00031497          	auipc	s1,0x31
    800020d2:	8c248493          	addi	s1,s1,-1854 # 80032990 <proc>
      if(p->state == RUNNABLE) {
    800020d6:	490d                	li	s2,3
    800020d8:	bf45                	j	80002088 <scheduler+0x60>

00000000800020da <sched>:
{
    800020da:	7179                	addi	sp,sp,-48
    800020dc:	f406                	sd	ra,40(sp)
    800020de:	f022                	sd	s0,32(sp)
    800020e0:	ec26                	sd	s1,24(sp)
    800020e2:	e84a                	sd	s2,16(sp)
    800020e4:	e44e                	sd	s3,8(sp)
    800020e6:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800020e8:	ae1ff0ef          	jal	80001bc8 <myproc>
    800020ec:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    800020ee:	cb5fe0ef          	jal	80000da2 <holding>
    800020f2:	c92d                	beqz	a0,80002164 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    800020f4:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800020f6:	2781                	sext.w	a5,a5
    800020f8:	079e                	slli	a5,a5,0x7
    800020fa:	00030717          	auipc	a4,0x30
    800020fe:	46670713          	addi	a4,a4,1126 # 80032560 <pid_lock>
    80002102:	97ba                	add	a5,a5,a4
    80002104:	0a87a703          	lw	a4,168(a5)
    80002108:	4785                	li	a5,1
    8000210a:	06f71363          	bne	a4,a5,80002170 <sched+0x96>
  if(p->state == RUNNING)
    8000210e:	4c98                	lw	a4,24(s1)
    80002110:	4791                	li	a5,4
    80002112:	06f70563          	beq	a4,a5,8000217c <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002116:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000211a:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000211c:	e7b5                	bnez	a5,80002188 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000211e:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80002120:	00030917          	auipc	s2,0x30
    80002124:	44090913          	addi	s2,s2,1088 # 80032560 <pid_lock>
    80002128:	2781                	sext.w	a5,a5
    8000212a:	079e                	slli	a5,a5,0x7
    8000212c:	97ca                	add	a5,a5,s2
    8000212e:	0ac7a983          	lw	s3,172(a5)
    80002132:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80002134:	2781                	sext.w	a5,a5
    80002136:	079e                	slli	a5,a5,0x7
    80002138:	00030597          	auipc	a1,0x30
    8000213c:	46058593          	addi	a1,a1,1120 # 80032598 <cpus+0x8>
    80002140:	95be                	add	a1,a1,a5
    80002142:	06048513          	addi	a0,s1,96
    80002146:	50e000ef          	jal	80002654 <swtch>
    8000214a:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    8000214c:	2781                	sext.w	a5,a5
    8000214e:	079e                	slli	a5,a5,0x7
    80002150:	993e                	add	s2,s2,a5
    80002152:	0b392623          	sw	s3,172(s2)
}
    80002156:	70a2                	ld	ra,40(sp)
    80002158:	7402                	ld	s0,32(sp)
    8000215a:	64e2                	ld	s1,24(sp)
    8000215c:	6942                	ld	s2,16(sp)
    8000215e:	69a2                	ld	s3,8(sp)
    80002160:	6145                	addi	sp,sp,48
    80002162:	8082                	ret
    panic("sched p->lock");
    80002164:	00005517          	auipc	a0,0x5
    80002168:	19450513          	addi	a0,a0,404 # 800072f8 <etext+0x2f8>
    8000216c:	e74fe0ef          	jal	800007e0 <panic>
    panic("sched locks");
    80002170:	00005517          	auipc	a0,0x5
    80002174:	19850513          	addi	a0,a0,408 # 80007308 <etext+0x308>
    80002178:	e68fe0ef          	jal	800007e0 <panic>
    panic("sched RUNNING");
    8000217c:	00005517          	auipc	a0,0x5
    80002180:	19c50513          	addi	a0,a0,412 # 80007318 <etext+0x318>
    80002184:	e5cfe0ef          	jal	800007e0 <panic>
    panic("sched interruptible");
    80002188:	00005517          	auipc	a0,0x5
    8000218c:	1a050513          	addi	a0,a0,416 # 80007328 <etext+0x328>
    80002190:	e50fe0ef          	jal	800007e0 <panic>

0000000080002194 <yield>:
{
    80002194:	1101                	addi	sp,sp,-32
    80002196:	ec06                	sd	ra,24(sp)
    80002198:	e822                	sd	s0,16(sp)
    8000219a:	e426                	sd	s1,8(sp)
    8000219c:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    8000219e:	a2bff0ef          	jal	80001bc8 <myproc>
    800021a2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800021a4:	c69fe0ef          	jal	80000e0c <acquire>
  p->state = RUNNABLE;
    800021a8:	478d                	li	a5,3
    800021aa:	cc9c                	sw	a5,24(s1)
  sched();
    800021ac:	f2fff0ef          	jal	800020da <sched>
  release(&p->lock);
    800021b0:	8526                	mv	a0,s1
    800021b2:	cf3fe0ef          	jal	80000ea4 <release>
}
    800021b6:	60e2                	ld	ra,24(sp)
    800021b8:	6442                	ld	s0,16(sp)
    800021ba:	64a2                	ld	s1,8(sp)
    800021bc:	6105                	addi	sp,sp,32
    800021be:	8082                	ret

00000000800021c0 <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    800021c0:	7179                	addi	sp,sp,-48
    800021c2:	f406                	sd	ra,40(sp)
    800021c4:	f022                	sd	s0,32(sp)
    800021c6:	ec26                	sd	s1,24(sp)
    800021c8:	e84a                	sd	s2,16(sp)
    800021ca:	e44e                	sd	s3,8(sp)
    800021cc:	1800                	addi	s0,sp,48
    800021ce:	89aa                	mv	s3,a0
    800021d0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800021d2:	9f7ff0ef          	jal	80001bc8 <myproc>
    800021d6:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    800021d8:	c35fe0ef          	jal	80000e0c <acquire>
  release(lk);
    800021dc:	854a                	mv	a0,s2
    800021de:	cc7fe0ef          	jal	80000ea4 <release>

  // Go to sleep.
  p->chan = chan;
    800021e2:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    800021e6:	4789                	li	a5,2
    800021e8:	cc9c                	sw	a5,24(s1)

  sched();
    800021ea:	ef1ff0ef          	jal	800020da <sched>

  // Tidy up.
  p->chan = 0;
    800021ee:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800021f2:	8526                	mv	a0,s1
    800021f4:	cb1fe0ef          	jal	80000ea4 <release>
  acquire(lk);
    800021f8:	854a                	mv	a0,s2
    800021fa:	c13fe0ef          	jal	80000e0c <acquire>
}
    800021fe:	70a2                	ld	ra,40(sp)
    80002200:	7402                	ld	s0,32(sp)
    80002202:	64e2                	ld	s1,24(sp)
    80002204:	6942                	ld	s2,16(sp)
    80002206:	69a2                	ld	s3,8(sp)
    80002208:	6145                	addi	sp,sp,48
    8000220a:	8082                	ret

000000008000220c <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    8000220c:	7139                	addi	sp,sp,-64
    8000220e:	fc06                	sd	ra,56(sp)
    80002210:	f822                	sd	s0,48(sp)
    80002212:	f426                	sd	s1,40(sp)
    80002214:	f04a                	sd	s2,32(sp)
    80002216:	ec4e                	sd	s3,24(sp)
    80002218:	e852                	sd	s4,16(sp)
    8000221a:	e456                	sd	s5,8(sp)
    8000221c:	0080                	addi	s0,sp,64
    8000221e:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80002220:	00030497          	auipc	s1,0x30
    80002224:	77048493          	addi	s1,s1,1904 # 80032990 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80002228:	4989                	li	s3,2
        p->state = RUNNABLE;
    8000222a:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    8000222c:	00036917          	auipc	s2,0x36
    80002230:	16490913          	addi	s2,s2,356 # 80038390 <tickslock>
    80002234:	a801                	j	80002244 <wakeup+0x38>
      }
      release(&p->lock);
    80002236:	8526                	mv	a0,s1
    80002238:	c6dfe0ef          	jal	80000ea4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000223c:	16848493          	addi	s1,s1,360
    80002240:	03248263          	beq	s1,s2,80002264 <wakeup+0x58>
    if(p != myproc()){
    80002244:	985ff0ef          	jal	80001bc8 <myproc>
    80002248:	fea48ae3          	beq	s1,a0,8000223c <wakeup+0x30>
      acquire(&p->lock);
    8000224c:	8526                	mv	a0,s1
    8000224e:	bbffe0ef          	jal	80000e0c <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80002252:	4c9c                	lw	a5,24(s1)
    80002254:	ff3791e3          	bne	a5,s3,80002236 <wakeup+0x2a>
    80002258:	709c                	ld	a5,32(s1)
    8000225a:	fd479ee3          	bne	a5,s4,80002236 <wakeup+0x2a>
        p->state = RUNNABLE;
    8000225e:	0154ac23          	sw	s5,24(s1)
    80002262:	bfd1                	j	80002236 <wakeup+0x2a>
    }
  }
}
    80002264:	70e2                	ld	ra,56(sp)
    80002266:	7442                	ld	s0,48(sp)
    80002268:	74a2                	ld	s1,40(sp)
    8000226a:	7902                	ld	s2,32(sp)
    8000226c:	69e2                	ld	s3,24(sp)
    8000226e:	6a42                	ld	s4,16(sp)
    80002270:	6aa2                	ld	s5,8(sp)
    80002272:	6121                	addi	sp,sp,64
    80002274:	8082                	ret

0000000080002276 <reparent>:
{
    80002276:	7179                	addi	sp,sp,-48
    80002278:	f406                	sd	ra,40(sp)
    8000227a:	f022                	sd	s0,32(sp)
    8000227c:	ec26                	sd	s1,24(sp)
    8000227e:	e84a                	sd	s2,16(sp)
    80002280:	e44e                	sd	s3,8(sp)
    80002282:	e052                	sd	s4,0(sp)
    80002284:	1800                	addi	s0,sp,48
    80002286:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002288:	00030497          	auipc	s1,0x30
    8000228c:	70848493          	addi	s1,s1,1800 # 80032990 <proc>
      pp->parent = initproc;
    80002290:	00008a17          	auipc	s4,0x8
    80002294:	1b0a0a13          	addi	s4,s4,432 # 8000a440 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002298:	00036997          	auipc	s3,0x36
    8000229c:	0f898993          	addi	s3,s3,248 # 80038390 <tickslock>
    800022a0:	a029                	j	800022aa <reparent+0x34>
    800022a2:	16848493          	addi	s1,s1,360
    800022a6:	01348b63          	beq	s1,s3,800022bc <reparent+0x46>
    if(pp->parent == p){
    800022aa:	7c9c                	ld	a5,56(s1)
    800022ac:	ff279be3          	bne	a5,s2,800022a2 <reparent+0x2c>
      pp->parent = initproc;
    800022b0:	000a3503          	ld	a0,0(s4)
    800022b4:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    800022b6:	f57ff0ef          	jal	8000220c <wakeup>
    800022ba:	b7e5                	j	800022a2 <reparent+0x2c>
}
    800022bc:	70a2                	ld	ra,40(sp)
    800022be:	7402                	ld	s0,32(sp)
    800022c0:	64e2                	ld	s1,24(sp)
    800022c2:	6942                	ld	s2,16(sp)
    800022c4:	69a2                	ld	s3,8(sp)
    800022c6:	6a02                	ld	s4,0(sp)
    800022c8:	6145                	addi	sp,sp,48
    800022ca:	8082                	ret

00000000800022cc <kexit>:
{
    800022cc:	7179                	addi	sp,sp,-48
    800022ce:	f406                	sd	ra,40(sp)
    800022d0:	f022                	sd	s0,32(sp)
    800022d2:	ec26                	sd	s1,24(sp)
    800022d4:	e84a                	sd	s2,16(sp)
    800022d6:	e44e                	sd	s3,8(sp)
    800022d8:	e052                	sd	s4,0(sp)
    800022da:	1800                	addi	s0,sp,48
    800022dc:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800022de:	8ebff0ef          	jal	80001bc8 <myproc>
    800022e2:	89aa                	mv	s3,a0
  if(p == initproc)
    800022e4:	00008797          	auipc	a5,0x8
    800022e8:	15c7b783          	ld	a5,348(a5) # 8000a440 <initproc>
    800022ec:	0d050493          	addi	s1,a0,208
    800022f0:	15050913          	addi	s2,a0,336
    800022f4:	00a79f63          	bne	a5,a0,80002312 <kexit+0x46>
    panic("init exiting");
    800022f8:	00005517          	auipc	a0,0x5
    800022fc:	04850513          	addi	a0,a0,72 # 80007340 <etext+0x340>
    80002300:	ce0fe0ef          	jal	800007e0 <panic>
      fileclose(f);
    80002304:	7eb010ef          	jal	800042ee <fileclose>
      p->ofile[fd] = 0;
    80002308:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    8000230c:	04a1                	addi	s1,s1,8
    8000230e:	01248563          	beq	s1,s2,80002318 <kexit+0x4c>
    if(p->ofile[fd]){
    80002312:	6088                	ld	a0,0(s1)
    80002314:	f965                	bnez	a0,80002304 <kexit+0x38>
    80002316:	bfdd                	j	8000230c <kexit+0x40>
  begin_op();
    80002318:	3cb010ef          	jal	80003ee2 <begin_op>
  iput(p->cwd);
    8000231c:	1509b503          	ld	a0,336(s3)
    80002320:	35a010ef          	jal	8000367a <iput>
  end_op();
    80002324:	429010ef          	jal	80003f4c <end_op>
  p->cwd = 0;
    80002328:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000232c:	00030497          	auipc	s1,0x30
    80002330:	24c48493          	addi	s1,s1,588 # 80032578 <wait_lock>
    80002334:	8526                	mv	a0,s1
    80002336:	ad7fe0ef          	jal	80000e0c <acquire>
  reparent(p);
    8000233a:	854e                	mv	a0,s3
    8000233c:	f3bff0ef          	jal	80002276 <reparent>
  wakeup(p->parent);
    80002340:	0389b503          	ld	a0,56(s3)
    80002344:	ec9ff0ef          	jal	8000220c <wakeup>
  acquire(&p->lock);
    80002348:	854e                	mv	a0,s3
    8000234a:	ac3fe0ef          	jal	80000e0c <acquire>
  p->xstate = status;
    8000234e:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002352:	4795                	li	a5,5
    80002354:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002358:	8526                	mv	a0,s1
    8000235a:	b4bfe0ef          	jal	80000ea4 <release>
  sched();
    8000235e:	d7dff0ef          	jal	800020da <sched>
  panic("zombie exit");
    80002362:	00005517          	auipc	a0,0x5
    80002366:	fee50513          	addi	a0,a0,-18 # 80007350 <etext+0x350>
    8000236a:	c76fe0ef          	jal	800007e0 <panic>

000000008000236e <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    8000236e:	7179                	addi	sp,sp,-48
    80002370:	f406                	sd	ra,40(sp)
    80002372:	f022                	sd	s0,32(sp)
    80002374:	ec26                	sd	s1,24(sp)
    80002376:	e84a                	sd	s2,16(sp)
    80002378:	e44e                	sd	s3,8(sp)
    8000237a:	1800                	addi	s0,sp,48
    8000237c:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    8000237e:	00030497          	auipc	s1,0x30
    80002382:	61248493          	addi	s1,s1,1554 # 80032990 <proc>
    80002386:	00036997          	auipc	s3,0x36
    8000238a:	00a98993          	addi	s3,s3,10 # 80038390 <tickslock>
    acquire(&p->lock);
    8000238e:	8526                	mv	a0,s1
    80002390:	a7dfe0ef          	jal	80000e0c <acquire>
    if(p->pid == pid){
    80002394:	589c                	lw	a5,48(s1)
    80002396:	01278b63          	beq	a5,s2,800023ac <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000239a:	8526                	mv	a0,s1
    8000239c:	b09fe0ef          	jal	80000ea4 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800023a0:	16848493          	addi	s1,s1,360
    800023a4:	ff3495e3          	bne	s1,s3,8000238e <kkill+0x20>
  }
  return -1;
    800023a8:	557d                	li	a0,-1
    800023aa:	a819                	j	800023c0 <kkill+0x52>
      p->killed = 1;
    800023ac:	4785                	li	a5,1
    800023ae:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800023b0:	4c98                	lw	a4,24(s1)
    800023b2:	4789                	li	a5,2
    800023b4:	00f70d63          	beq	a4,a5,800023ce <kkill+0x60>
      release(&p->lock);
    800023b8:	8526                	mv	a0,s1
    800023ba:	aebfe0ef          	jal	80000ea4 <release>
      return 0;
    800023be:	4501                	li	a0,0
}
    800023c0:	70a2                	ld	ra,40(sp)
    800023c2:	7402                	ld	s0,32(sp)
    800023c4:	64e2                	ld	s1,24(sp)
    800023c6:	6942                	ld	s2,16(sp)
    800023c8:	69a2                	ld	s3,8(sp)
    800023ca:	6145                	addi	sp,sp,48
    800023cc:	8082                	ret
        p->state = RUNNABLE;
    800023ce:	478d                	li	a5,3
    800023d0:	cc9c                	sw	a5,24(s1)
    800023d2:	b7dd                	j	800023b8 <kkill+0x4a>

00000000800023d4 <setkilled>:

void
setkilled(struct proc *p)
{
    800023d4:	1101                	addi	sp,sp,-32
    800023d6:	ec06                	sd	ra,24(sp)
    800023d8:	e822                	sd	s0,16(sp)
    800023da:	e426                	sd	s1,8(sp)
    800023dc:	1000                	addi	s0,sp,32
    800023de:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800023e0:	a2dfe0ef          	jal	80000e0c <acquire>
  p->killed = 1;
    800023e4:	4785                	li	a5,1
    800023e6:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800023e8:	8526                	mv	a0,s1
    800023ea:	abbfe0ef          	jal	80000ea4 <release>
}
    800023ee:	60e2                	ld	ra,24(sp)
    800023f0:	6442                	ld	s0,16(sp)
    800023f2:	64a2                	ld	s1,8(sp)
    800023f4:	6105                	addi	sp,sp,32
    800023f6:	8082                	ret

00000000800023f8 <killed>:

int
killed(struct proc *p)
{
    800023f8:	1101                	addi	sp,sp,-32
    800023fa:	ec06                	sd	ra,24(sp)
    800023fc:	e822                	sd	s0,16(sp)
    800023fe:	e426                	sd	s1,8(sp)
    80002400:	e04a                	sd	s2,0(sp)
    80002402:	1000                	addi	s0,sp,32
    80002404:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002406:	a07fe0ef          	jal	80000e0c <acquire>
  k = p->killed;
    8000240a:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    8000240e:	8526                	mv	a0,s1
    80002410:	a95fe0ef          	jal	80000ea4 <release>
  return k;
}
    80002414:	854a                	mv	a0,s2
    80002416:	60e2                	ld	ra,24(sp)
    80002418:	6442                	ld	s0,16(sp)
    8000241a:	64a2                	ld	s1,8(sp)
    8000241c:	6902                	ld	s2,0(sp)
    8000241e:	6105                	addi	sp,sp,32
    80002420:	8082                	ret

0000000080002422 <kwait>:
{
    80002422:	715d                	addi	sp,sp,-80
    80002424:	e486                	sd	ra,72(sp)
    80002426:	e0a2                	sd	s0,64(sp)
    80002428:	fc26                	sd	s1,56(sp)
    8000242a:	f84a                	sd	s2,48(sp)
    8000242c:	f44e                	sd	s3,40(sp)
    8000242e:	f052                	sd	s4,32(sp)
    80002430:	ec56                	sd	s5,24(sp)
    80002432:	e85a                	sd	s6,16(sp)
    80002434:	e45e                	sd	s7,8(sp)
    80002436:	e062                	sd	s8,0(sp)
    80002438:	0880                	addi	s0,sp,80
    8000243a:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    8000243c:	f8cff0ef          	jal	80001bc8 <myproc>
    80002440:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002442:	00030517          	auipc	a0,0x30
    80002446:	13650513          	addi	a0,a0,310 # 80032578 <wait_lock>
    8000244a:	9c3fe0ef          	jal	80000e0c <acquire>
    havekids = 0;
    8000244e:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    80002450:	4a15                	li	s4,5
        havekids = 1;
    80002452:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002454:	00036997          	auipc	s3,0x36
    80002458:	f3c98993          	addi	s3,s3,-196 # 80038390 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000245c:	00030c17          	auipc	s8,0x30
    80002460:	11cc0c13          	addi	s8,s8,284 # 80032578 <wait_lock>
    80002464:	a871                	j	80002500 <kwait+0xde>
          pid = pp->pid;
    80002466:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000246a:	000b0c63          	beqz	s6,80002482 <kwait+0x60>
    8000246e:	4691                	li	a3,4
    80002470:	02c48613          	addi	a2,s1,44
    80002474:	85da                	mv	a1,s6
    80002476:	05093503          	ld	a0,80(s2)
    8000247a:	c1eff0ef          	jal	80001898 <copyout>
    8000247e:	02054b63          	bltz	a0,800024b4 <kwait+0x92>
          freeproc(pp);
    80002482:	8526                	mv	a0,s1
    80002484:	915ff0ef          	jal	80001d98 <freeproc>
          release(&pp->lock);
    80002488:	8526                	mv	a0,s1
    8000248a:	a1bfe0ef          	jal	80000ea4 <release>
          release(&wait_lock);
    8000248e:	00030517          	auipc	a0,0x30
    80002492:	0ea50513          	addi	a0,a0,234 # 80032578 <wait_lock>
    80002496:	a0ffe0ef          	jal	80000ea4 <release>
}
    8000249a:	854e                	mv	a0,s3
    8000249c:	60a6                	ld	ra,72(sp)
    8000249e:	6406                	ld	s0,64(sp)
    800024a0:	74e2                	ld	s1,56(sp)
    800024a2:	7942                	ld	s2,48(sp)
    800024a4:	79a2                	ld	s3,40(sp)
    800024a6:	7a02                	ld	s4,32(sp)
    800024a8:	6ae2                	ld	s5,24(sp)
    800024aa:	6b42                	ld	s6,16(sp)
    800024ac:	6ba2                	ld	s7,8(sp)
    800024ae:	6c02                	ld	s8,0(sp)
    800024b0:	6161                	addi	sp,sp,80
    800024b2:	8082                	ret
            release(&pp->lock);
    800024b4:	8526                	mv	a0,s1
    800024b6:	9effe0ef          	jal	80000ea4 <release>
            release(&wait_lock);
    800024ba:	00030517          	auipc	a0,0x30
    800024be:	0be50513          	addi	a0,a0,190 # 80032578 <wait_lock>
    800024c2:	9e3fe0ef          	jal	80000ea4 <release>
            return -1;
    800024c6:	59fd                	li	s3,-1
    800024c8:	bfc9                	j	8000249a <kwait+0x78>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800024ca:	16848493          	addi	s1,s1,360
    800024ce:	03348063          	beq	s1,s3,800024ee <kwait+0xcc>
      if(pp->parent == p){
    800024d2:	7c9c                	ld	a5,56(s1)
    800024d4:	ff279be3          	bne	a5,s2,800024ca <kwait+0xa8>
        acquire(&pp->lock);
    800024d8:	8526                	mv	a0,s1
    800024da:	933fe0ef          	jal	80000e0c <acquire>
        if(pp->state == ZOMBIE){
    800024de:	4c9c                	lw	a5,24(s1)
    800024e0:	f94783e3          	beq	a5,s4,80002466 <kwait+0x44>
        release(&pp->lock);
    800024e4:	8526                	mv	a0,s1
    800024e6:	9bffe0ef          	jal	80000ea4 <release>
        havekids = 1;
    800024ea:	8756                	mv	a4,s5
    800024ec:	bff9                	j	800024ca <kwait+0xa8>
    if(!havekids || killed(p)){
    800024ee:	cf19                	beqz	a4,8000250c <kwait+0xea>
    800024f0:	854a                	mv	a0,s2
    800024f2:	f07ff0ef          	jal	800023f8 <killed>
    800024f6:	e919                	bnez	a0,8000250c <kwait+0xea>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800024f8:	85e2                	mv	a1,s8
    800024fa:	854a                	mv	a0,s2
    800024fc:	cc5ff0ef          	jal	800021c0 <sleep>
    havekids = 0;
    80002500:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002502:	00030497          	auipc	s1,0x30
    80002506:	48e48493          	addi	s1,s1,1166 # 80032990 <proc>
    8000250a:	b7e1                	j	800024d2 <kwait+0xb0>
      release(&wait_lock);
    8000250c:	00030517          	auipc	a0,0x30
    80002510:	06c50513          	addi	a0,a0,108 # 80032578 <wait_lock>
    80002514:	991fe0ef          	jal	80000ea4 <release>
      return -1;
    80002518:	59fd                	li	s3,-1
    8000251a:	b741                	j	8000249a <kwait+0x78>

000000008000251c <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000251c:	7179                	addi	sp,sp,-48
    8000251e:	f406                	sd	ra,40(sp)
    80002520:	f022                	sd	s0,32(sp)
    80002522:	ec26                	sd	s1,24(sp)
    80002524:	e84a                	sd	s2,16(sp)
    80002526:	e44e                	sd	s3,8(sp)
    80002528:	e052                	sd	s4,0(sp)
    8000252a:	1800                	addi	s0,sp,48
    8000252c:	84aa                	mv	s1,a0
    8000252e:	892e                	mv	s2,a1
    80002530:	89b2                	mv	s3,a2
    80002532:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002534:	e94ff0ef          	jal	80001bc8 <myproc>
  if(user_dst){
    80002538:	cc99                	beqz	s1,80002556 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    8000253a:	86d2                	mv	a3,s4
    8000253c:	864e                	mv	a2,s3
    8000253e:	85ca                	mv	a1,s2
    80002540:	6928                	ld	a0,80(a0)
    80002542:	b56ff0ef          	jal	80001898 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002546:	70a2                	ld	ra,40(sp)
    80002548:	7402                	ld	s0,32(sp)
    8000254a:	64e2                	ld	s1,24(sp)
    8000254c:	6942                	ld	s2,16(sp)
    8000254e:	69a2                	ld	s3,8(sp)
    80002550:	6a02                	ld	s4,0(sp)
    80002552:	6145                	addi	sp,sp,48
    80002554:	8082                	ret
    memmove((char *)dst, src, len);
    80002556:	000a061b          	sext.w	a2,s4
    8000255a:	85ce                	mv	a1,s3
    8000255c:	854a                	mv	a0,s2
    8000255e:	9dffe0ef          	jal	80000f3c <memmove>
    return 0;
    80002562:	8526                	mv	a0,s1
    80002564:	b7cd                	j	80002546 <either_copyout+0x2a>

0000000080002566 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002566:	7179                	addi	sp,sp,-48
    80002568:	f406                	sd	ra,40(sp)
    8000256a:	f022                	sd	s0,32(sp)
    8000256c:	ec26                	sd	s1,24(sp)
    8000256e:	e84a                	sd	s2,16(sp)
    80002570:	e44e                	sd	s3,8(sp)
    80002572:	e052                	sd	s4,0(sp)
    80002574:	1800                	addi	s0,sp,48
    80002576:	892a                	mv	s2,a0
    80002578:	84ae                	mv	s1,a1
    8000257a:	89b2                	mv	s3,a2
    8000257c:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000257e:	e4aff0ef          	jal	80001bc8 <myproc>
  if(user_src){
    80002582:	cc99                	beqz	s1,800025a0 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80002584:	86d2                	mv	a3,s4
    80002586:	864e                	mv	a2,s3
    80002588:	85ca                	mv	a1,s2
    8000258a:	6928                	ld	a0,80(a0)
    8000258c:	c14ff0ef          	jal	800019a0 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002590:	70a2                	ld	ra,40(sp)
    80002592:	7402                	ld	s0,32(sp)
    80002594:	64e2                	ld	s1,24(sp)
    80002596:	6942                	ld	s2,16(sp)
    80002598:	69a2                	ld	s3,8(sp)
    8000259a:	6a02                	ld	s4,0(sp)
    8000259c:	6145                	addi	sp,sp,48
    8000259e:	8082                	ret
    memmove(dst, (char*)src, len);
    800025a0:	000a061b          	sext.w	a2,s4
    800025a4:	85ce                	mv	a1,s3
    800025a6:	854a                	mv	a0,s2
    800025a8:	995fe0ef          	jal	80000f3c <memmove>
    return 0;
    800025ac:	8526                	mv	a0,s1
    800025ae:	b7cd                	j	80002590 <either_copyin+0x2a>

00000000800025b0 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800025b0:	715d                	addi	sp,sp,-80
    800025b2:	e486                	sd	ra,72(sp)
    800025b4:	e0a2                	sd	s0,64(sp)
    800025b6:	fc26                	sd	s1,56(sp)
    800025b8:	f84a                	sd	s2,48(sp)
    800025ba:	f44e                	sd	s3,40(sp)
    800025bc:	f052                	sd	s4,32(sp)
    800025be:	ec56                	sd	s5,24(sp)
    800025c0:	e85a                	sd	s6,16(sp)
    800025c2:	e45e                	sd	s7,8(sp)
    800025c4:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800025c6:	00005517          	auipc	a0,0x5
    800025ca:	baa50513          	addi	a0,a0,-1110 # 80007170 <etext+0x170>
    800025ce:	f2dfd0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800025d2:	00030497          	auipc	s1,0x30
    800025d6:	51648493          	addi	s1,s1,1302 # 80032ae8 <proc+0x158>
    800025da:	00036917          	auipc	s2,0x36
    800025de:	f0e90913          	addi	s2,s2,-242 # 800384e8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800025e2:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800025e4:	00005997          	auipc	s3,0x5
    800025e8:	d7c98993          	addi	s3,s3,-644 # 80007360 <etext+0x360>
    printf("%d %s %s", p->pid, state, p->name);
    800025ec:	00005a97          	auipc	s5,0x5
    800025f0:	d7ca8a93          	addi	s5,s5,-644 # 80007368 <etext+0x368>
    printf("\n");
    800025f4:	00005a17          	auipc	s4,0x5
    800025f8:	b7ca0a13          	addi	s4,s4,-1156 # 80007170 <etext+0x170>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800025fc:	00005b97          	auipc	s7,0x5
    80002600:	28cb8b93          	addi	s7,s7,652 # 80007888 <states.0>
    80002604:	a829                	j	8000261e <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002606:	ed86a583          	lw	a1,-296(a3)
    8000260a:	8556                	mv	a0,s5
    8000260c:	eeffd0ef          	jal	800004fa <printf>
    printf("\n");
    80002610:	8552                	mv	a0,s4
    80002612:	ee9fd0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002616:	16848493          	addi	s1,s1,360
    8000261a:	03248263          	beq	s1,s2,8000263e <procdump+0x8e>
    if(p->state == UNUSED)
    8000261e:	86a6                	mv	a3,s1
    80002620:	ec04a783          	lw	a5,-320(s1)
    80002624:	dbed                	beqz	a5,80002616 <procdump+0x66>
      state = "???";
    80002626:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002628:	fcfb6fe3          	bltu	s6,a5,80002606 <procdump+0x56>
    8000262c:	02079713          	slli	a4,a5,0x20
    80002630:	01d75793          	srli	a5,a4,0x1d
    80002634:	97de                	add	a5,a5,s7
    80002636:	6390                	ld	a2,0(a5)
    80002638:	f679                	bnez	a2,80002606 <procdump+0x56>
      state = "???";
    8000263a:	864e                	mv	a2,s3
    8000263c:	b7e9                	j	80002606 <procdump+0x56>
  }
}
    8000263e:	60a6                	ld	ra,72(sp)
    80002640:	6406                	ld	s0,64(sp)
    80002642:	74e2                	ld	s1,56(sp)
    80002644:	7942                	ld	s2,48(sp)
    80002646:	79a2                	ld	s3,40(sp)
    80002648:	7a02                	ld	s4,32(sp)
    8000264a:	6ae2                	ld	s5,24(sp)
    8000264c:	6b42                	ld	s6,16(sp)
    8000264e:	6ba2                	ld	s7,8(sp)
    80002650:	6161                	addi	sp,sp,80
    80002652:	8082                	ret

0000000080002654 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002654:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002658:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    8000265c:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    8000265e:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002660:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    80002664:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002668:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    8000266c:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002670:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002674:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002678:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    8000267c:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002680:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002684:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002688:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    8000268c:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002690:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002692:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002694:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002698:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    8000269c:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800026a0:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800026a4:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800026a8:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800026ac:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800026b0:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800026b4:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800026b8:	0685bd83          	ld	s11,104(a1)
        
        ret
    800026bc:	8082                	ret

00000000800026be <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800026be:	1141                	addi	sp,sp,-16
    800026c0:	e406                	sd	ra,8(sp)
    800026c2:	e022                	sd	s0,0(sp)
    800026c4:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800026c6:	00005597          	auipc	a1,0x5
    800026ca:	ce258593          	addi	a1,a1,-798 # 800073a8 <etext+0x3a8>
    800026ce:	00036517          	auipc	a0,0x36
    800026d2:	cc250513          	addi	a0,a0,-830 # 80038390 <tickslock>
    800026d6:	eb6fe0ef          	jal	80000d8c <initlock>
}
    800026da:	60a2                	ld	ra,8(sp)
    800026dc:	6402                	ld	s0,0(sp)
    800026de:	0141                	addi	sp,sp,16
    800026e0:	8082                	ret

00000000800026e2 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800026e2:	1141                	addi	sp,sp,-16
    800026e4:	e422                	sd	s0,8(sp)
    800026e6:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800026e8:	00003797          	auipc	a5,0x3
    800026ec:	f7878793          	addi	a5,a5,-136 # 80005660 <kernelvec>
    800026f0:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800026f4:	6422                	ld	s0,8(sp)
    800026f6:	0141                	addi	sp,sp,16
    800026f8:	8082                	ret

00000000800026fa <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800026fa:	1141                	addi	sp,sp,-16
    800026fc:	e406                	sd	ra,8(sp)
    800026fe:	e022                	sd	s0,0(sp)
    80002700:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002702:	cc6ff0ef          	jal	80001bc8 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002706:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000270a:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000270c:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002710:	04000737          	lui	a4,0x4000
    80002714:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80002716:	0732                	slli	a4,a4,0xc
    80002718:	00004797          	auipc	a5,0x4
    8000271c:	8e878793          	addi	a5,a5,-1816 # 80006000 <_trampoline>
    80002720:	00004697          	auipc	a3,0x4
    80002724:	8e068693          	addi	a3,a3,-1824 # 80006000 <_trampoline>
    80002728:	8f95                	sub	a5,a5,a3
    8000272a:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000272c:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002730:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002732:	18002773          	csrr	a4,satp
    80002736:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002738:	6d38                	ld	a4,88(a0)
    8000273a:	613c                	ld	a5,64(a0)
    8000273c:	6685                	lui	a3,0x1
    8000273e:	97b6                	add	a5,a5,a3
    80002740:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002742:	6d3c                	ld	a5,88(a0)
    80002744:	00000717          	auipc	a4,0x0
    80002748:	0f870713          	addi	a4,a4,248 # 8000283c <usertrap>
    8000274c:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    8000274e:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002750:	8712                	mv	a4,tp
    80002752:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002754:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002758:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000275c:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002760:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002764:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002766:	6f9c                	ld	a5,24(a5)
    80002768:	14179073          	csrw	sepc,a5
}
    8000276c:	60a2                	ld	ra,8(sp)
    8000276e:	6402                	ld	s0,0(sp)
    80002770:	0141                	addi	sp,sp,16
    80002772:	8082                	ret

0000000080002774 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002774:	1101                	addi	sp,sp,-32
    80002776:	ec06                	sd	ra,24(sp)
    80002778:	e822                	sd	s0,16(sp)
    8000277a:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    8000277c:	c20ff0ef          	jal	80001b9c <cpuid>
    80002780:	cd11                	beqz	a0,8000279c <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    80002782:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80002786:	000f4737          	lui	a4,0xf4
    8000278a:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000278e:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002790:	14d79073          	csrw	stimecmp,a5
}
    80002794:	60e2                	ld	ra,24(sp)
    80002796:	6442                	ld	s0,16(sp)
    80002798:	6105                	addi	sp,sp,32
    8000279a:	8082                	ret
    8000279c:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    8000279e:	00036497          	auipc	s1,0x36
    800027a2:	bf248493          	addi	s1,s1,-1038 # 80038390 <tickslock>
    800027a6:	8526                	mv	a0,s1
    800027a8:	e64fe0ef          	jal	80000e0c <acquire>
    ticks++;
    800027ac:	00008517          	auipc	a0,0x8
    800027b0:	c9c50513          	addi	a0,a0,-868 # 8000a448 <ticks>
    800027b4:	411c                	lw	a5,0(a0)
    800027b6:	2785                	addiw	a5,a5,1
    800027b8:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800027ba:	a53ff0ef          	jal	8000220c <wakeup>
    release(&tickslock);
    800027be:	8526                	mv	a0,s1
    800027c0:	ee4fe0ef          	jal	80000ea4 <release>
    800027c4:	64a2                	ld	s1,8(sp)
    800027c6:	bf75                	j	80002782 <clockintr+0xe>

00000000800027c8 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800027c8:	1101                	addi	sp,sp,-32
    800027ca:	ec06                	sd	ra,24(sp)
    800027cc:	e822                	sd	s0,16(sp)
    800027ce:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027d0:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    800027d4:	57fd                	li	a5,-1
    800027d6:	17fe                	slli	a5,a5,0x3f
    800027d8:	07a5                	addi	a5,a5,9
    800027da:	00f70c63          	beq	a4,a5,800027f2 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    800027de:	57fd                	li	a5,-1
    800027e0:	17fe                	slli	a5,a5,0x3f
    800027e2:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800027e4:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    800027e6:	04f70763          	beq	a4,a5,80002834 <devintr+0x6c>
  }
}
    800027ea:	60e2                	ld	ra,24(sp)
    800027ec:	6442                	ld	s0,16(sp)
    800027ee:	6105                	addi	sp,sp,32
    800027f0:	8082                	ret
    800027f2:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800027f4:	719020ef          	jal	8000570c <plic_claim>
    800027f8:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    800027fa:	47a9                	li	a5,10
    800027fc:	00f50963          	beq	a0,a5,8000280e <devintr+0x46>
    } else if(irq == VIRTIO0_IRQ){
    80002800:	4785                	li	a5,1
    80002802:	00f50963          	beq	a0,a5,80002814 <devintr+0x4c>
    return 1;
    80002806:	4505                	li	a0,1
    } else if(irq){
    80002808:	e889                	bnez	s1,8000281a <devintr+0x52>
    8000280a:	64a2                	ld	s1,8(sp)
    8000280c:	bff9                	j	800027ea <devintr+0x22>
      uartintr();
    8000280e:	9a2fe0ef          	jal	800009b0 <uartintr>
    if(irq)
    80002812:	a819                	j	80002828 <devintr+0x60>
      virtio_disk_intr();
    80002814:	3be030ef          	jal	80005bd2 <virtio_disk_intr>
    if(irq)
    80002818:	a801                	j	80002828 <devintr+0x60>
      printf("unexpected interrupt irq=%d\n", irq);
    8000281a:	85a6                	mv	a1,s1
    8000281c:	00005517          	auipc	a0,0x5
    80002820:	b9450513          	addi	a0,a0,-1132 # 800073b0 <etext+0x3b0>
    80002824:	cd7fd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    80002828:	8526                	mv	a0,s1
    8000282a:	703020ef          	jal	8000572c <plic_complete>
    return 1;
    8000282e:	4505                	li	a0,1
    80002830:	64a2                	ld	s1,8(sp)
    80002832:	bf65                	j	800027ea <devintr+0x22>
    clockintr();
    80002834:	f41ff0ef          	jal	80002774 <clockintr>
    return 2;
    80002838:	4509                	li	a0,2
    8000283a:	bf45                	j	800027ea <devintr+0x22>

000000008000283c <usertrap>:
{
    8000283c:	1101                	addi	sp,sp,-32
    8000283e:	ec06                	sd	ra,24(sp)
    80002840:	e822                	sd	s0,16(sp)
    80002842:	e426                	sd	s1,8(sp)
    80002844:	e04a                	sd	s2,0(sp)
    80002846:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002848:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    8000284c:	1007f793          	andi	a5,a5,256
    80002850:	eba5                	bnez	a5,800028c0 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002852:	00003797          	auipc	a5,0x3
    80002856:	e0e78793          	addi	a5,a5,-498 # 80005660 <kernelvec>
    8000285a:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000285e:	b6aff0ef          	jal	80001bc8 <myproc>
    80002862:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002864:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002866:	14102773          	csrr	a4,sepc
    8000286a:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000286c:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80002870:	47a1                	li	a5,8
    80002872:	04f70d63          	beq	a4,a5,800028cc <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    80002876:	f53ff0ef          	jal	800027c8 <devintr>
    8000287a:	892a                	mv	s2,a0
    8000287c:	e945                	bnez	a0,8000292c <usertrap+0xf0>
    8000287e:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002882:	47bd                	li	a5,15
    80002884:	08f70863          	beq	a4,a5,80002914 <usertrap+0xd8>
    80002888:	14202773          	csrr	a4,scause
    8000288c:	47b5                	li	a5,13
    8000288e:	08f70363          	beq	a4,a5,80002914 <usertrap+0xd8>
    80002892:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002896:	5890                	lw	a2,48(s1)
    80002898:	00005517          	auipc	a0,0x5
    8000289c:	b5850513          	addi	a0,a0,-1192 # 800073f0 <etext+0x3f0>
    800028a0:	c5bfd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800028a4:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800028a8:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800028ac:	00005517          	auipc	a0,0x5
    800028b0:	b7450513          	addi	a0,a0,-1164 # 80007420 <etext+0x420>
    800028b4:	c47fd0ef          	jal	800004fa <printf>
    setkilled(p);
    800028b8:	8526                	mv	a0,s1
    800028ba:	b1bff0ef          	jal	800023d4 <setkilled>
    800028be:	a035                	j	800028ea <usertrap+0xae>
    panic("usertrap: not from user mode");
    800028c0:	00005517          	auipc	a0,0x5
    800028c4:	b1050513          	addi	a0,a0,-1264 # 800073d0 <etext+0x3d0>
    800028c8:	f19fd0ef          	jal	800007e0 <panic>
    if(killed(p))
    800028cc:	b2dff0ef          	jal	800023f8 <killed>
    800028d0:	ed15                	bnez	a0,8000290c <usertrap+0xd0>
    p->trapframe->epc += 4;
    800028d2:	6cb8                	ld	a4,88(s1)
    800028d4:	6f1c                	ld	a5,24(a4)
    800028d6:	0791                	addi	a5,a5,4
    800028d8:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028da:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800028de:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800028e2:	10079073          	csrw	sstatus,a5
    syscall();
    800028e6:	246000ef          	jal	80002b2c <syscall>
  if(killed(p))
    800028ea:	8526                	mv	a0,s1
    800028ec:	b0dff0ef          	jal	800023f8 <killed>
    800028f0:	e139                	bnez	a0,80002936 <usertrap+0xfa>
  prepare_return();
    800028f2:	e09ff0ef          	jal	800026fa <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800028f6:	68a8                	ld	a0,80(s1)
    800028f8:	8131                	srli	a0,a0,0xc
    800028fa:	57fd                	li	a5,-1
    800028fc:	17fe                	slli	a5,a5,0x3f
    800028fe:	8d5d                	or	a0,a0,a5
}
    80002900:	60e2                	ld	ra,24(sp)
    80002902:	6442                	ld	s0,16(sp)
    80002904:	64a2                	ld	s1,8(sp)
    80002906:	6902                	ld	s2,0(sp)
    80002908:	6105                	addi	sp,sp,32
    8000290a:	8082                	ret
      kexit(-1);
    8000290c:	557d                	li	a0,-1
    8000290e:	9bfff0ef          	jal	800022cc <kexit>
    80002912:	b7c1                	j	800028d2 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002914:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002918:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    8000291c:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    8000291e:	00163613          	seqz	a2,a2
    80002922:	68a8                	ld	a0,80(s1)
    80002924:	e55fe0ef          	jal	80001778 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002928:	f169                	bnez	a0,800028ea <usertrap+0xae>
    8000292a:	b7a5                	j	80002892 <usertrap+0x56>
  if(killed(p))
    8000292c:	8526                	mv	a0,s1
    8000292e:	acbff0ef          	jal	800023f8 <killed>
    80002932:	c511                	beqz	a0,8000293e <usertrap+0x102>
    80002934:	a011                	j	80002938 <usertrap+0xfc>
    80002936:	4901                	li	s2,0
    kexit(-1);
    80002938:	557d                	li	a0,-1
    8000293a:	993ff0ef          	jal	800022cc <kexit>
  if(which_dev == 2)
    8000293e:	4789                	li	a5,2
    80002940:	faf919e3          	bne	s2,a5,800028f2 <usertrap+0xb6>
    yield();
    80002944:	851ff0ef          	jal	80002194 <yield>
    80002948:	b76d                	j	800028f2 <usertrap+0xb6>

000000008000294a <kerneltrap>:
{
    8000294a:	7179                	addi	sp,sp,-48
    8000294c:	f406                	sd	ra,40(sp)
    8000294e:	f022                	sd	s0,32(sp)
    80002950:	ec26                	sd	s1,24(sp)
    80002952:	e84a                	sd	s2,16(sp)
    80002954:	e44e                	sd	s3,8(sp)
    80002956:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002958:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000295c:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002960:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80002964:	1004f793          	andi	a5,s1,256
    80002968:	c795                	beqz	a5,80002994 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000296a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000296e:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002970:	eb85                	bnez	a5,800029a0 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    80002972:	e57ff0ef          	jal	800027c8 <devintr>
    80002976:	c91d                	beqz	a0,800029ac <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    80002978:	4789                	li	a5,2
    8000297a:	04f50a63          	beq	a0,a5,800029ce <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000297e:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002982:	10049073          	csrw	sstatus,s1
}
    80002986:	70a2                	ld	ra,40(sp)
    80002988:	7402                	ld	s0,32(sp)
    8000298a:	64e2                	ld	s1,24(sp)
    8000298c:	6942                	ld	s2,16(sp)
    8000298e:	69a2                	ld	s3,8(sp)
    80002990:	6145                	addi	sp,sp,48
    80002992:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002994:	00005517          	auipc	a0,0x5
    80002998:	ab450513          	addi	a0,a0,-1356 # 80007448 <etext+0x448>
    8000299c:	e45fd0ef          	jal	800007e0 <panic>
    panic("kerneltrap: interrupts enabled");
    800029a0:	00005517          	auipc	a0,0x5
    800029a4:	ad050513          	addi	a0,a0,-1328 # 80007470 <etext+0x470>
    800029a8:	e39fd0ef          	jal	800007e0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029ac:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800029b0:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800029b4:	85ce                	mv	a1,s3
    800029b6:	00005517          	auipc	a0,0x5
    800029ba:	ada50513          	addi	a0,a0,-1318 # 80007490 <etext+0x490>
    800029be:	b3dfd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    800029c2:	00005517          	auipc	a0,0x5
    800029c6:	af650513          	addi	a0,a0,-1290 # 800074b8 <etext+0x4b8>
    800029ca:	e17fd0ef          	jal	800007e0 <panic>
  if(which_dev == 2 && myproc() != 0)
    800029ce:	9faff0ef          	jal	80001bc8 <myproc>
    800029d2:	d555                	beqz	a0,8000297e <kerneltrap+0x34>
    yield();
    800029d4:	fc0ff0ef          	jal	80002194 <yield>
    800029d8:	b75d                	j	8000297e <kerneltrap+0x34>

00000000800029da <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800029da:	1101                	addi	sp,sp,-32
    800029dc:	ec06                	sd	ra,24(sp)
    800029de:	e822                	sd	s0,16(sp)
    800029e0:	e426                	sd	s1,8(sp)
    800029e2:	1000                	addi	s0,sp,32
    800029e4:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800029e6:	9e2ff0ef          	jal	80001bc8 <myproc>
  switch (n) {
    800029ea:	4795                	li	a5,5
    800029ec:	0497e163          	bltu	a5,s1,80002a2e <argraw+0x54>
    800029f0:	048a                	slli	s1,s1,0x2
    800029f2:	00005717          	auipc	a4,0x5
    800029f6:	ec670713          	addi	a4,a4,-314 # 800078b8 <states.0+0x30>
    800029fa:	94ba                	add	s1,s1,a4
    800029fc:	409c                	lw	a5,0(s1)
    800029fe:	97ba                	add	a5,a5,a4
    80002a00:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002a02:	6d3c                	ld	a5,88(a0)
    80002a04:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002a06:	60e2                	ld	ra,24(sp)
    80002a08:	6442                	ld	s0,16(sp)
    80002a0a:	64a2                	ld	s1,8(sp)
    80002a0c:	6105                	addi	sp,sp,32
    80002a0e:	8082                	ret
    return p->trapframe->a1;
    80002a10:	6d3c                	ld	a5,88(a0)
    80002a12:	7fa8                	ld	a0,120(a5)
    80002a14:	bfcd                	j	80002a06 <argraw+0x2c>
    return p->trapframe->a2;
    80002a16:	6d3c                	ld	a5,88(a0)
    80002a18:	63c8                	ld	a0,128(a5)
    80002a1a:	b7f5                	j	80002a06 <argraw+0x2c>
    return p->trapframe->a3;
    80002a1c:	6d3c                	ld	a5,88(a0)
    80002a1e:	67c8                	ld	a0,136(a5)
    80002a20:	b7dd                	j	80002a06 <argraw+0x2c>
    return p->trapframe->a4;
    80002a22:	6d3c                	ld	a5,88(a0)
    80002a24:	6bc8                	ld	a0,144(a5)
    80002a26:	b7c5                	j	80002a06 <argraw+0x2c>
    return p->trapframe->a5;
    80002a28:	6d3c                	ld	a5,88(a0)
    80002a2a:	6fc8                	ld	a0,152(a5)
    80002a2c:	bfe9                	j	80002a06 <argraw+0x2c>
  panic("argraw");
    80002a2e:	00005517          	auipc	a0,0x5
    80002a32:	a9a50513          	addi	a0,a0,-1382 # 800074c8 <etext+0x4c8>
    80002a36:	dabfd0ef          	jal	800007e0 <panic>

0000000080002a3a <fetchaddr>:
{
    80002a3a:	1101                	addi	sp,sp,-32
    80002a3c:	ec06                	sd	ra,24(sp)
    80002a3e:	e822                	sd	s0,16(sp)
    80002a40:	e426                	sd	s1,8(sp)
    80002a42:	e04a                	sd	s2,0(sp)
    80002a44:	1000                	addi	s0,sp,32
    80002a46:	84aa                	mv	s1,a0
    80002a48:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002a4a:	97eff0ef          	jal	80001bc8 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002a4e:	653c                	ld	a5,72(a0)
    80002a50:	02f4f663          	bgeu	s1,a5,80002a7c <fetchaddr+0x42>
    80002a54:	00848713          	addi	a4,s1,8
    80002a58:	02e7e463          	bltu	a5,a4,80002a80 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002a5c:	46a1                	li	a3,8
    80002a5e:	8626                	mv	a2,s1
    80002a60:	85ca                	mv	a1,s2
    80002a62:	6928                	ld	a0,80(a0)
    80002a64:	f3dfe0ef          	jal	800019a0 <copyin>
    80002a68:	00a03533          	snez	a0,a0
    80002a6c:	40a00533          	neg	a0,a0
}
    80002a70:	60e2                	ld	ra,24(sp)
    80002a72:	6442                	ld	s0,16(sp)
    80002a74:	64a2                	ld	s1,8(sp)
    80002a76:	6902                	ld	s2,0(sp)
    80002a78:	6105                	addi	sp,sp,32
    80002a7a:	8082                	ret
    return -1;
    80002a7c:	557d                	li	a0,-1
    80002a7e:	bfcd                	j	80002a70 <fetchaddr+0x36>
    80002a80:	557d                	li	a0,-1
    80002a82:	b7fd                	j	80002a70 <fetchaddr+0x36>

0000000080002a84 <fetchstr>:
{
    80002a84:	7179                	addi	sp,sp,-48
    80002a86:	f406                	sd	ra,40(sp)
    80002a88:	f022                	sd	s0,32(sp)
    80002a8a:	ec26                	sd	s1,24(sp)
    80002a8c:	e84a                	sd	s2,16(sp)
    80002a8e:	e44e                	sd	s3,8(sp)
    80002a90:	1800                	addi	s0,sp,48
    80002a92:	892a                	mv	s2,a0
    80002a94:	84ae                	mv	s1,a1
    80002a96:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002a98:	930ff0ef          	jal	80001bc8 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002a9c:	86ce                	mv	a3,s3
    80002a9e:	864a                	mv	a2,s2
    80002aa0:	85a6                	mv	a1,s1
    80002aa2:	6928                	ld	a0,80(a0)
    80002aa4:	c1dfe0ef          	jal	800016c0 <copyinstr>
    80002aa8:	00054c63          	bltz	a0,80002ac0 <fetchstr+0x3c>
  return strlen(buf);
    80002aac:	8526                	mv	a0,s1
    80002aae:	da2fe0ef          	jal	80001050 <strlen>
}
    80002ab2:	70a2                	ld	ra,40(sp)
    80002ab4:	7402                	ld	s0,32(sp)
    80002ab6:	64e2                	ld	s1,24(sp)
    80002ab8:	6942                	ld	s2,16(sp)
    80002aba:	69a2                	ld	s3,8(sp)
    80002abc:	6145                	addi	sp,sp,48
    80002abe:	8082                	ret
    return -1;
    80002ac0:	557d                	li	a0,-1
    80002ac2:	bfc5                	j	80002ab2 <fetchstr+0x2e>

0000000080002ac4 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002ac4:	1101                	addi	sp,sp,-32
    80002ac6:	ec06                	sd	ra,24(sp)
    80002ac8:	e822                	sd	s0,16(sp)
    80002aca:	e426                	sd	s1,8(sp)
    80002acc:	1000                	addi	s0,sp,32
    80002ace:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002ad0:	f0bff0ef          	jal	800029da <argraw>
    80002ad4:	c088                	sw	a0,0(s1)
}
    80002ad6:	60e2                	ld	ra,24(sp)
    80002ad8:	6442                	ld	s0,16(sp)
    80002ada:	64a2                	ld	s1,8(sp)
    80002adc:	6105                	addi	sp,sp,32
    80002ade:	8082                	ret

0000000080002ae0 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002ae0:	1101                	addi	sp,sp,-32
    80002ae2:	ec06                	sd	ra,24(sp)
    80002ae4:	e822                	sd	s0,16(sp)
    80002ae6:	e426                	sd	s1,8(sp)
    80002ae8:	1000                	addi	s0,sp,32
    80002aea:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002aec:	eefff0ef          	jal	800029da <argraw>
    80002af0:	e088                	sd	a0,0(s1)
}
    80002af2:	60e2                	ld	ra,24(sp)
    80002af4:	6442                	ld	s0,16(sp)
    80002af6:	64a2                	ld	s1,8(sp)
    80002af8:	6105                	addi	sp,sp,32
    80002afa:	8082                	ret

0000000080002afc <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002afc:	7179                	addi	sp,sp,-48
    80002afe:	f406                	sd	ra,40(sp)
    80002b00:	f022                	sd	s0,32(sp)
    80002b02:	ec26                	sd	s1,24(sp)
    80002b04:	e84a                	sd	s2,16(sp)
    80002b06:	1800                	addi	s0,sp,48
    80002b08:	84ae                	mv	s1,a1
    80002b0a:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002b0c:	fd840593          	addi	a1,s0,-40
    80002b10:	fd1ff0ef          	jal	80002ae0 <argaddr>
  return fetchstr(addr, buf, max);
    80002b14:	864a                	mv	a2,s2
    80002b16:	85a6                	mv	a1,s1
    80002b18:	fd843503          	ld	a0,-40(s0)
    80002b1c:	f69ff0ef          	jal	80002a84 <fetchstr>
}
    80002b20:	70a2                	ld	ra,40(sp)
    80002b22:	7402                	ld	s0,32(sp)
    80002b24:	64e2                	ld	s1,24(sp)
    80002b26:	6942                	ld	s2,16(sp)
    80002b28:	6145                	addi	sp,sp,48
    80002b2a:	8082                	ret

0000000080002b2c <syscall>:
[SYS_pgrefcount] sys_pgrefcount,
};

void
syscall(void)
{
    80002b2c:	1101                	addi	sp,sp,-32
    80002b2e:	ec06                	sd	ra,24(sp)
    80002b30:	e822                	sd	s0,16(sp)
    80002b32:	e426                	sd	s1,8(sp)
    80002b34:	e04a                	sd	s2,0(sp)
    80002b36:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002b38:	890ff0ef          	jal	80001bc8 <myproc>
    80002b3c:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002b3e:	05853903          	ld	s2,88(a0)
    80002b42:	0a893783          	ld	a5,168(s2)
    80002b46:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002b4a:	37fd                	addiw	a5,a5,-1
    80002b4c:	4755                	li	a4,21
    80002b4e:	00f76f63          	bltu	a4,a5,80002b6c <syscall+0x40>
    80002b52:	00369713          	slli	a4,a3,0x3
    80002b56:	00005797          	auipc	a5,0x5
    80002b5a:	d7a78793          	addi	a5,a5,-646 # 800078d0 <syscalls>
    80002b5e:	97ba                	add	a5,a5,a4
    80002b60:	639c                	ld	a5,0(a5)
    80002b62:	c789                	beqz	a5,80002b6c <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002b64:	9782                	jalr	a5
    80002b66:	06a93823          	sd	a0,112(s2)
    80002b6a:	a829                	j	80002b84 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002b6c:	15848613          	addi	a2,s1,344
    80002b70:	588c                	lw	a1,48(s1)
    80002b72:	00005517          	auipc	a0,0x5
    80002b76:	95e50513          	addi	a0,a0,-1698 # 800074d0 <etext+0x4d0>
    80002b7a:	981fd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002b7e:	6cbc                	ld	a5,88(s1)
    80002b80:	577d                	li	a4,-1
    80002b82:	fbb8                	sd	a4,112(a5)
  }
}
    80002b84:	60e2                	ld	ra,24(sp)
    80002b86:	6442                	ld	s0,16(sp)
    80002b88:	64a2                	ld	s1,8(sp)
    80002b8a:	6902                	ld	s2,0(sp)
    80002b8c:	6105                	addi	sp,sp,32
    80002b8e:	8082                	ret

0000000080002b90 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002b90:	1101                	addi	sp,sp,-32
    80002b92:	ec06                	sd	ra,24(sp)
    80002b94:	e822                	sd	s0,16(sp)
    80002b96:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002b98:	fec40593          	addi	a1,s0,-20
    80002b9c:	4501                	li	a0,0
    80002b9e:	f27ff0ef          	jal	80002ac4 <argint>
  kexit(n);
    80002ba2:	fec42503          	lw	a0,-20(s0)
    80002ba6:	f26ff0ef          	jal	800022cc <kexit>
  return 0;  // not reached
}
    80002baa:	4501                	li	a0,0
    80002bac:	60e2                	ld	ra,24(sp)
    80002bae:	6442                	ld	s0,16(sp)
    80002bb0:	6105                	addi	sp,sp,32
    80002bb2:	8082                	ret

0000000080002bb4 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002bb4:	1141                	addi	sp,sp,-16
    80002bb6:	e406                	sd	ra,8(sp)
    80002bb8:	e022                	sd	s0,0(sp)
    80002bba:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002bbc:	80cff0ef          	jal	80001bc8 <myproc>
}
    80002bc0:	5908                	lw	a0,48(a0)
    80002bc2:	60a2                	ld	ra,8(sp)
    80002bc4:	6402                	ld	s0,0(sp)
    80002bc6:	0141                	addi	sp,sp,16
    80002bc8:	8082                	ret

0000000080002bca <sys_fork>:

uint64
sys_fork(void)
{
    80002bca:	1141                	addi	sp,sp,-16
    80002bcc:	e406                	sd	ra,8(sp)
    80002bce:	e022                	sd	s0,0(sp)
    80002bd0:	0800                	addi	s0,sp,16
  return kfork();
    80002bd2:	b48ff0ef          	jal	80001f1a <kfork>
}
    80002bd6:	60a2                	ld	ra,8(sp)
    80002bd8:	6402                	ld	s0,0(sp)
    80002bda:	0141                	addi	sp,sp,16
    80002bdc:	8082                	ret

0000000080002bde <sys_wait>:

uint64
sys_wait(void)
{
    80002bde:	1101                	addi	sp,sp,-32
    80002be0:	ec06                	sd	ra,24(sp)
    80002be2:	e822                	sd	s0,16(sp)
    80002be4:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002be6:	fe840593          	addi	a1,s0,-24
    80002bea:	4501                	li	a0,0
    80002bec:	ef5ff0ef          	jal	80002ae0 <argaddr>
  return kwait(p);
    80002bf0:	fe843503          	ld	a0,-24(s0)
    80002bf4:	82fff0ef          	jal	80002422 <kwait>
}
    80002bf8:	60e2                	ld	ra,24(sp)
    80002bfa:	6442                	ld	s0,16(sp)
    80002bfc:	6105                	addi	sp,sp,32
    80002bfe:	8082                	ret

0000000080002c00 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002c00:	7179                	addi	sp,sp,-48
    80002c02:	f406                	sd	ra,40(sp)
    80002c04:	f022                	sd	s0,32(sp)
    80002c06:	ec26                	sd	s1,24(sp)
    80002c08:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002c0a:	fd840593          	addi	a1,s0,-40
    80002c0e:	4501                	li	a0,0
    80002c10:	eb5ff0ef          	jal	80002ac4 <argint>
  argint(1, &t);
    80002c14:	fdc40593          	addi	a1,s0,-36
    80002c18:	4505                	li	a0,1
    80002c1a:	eabff0ef          	jal	80002ac4 <argint>
  addr = myproc()->sz;
    80002c1e:	fabfe0ef          	jal	80001bc8 <myproc>
    80002c22:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002c24:	fdc42703          	lw	a4,-36(s0)
    80002c28:	4785                	li	a5,1
    80002c2a:	02f70163          	beq	a4,a5,80002c4c <sys_sbrk+0x4c>
    80002c2e:	fd842783          	lw	a5,-40(s0)
    80002c32:	0007cd63          	bltz	a5,80002c4c <sys_sbrk+0x4c>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002c36:	97a6                	add	a5,a5,s1
    80002c38:	0297e863          	bltu	a5,s1,80002c68 <sys_sbrk+0x68>
      return -1;
    myproc()->sz += n;
    80002c3c:	f8dfe0ef          	jal	80001bc8 <myproc>
    80002c40:	fd842703          	lw	a4,-40(s0)
    80002c44:	653c                	ld	a5,72(a0)
    80002c46:	97ba                	add	a5,a5,a4
    80002c48:	e53c                	sd	a5,72(a0)
    80002c4a:	a039                	j	80002c58 <sys_sbrk+0x58>
    if(growproc(n) < 0) {
    80002c4c:	fd842503          	lw	a0,-40(s0)
    80002c50:	a7aff0ef          	jal	80001eca <growproc>
    80002c54:	00054863          	bltz	a0,80002c64 <sys_sbrk+0x64>
  }
  return addr;
}
    80002c58:	8526                	mv	a0,s1
    80002c5a:	70a2                	ld	ra,40(sp)
    80002c5c:	7402                	ld	s0,32(sp)
    80002c5e:	64e2                	ld	s1,24(sp)
    80002c60:	6145                	addi	sp,sp,48
    80002c62:	8082                	ret
      return -1;
    80002c64:	54fd                	li	s1,-1
    80002c66:	bfcd                	j	80002c58 <sys_sbrk+0x58>
      return -1;
    80002c68:	54fd                	li	s1,-1
    80002c6a:	b7fd                	j	80002c58 <sys_sbrk+0x58>

0000000080002c6c <sys_pause>:

uint64
sys_pause(void)
{
    80002c6c:	7139                	addi	sp,sp,-64
    80002c6e:	fc06                	sd	ra,56(sp)
    80002c70:	f822                	sd	s0,48(sp)
    80002c72:	f04a                	sd	s2,32(sp)
    80002c74:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002c76:	fcc40593          	addi	a1,s0,-52
    80002c7a:	4501                	li	a0,0
    80002c7c:	e49ff0ef          	jal	80002ac4 <argint>
  if(n < 0)
    80002c80:	fcc42783          	lw	a5,-52(s0)
    80002c84:	0607c763          	bltz	a5,80002cf2 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002c88:	00035517          	auipc	a0,0x35
    80002c8c:	70850513          	addi	a0,a0,1800 # 80038390 <tickslock>
    80002c90:	97cfe0ef          	jal	80000e0c <acquire>
  ticks0 = ticks;
    80002c94:	00007917          	auipc	s2,0x7
    80002c98:	7b492903          	lw	s2,1972(s2) # 8000a448 <ticks>
  while(ticks - ticks0 < n){
    80002c9c:	fcc42783          	lw	a5,-52(s0)
    80002ca0:	cf8d                	beqz	a5,80002cda <sys_pause+0x6e>
    80002ca2:	f426                	sd	s1,40(sp)
    80002ca4:	ec4e                	sd	s3,24(sp)
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002ca6:	00035997          	auipc	s3,0x35
    80002caa:	6ea98993          	addi	s3,s3,1770 # 80038390 <tickslock>
    80002cae:	00007497          	auipc	s1,0x7
    80002cb2:	79a48493          	addi	s1,s1,1946 # 8000a448 <ticks>
    if(killed(myproc())){
    80002cb6:	f13fe0ef          	jal	80001bc8 <myproc>
    80002cba:	f3eff0ef          	jal	800023f8 <killed>
    80002cbe:	ed0d                	bnez	a0,80002cf8 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002cc0:	85ce                	mv	a1,s3
    80002cc2:	8526                	mv	a0,s1
    80002cc4:	cfcff0ef          	jal	800021c0 <sleep>
  while(ticks - ticks0 < n){
    80002cc8:	409c                	lw	a5,0(s1)
    80002cca:	412787bb          	subw	a5,a5,s2
    80002cce:	fcc42703          	lw	a4,-52(s0)
    80002cd2:	fee7e2e3          	bltu	a5,a4,80002cb6 <sys_pause+0x4a>
    80002cd6:	74a2                	ld	s1,40(sp)
    80002cd8:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002cda:	00035517          	auipc	a0,0x35
    80002cde:	6b650513          	addi	a0,a0,1718 # 80038390 <tickslock>
    80002ce2:	9c2fe0ef          	jal	80000ea4 <release>
  return 0;
    80002ce6:	4501                	li	a0,0
}
    80002ce8:	70e2                	ld	ra,56(sp)
    80002cea:	7442                	ld	s0,48(sp)
    80002cec:	7902                	ld	s2,32(sp)
    80002cee:	6121                	addi	sp,sp,64
    80002cf0:	8082                	ret
    n = 0;
    80002cf2:	fc042623          	sw	zero,-52(s0)
    80002cf6:	bf49                	j	80002c88 <sys_pause+0x1c>
      release(&tickslock);
    80002cf8:	00035517          	auipc	a0,0x35
    80002cfc:	69850513          	addi	a0,a0,1688 # 80038390 <tickslock>
    80002d00:	9a4fe0ef          	jal	80000ea4 <release>
      return -1;
    80002d04:	557d                	li	a0,-1
    80002d06:	74a2                	ld	s1,40(sp)
    80002d08:	69e2                	ld	s3,24(sp)
    80002d0a:	bff9                	j	80002ce8 <sys_pause+0x7c>

0000000080002d0c <sys_kill>:

uint64
sys_kill(void)
{
    80002d0c:	1101                	addi	sp,sp,-32
    80002d0e:	ec06                	sd	ra,24(sp)
    80002d10:	e822                	sd	s0,16(sp)
    80002d12:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002d14:	fec40593          	addi	a1,s0,-20
    80002d18:	4501                	li	a0,0
    80002d1a:	dabff0ef          	jal	80002ac4 <argint>
  return kkill(pid);
    80002d1e:	fec42503          	lw	a0,-20(s0)
    80002d22:	e4cff0ef          	jal	8000236e <kkill>
}
    80002d26:	60e2                	ld	ra,24(sp)
    80002d28:	6442                	ld	s0,16(sp)
    80002d2a:	6105                	addi	sp,sp,32
    80002d2c:	8082                	ret

0000000080002d2e <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002d2e:	1101                	addi	sp,sp,-32
    80002d30:	ec06                	sd	ra,24(sp)
    80002d32:	e822                	sd	s0,16(sp)
    80002d34:	e426                	sd	s1,8(sp)
    80002d36:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002d38:	00035517          	auipc	a0,0x35
    80002d3c:	65850513          	addi	a0,a0,1624 # 80038390 <tickslock>
    80002d40:	8ccfe0ef          	jal	80000e0c <acquire>
  xticks = ticks;
    80002d44:	00007497          	auipc	s1,0x7
    80002d48:	7044a483          	lw	s1,1796(s1) # 8000a448 <ticks>
  release(&tickslock);
    80002d4c:	00035517          	auipc	a0,0x35
    80002d50:	64450513          	addi	a0,a0,1604 # 80038390 <tickslock>
    80002d54:	950fe0ef          	jal	80000ea4 <release>
  return xticks;
}
    80002d58:	02049513          	slli	a0,s1,0x20
    80002d5c:	9101                	srli	a0,a0,0x20
    80002d5e:	60e2                	ld	ra,24(sp)
    80002d60:	6442                	ld	s0,16(sp)
    80002d62:	64a2                	ld	s1,8(sp)
    80002d64:	6105                	addi	sp,sp,32
    80002d66:	8082                	ret

0000000080002d68 <sys_pgrefcount>:
// Phase 4: expose the physical page refcount for a user virtual
// address, mainly so cowtest/demos can show COW sharing directly
// (e.g. refcount 2+ right after fork, back to 1 after a write).
uint64
sys_pgrefcount(void)
{
    80002d68:	7179                	addi	sp,sp,-48
    80002d6a:	f406                	sd	ra,40(sp)
    80002d6c:	f022                	sd	s0,32(sp)
    80002d6e:	ec26                	sd	s1,24(sp)
    80002d70:	1800                	addi	s0,sp,48
  uint64 va;
  uint64 pa;
  struct proc *p = myproc();
    80002d72:	e57fe0ef          	jal	80001bc8 <myproc>
    80002d76:	84aa                	mv	s1,a0

  argaddr(0, &va);
    80002d78:	fd840593          	addi	a1,s0,-40
    80002d7c:	4501                	li	a0,0
    80002d7e:	d63ff0ef          	jal	80002ae0 <argaddr>

  pa = walkaddr(p->pagetable, PGROUNDDOWN(va));
    80002d82:	75fd                	lui	a1,0xfffff
    80002d84:	fd843783          	ld	a5,-40(s0)
    80002d88:	8dfd                	and	a1,a1,a5
    80002d8a:	68a8                	ld	a0,80(s1)
    80002d8c:	c66fe0ef          	jal	800011f2 <walkaddr>
    80002d90:	87aa                	mv	a5,a0
  if(pa == 0)
    return -1;
    80002d92:	557d                	li	a0,-1
  if(pa == 0)
    80002d94:	c781                	beqz	a5,80002d9c <sys_pgrefcount+0x34>

  return getref(pa);
    80002d96:	853e                	mv	a0,a5
    80002d98:	ce1fd0ef          	jal	80000a78 <getref>
}
    80002d9c:	70a2                	ld	ra,40(sp)
    80002d9e:	7402                	ld	s0,32(sp)
    80002da0:	64e2                	ld	s1,24(sp)
    80002da2:	6145                	addi	sp,sp,48
    80002da4:	8082                	ret

0000000080002da6 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002da6:	7179                	addi	sp,sp,-48
    80002da8:	f406                	sd	ra,40(sp)
    80002daa:	f022                	sd	s0,32(sp)
    80002dac:	ec26                	sd	s1,24(sp)
    80002dae:	e84a                	sd	s2,16(sp)
    80002db0:	e44e                	sd	s3,8(sp)
    80002db2:	e052                	sd	s4,0(sp)
    80002db4:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002db6:	00004597          	auipc	a1,0x4
    80002dba:	73a58593          	addi	a1,a1,1850 # 800074f0 <etext+0x4f0>
    80002dbe:	00035517          	auipc	a0,0x35
    80002dc2:	5ea50513          	addi	a0,a0,1514 # 800383a8 <bcache>
    80002dc6:	fc7fd0ef          	jal	80000d8c <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002dca:	0003d797          	auipc	a5,0x3d
    80002dce:	5de78793          	addi	a5,a5,1502 # 800403a8 <bcache+0x8000>
    80002dd2:	0003e717          	auipc	a4,0x3e
    80002dd6:	83e70713          	addi	a4,a4,-1986 # 80040610 <bcache+0x8268>
    80002dda:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002dde:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002de2:	00035497          	auipc	s1,0x35
    80002de6:	5de48493          	addi	s1,s1,1502 # 800383c0 <bcache+0x18>
    b->next = bcache.head.next;
    80002dea:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002dec:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002dee:	00004a17          	auipc	s4,0x4
    80002df2:	70aa0a13          	addi	s4,s4,1802 # 800074f8 <etext+0x4f8>
    b->next = bcache.head.next;
    80002df6:	2b893783          	ld	a5,696(s2)
    80002dfa:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002dfc:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002e00:	85d2                	mv	a1,s4
    80002e02:	01048513          	addi	a0,s1,16
    80002e06:	322010ef          	jal	80004128 <initsleeplock>
    bcache.head.next->prev = b;
    80002e0a:	2b893783          	ld	a5,696(s2)
    80002e0e:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002e10:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002e14:	45848493          	addi	s1,s1,1112
    80002e18:	fd349fe3          	bne	s1,s3,80002df6 <binit+0x50>
  }
}
    80002e1c:	70a2                	ld	ra,40(sp)
    80002e1e:	7402                	ld	s0,32(sp)
    80002e20:	64e2                	ld	s1,24(sp)
    80002e22:	6942                	ld	s2,16(sp)
    80002e24:	69a2                	ld	s3,8(sp)
    80002e26:	6a02                	ld	s4,0(sp)
    80002e28:	6145                	addi	sp,sp,48
    80002e2a:	8082                	ret

0000000080002e2c <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002e2c:	7179                	addi	sp,sp,-48
    80002e2e:	f406                	sd	ra,40(sp)
    80002e30:	f022                	sd	s0,32(sp)
    80002e32:	ec26                	sd	s1,24(sp)
    80002e34:	e84a                	sd	s2,16(sp)
    80002e36:	e44e                	sd	s3,8(sp)
    80002e38:	1800                	addi	s0,sp,48
    80002e3a:	892a                	mv	s2,a0
    80002e3c:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002e3e:	00035517          	auipc	a0,0x35
    80002e42:	56a50513          	addi	a0,a0,1386 # 800383a8 <bcache>
    80002e46:	fc7fd0ef          	jal	80000e0c <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002e4a:	0003e497          	auipc	s1,0x3e
    80002e4e:	8164b483          	ld	s1,-2026(s1) # 80040660 <bcache+0x82b8>
    80002e52:	0003d797          	auipc	a5,0x3d
    80002e56:	7be78793          	addi	a5,a5,1982 # 80040610 <bcache+0x8268>
    80002e5a:	02f48b63          	beq	s1,a5,80002e90 <bread+0x64>
    80002e5e:	873e                	mv	a4,a5
    80002e60:	a021                	j	80002e68 <bread+0x3c>
    80002e62:	68a4                	ld	s1,80(s1)
    80002e64:	02e48663          	beq	s1,a4,80002e90 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002e68:	449c                	lw	a5,8(s1)
    80002e6a:	ff279ce3          	bne	a5,s2,80002e62 <bread+0x36>
    80002e6e:	44dc                	lw	a5,12(s1)
    80002e70:	ff3799e3          	bne	a5,s3,80002e62 <bread+0x36>
      b->refcnt++;
    80002e74:	40bc                	lw	a5,64(s1)
    80002e76:	2785                	addiw	a5,a5,1
    80002e78:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e7a:	00035517          	auipc	a0,0x35
    80002e7e:	52e50513          	addi	a0,a0,1326 # 800383a8 <bcache>
    80002e82:	822fe0ef          	jal	80000ea4 <release>
      acquiresleep(&b->lock);
    80002e86:	01048513          	addi	a0,s1,16
    80002e8a:	2d4010ef          	jal	8000415e <acquiresleep>
      return b;
    80002e8e:	a889                	j	80002ee0 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002e90:	0003d497          	auipc	s1,0x3d
    80002e94:	7c84b483          	ld	s1,1992(s1) # 80040658 <bcache+0x82b0>
    80002e98:	0003d797          	auipc	a5,0x3d
    80002e9c:	77878793          	addi	a5,a5,1912 # 80040610 <bcache+0x8268>
    80002ea0:	00f48863          	beq	s1,a5,80002eb0 <bread+0x84>
    80002ea4:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002ea6:	40bc                	lw	a5,64(s1)
    80002ea8:	cb91                	beqz	a5,80002ebc <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002eaa:	64a4                	ld	s1,72(s1)
    80002eac:	fee49de3          	bne	s1,a4,80002ea6 <bread+0x7a>
  panic("bget: no buffers");
    80002eb0:	00004517          	auipc	a0,0x4
    80002eb4:	65050513          	addi	a0,a0,1616 # 80007500 <etext+0x500>
    80002eb8:	929fd0ef          	jal	800007e0 <panic>
      b->dev = dev;
    80002ebc:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002ec0:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002ec4:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002ec8:	4785                	li	a5,1
    80002eca:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002ecc:	00035517          	auipc	a0,0x35
    80002ed0:	4dc50513          	addi	a0,a0,1244 # 800383a8 <bcache>
    80002ed4:	fd1fd0ef          	jal	80000ea4 <release>
      acquiresleep(&b->lock);
    80002ed8:	01048513          	addi	a0,s1,16
    80002edc:	282010ef          	jal	8000415e <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002ee0:	409c                	lw	a5,0(s1)
    80002ee2:	cb89                	beqz	a5,80002ef4 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002ee4:	8526                	mv	a0,s1
    80002ee6:	70a2                	ld	ra,40(sp)
    80002ee8:	7402                	ld	s0,32(sp)
    80002eea:	64e2                	ld	s1,24(sp)
    80002eec:	6942                	ld	s2,16(sp)
    80002eee:	69a2                	ld	s3,8(sp)
    80002ef0:	6145                	addi	sp,sp,48
    80002ef2:	8082                	ret
    virtio_disk_rw(b, 0);
    80002ef4:	4581                	li	a1,0
    80002ef6:	8526                	mv	a0,s1
    80002ef8:	2c9020ef          	jal	800059c0 <virtio_disk_rw>
    b->valid = 1;
    80002efc:	4785                	li	a5,1
    80002efe:	c09c                	sw	a5,0(s1)
  return b;
    80002f00:	b7d5                	j	80002ee4 <bread+0xb8>

0000000080002f02 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002f02:	1101                	addi	sp,sp,-32
    80002f04:	ec06                	sd	ra,24(sp)
    80002f06:	e822                	sd	s0,16(sp)
    80002f08:	e426                	sd	s1,8(sp)
    80002f0a:	1000                	addi	s0,sp,32
    80002f0c:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002f0e:	0541                	addi	a0,a0,16
    80002f10:	2cc010ef          	jal	800041dc <holdingsleep>
    80002f14:	c911                	beqz	a0,80002f28 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002f16:	4585                	li	a1,1
    80002f18:	8526                	mv	a0,s1
    80002f1a:	2a7020ef          	jal	800059c0 <virtio_disk_rw>
}
    80002f1e:	60e2                	ld	ra,24(sp)
    80002f20:	6442                	ld	s0,16(sp)
    80002f22:	64a2                	ld	s1,8(sp)
    80002f24:	6105                	addi	sp,sp,32
    80002f26:	8082                	ret
    panic("bwrite");
    80002f28:	00004517          	auipc	a0,0x4
    80002f2c:	5f050513          	addi	a0,a0,1520 # 80007518 <etext+0x518>
    80002f30:	8b1fd0ef          	jal	800007e0 <panic>

0000000080002f34 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002f34:	1101                	addi	sp,sp,-32
    80002f36:	ec06                	sd	ra,24(sp)
    80002f38:	e822                	sd	s0,16(sp)
    80002f3a:	e426                	sd	s1,8(sp)
    80002f3c:	e04a                	sd	s2,0(sp)
    80002f3e:	1000                	addi	s0,sp,32
    80002f40:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002f42:	01050913          	addi	s2,a0,16
    80002f46:	854a                	mv	a0,s2
    80002f48:	294010ef          	jal	800041dc <holdingsleep>
    80002f4c:	c135                	beqz	a0,80002fb0 <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002f4e:	854a                	mv	a0,s2
    80002f50:	254010ef          	jal	800041a4 <releasesleep>

  acquire(&bcache.lock);
    80002f54:	00035517          	auipc	a0,0x35
    80002f58:	45450513          	addi	a0,a0,1108 # 800383a8 <bcache>
    80002f5c:	eb1fd0ef          	jal	80000e0c <acquire>
  b->refcnt--;
    80002f60:	40bc                	lw	a5,64(s1)
    80002f62:	37fd                	addiw	a5,a5,-1
    80002f64:	0007871b          	sext.w	a4,a5
    80002f68:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002f6a:	e71d                	bnez	a4,80002f98 <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002f6c:	68b8                	ld	a4,80(s1)
    80002f6e:	64bc                	ld	a5,72(s1)
    80002f70:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002f72:	68b8                	ld	a4,80(s1)
    80002f74:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002f76:	0003d797          	auipc	a5,0x3d
    80002f7a:	43278793          	addi	a5,a5,1074 # 800403a8 <bcache+0x8000>
    80002f7e:	2b87b703          	ld	a4,696(a5)
    80002f82:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002f84:	0003d717          	auipc	a4,0x3d
    80002f88:	68c70713          	addi	a4,a4,1676 # 80040610 <bcache+0x8268>
    80002f8c:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002f8e:	2b87b703          	ld	a4,696(a5)
    80002f92:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002f94:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002f98:	00035517          	auipc	a0,0x35
    80002f9c:	41050513          	addi	a0,a0,1040 # 800383a8 <bcache>
    80002fa0:	f05fd0ef          	jal	80000ea4 <release>
}
    80002fa4:	60e2                	ld	ra,24(sp)
    80002fa6:	6442                	ld	s0,16(sp)
    80002fa8:	64a2                	ld	s1,8(sp)
    80002faa:	6902                	ld	s2,0(sp)
    80002fac:	6105                	addi	sp,sp,32
    80002fae:	8082                	ret
    panic("brelse");
    80002fb0:	00004517          	auipc	a0,0x4
    80002fb4:	57050513          	addi	a0,a0,1392 # 80007520 <etext+0x520>
    80002fb8:	829fd0ef          	jal	800007e0 <panic>

0000000080002fbc <bpin>:

void
bpin(struct buf *b) {
    80002fbc:	1101                	addi	sp,sp,-32
    80002fbe:	ec06                	sd	ra,24(sp)
    80002fc0:	e822                	sd	s0,16(sp)
    80002fc2:	e426                	sd	s1,8(sp)
    80002fc4:	1000                	addi	s0,sp,32
    80002fc6:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002fc8:	00035517          	auipc	a0,0x35
    80002fcc:	3e050513          	addi	a0,a0,992 # 800383a8 <bcache>
    80002fd0:	e3dfd0ef          	jal	80000e0c <acquire>
  b->refcnt++;
    80002fd4:	40bc                	lw	a5,64(s1)
    80002fd6:	2785                	addiw	a5,a5,1
    80002fd8:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002fda:	00035517          	auipc	a0,0x35
    80002fde:	3ce50513          	addi	a0,a0,974 # 800383a8 <bcache>
    80002fe2:	ec3fd0ef          	jal	80000ea4 <release>
}
    80002fe6:	60e2                	ld	ra,24(sp)
    80002fe8:	6442                	ld	s0,16(sp)
    80002fea:	64a2                	ld	s1,8(sp)
    80002fec:	6105                	addi	sp,sp,32
    80002fee:	8082                	ret

0000000080002ff0 <bunpin>:

void
bunpin(struct buf *b) {
    80002ff0:	1101                	addi	sp,sp,-32
    80002ff2:	ec06                	sd	ra,24(sp)
    80002ff4:	e822                	sd	s0,16(sp)
    80002ff6:	e426                	sd	s1,8(sp)
    80002ff8:	1000                	addi	s0,sp,32
    80002ffa:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002ffc:	00035517          	auipc	a0,0x35
    80003000:	3ac50513          	addi	a0,a0,940 # 800383a8 <bcache>
    80003004:	e09fd0ef          	jal	80000e0c <acquire>
  b->refcnt--;
    80003008:	40bc                	lw	a5,64(s1)
    8000300a:	37fd                	addiw	a5,a5,-1
    8000300c:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000300e:	00035517          	auipc	a0,0x35
    80003012:	39a50513          	addi	a0,a0,922 # 800383a8 <bcache>
    80003016:	e8ffd0ef          	jal	80000ea4 <release>
}
    8000301a:	60e2                	ld	ra,24(sp)
    8000301c:	6442                	ld	s0,16(sp)
    8000301e:	64a2                	ld	s1,8(sp)
    80003020:	6105                	addi	sp,sp,32
    80003022:	8082                	ret

0000000080003024 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003024:	1101                	addi	sp,sp,-32
    80003026:	ec06                	sd	ra,24(sp)
    80003028:	e822                	sd	s0,16(sp)
    8000302a:	e426                	sd	s1,8(sp)
    8000302c:	e04a                	sd	s2,0(sp)
    8000302e:	1000                	addi	s0,sp,32
    80003030:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80003032:	00d5d59b          	srliw	a1,a1,0xd
    80003036:	0003e797          	auipc	a5,0x3e
    8000303a:	a4e7a783          	lw	a5,-1458(a5) # 80040a84 <sb+0x1c>
    8000303e:	9dbd                	addw	a1,a1,a5
    80003040:	dedff0ef          	jal	80002e2c <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003044:	0074f713          	andi	a4,s1,7
    80003048:	4785                	li	a5,1
    8000304a:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    8000304e:	14ce                	slli	s1,s1,0x33
    80003050:	90d9                	srli	s1,s1,0x36
    80003052:	00950733          	add	a4,a0,s1
    80003056:	05874703          	lbu	a4,88(a4)
    8000305a:	00e7f6b3          	and	a3,a5,a4
    8000305e:	c29d                	beqz	a3,80003084 <bfree+0x60>
    80003060:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80003062:	94aa                	add	s1,s1,a0
    80003064:	fff7c793          	not	a5,a5
    80003068:	8f7d                	and	a4,a4,a5
    8000306a:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    8000306e:	7f9000ef          	jal	80004066 <log_write>
  brelse(bp);
    80003072:	854a                	mv	a0,s2
    80003074:	ec1ff0ef          	jal	80002f34 <brelse>
}
    80003078:	60e2                	ld	ra,24(sp)
    8000307a:	6442                	ld	s0,16(sp)
    8000307c:	64a2                	ld	s1,8(sp)
    8000307e:	6902                	ld	s2,0(sp)
    80003080:	6105                	addi	sp,sp,32
    80003082:	8082                	ret
    panic("freeing free block");
    80003084:	00004517          	auipc	a0,0x4
    80003088:	4a450513          	addi	a0,a0,1188 # 80007528 <etext+0x528>
    8000308c:	f54fd0ef          	jal	800007e0 <panic>

0000000080003090 <balloc>:
{
    80003090:	711d                	addi	sp,sp,-96
    80003092:	ec86                	sd	ra,88(sp)
    80003094:	e8a2                	sd	s0,80(sp)
    80003096:	e4a6                	sd	s1,72(sp)
    80003098:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    8000309a:	0003e797          	auipc	a5,0x3e
    8000309e:	9d27a783          	lw	a5,-1582(a5) # 80040a6c <sb+0x4>
    800030a2:	0e078f63          	beqz	a5,800031a0 <balloc+0x110>
    800030a6:	e0ca                	sd	s2,64(sp)
    800030a8:	fc4e                	sd	s3,56(sp)
    800030aa:	f852                	sd	s4,48(sp)
    800030ac:	f456                	sd	s5,40(sp)
    800030ae:	f05a                	sd	s6,32(sp)
    800030b0:	ec5e                	sd	s7,24(sp)
    800030b2:	e862                	sd	s8,16(sp)
    800030b4:	e466                	sd	s9,8(sp)
    800030b6:	8baa                	mv	s7,a0
    800030b8:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800030ba:	0003eb17          	auipc	s6,0x3e
    800030be:	9aeb0b13          	addi	s6,s6,-1618 # 80040a68 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800030c2:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    800030c4:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800030c6:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800030c8:	6c89                	lui	s9,0x2
    800030ca:	a0b5                	j	80003136 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    800030cc:	97ca                	add	a5,a5,s2
    800030ce:	8e55                	or	a2,a2,a3
    800030d0:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800030d4:	854a                	mv	a0,s2
    800030d6:	791000ef          	jal	80004066 <log_write>
        brelse(bp);
    800030da:	854a                	mv	a0,s2
    800030dc:	e59ff0ef          	jal	80002f34 <brelse>
  bp = bread(dev, bno);
    800030e0:	85a6                	mv	a1,s1
    800030e2:	855e                	mv	a0,s7
    800030e4:	d49ff0ef          	jal	80002e2c <bread>
    800030e8:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800030ea:	40000613          	li	a2,1024
    800030ee:	4581                	li	a1,0
    800030f0:	05850513          	addi	a0,a0,88
    800030f4:	dedfd0ef          	jal	80000ee0 <memset>
  log_write(bp);
    800030f8:	854a                	mv	a0,s2
    800030fa:	76d000ef          	jal	80004066 <log_write>
  brelse(bp);
    800030fe:	854a                	mv	a0,s2
    80003100:	e35ff0ef          	jal	80002f34 <brelse>
}
    80003104:	6906                	ld	s2,64(sp)
    80003106:	79e2                	ld	s3,56(sp)
    80003108:	7a42                	ld	s4,48(sp)
    8000310a:	7aa2                	ld	s5,40(sp)
    8000310c:	7b02                	ld	s6,32(sp)
    8000310e:	6be2                	ld	s7,24(sp)
    80003110:	6c42                	ld	s8,16(sp)
    80003112:	6ca2                	ld	s9,8(sp)
}
    80003114:	8526                	mv	a0,s1
    80003116:	60e6                	ld	ra,88(sp)
    80003118:	6446                	ld	s0,80(sp)
    8000311a:	64a6                	ld	s1,72(sp)
    8000311c:	6125                	addi	sp,sp,96
    8000311e:	8082                	ret
    brelse(bp);
    80003120:	854a                	mv	a0,s2
    80003122:	e13ff0ef          	jal	80002f34 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80003126:	015c87bb          	addw	a5,s9,s5
    8000312a:	00078a9b          	sext.w	s5,a5
    8000312e:	004b2703          	lw	a4,4(s6)
    80003132:	04eaff63          	bgeu	s5,a4,80003190 <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    80003136:	41fad79b          	sraiw	a5,s5,0x1f
    8000313a:	0137d79b          	srliw	a5,a5,0x13
    8000313e:	015787bb          	addw	a5,a5,s5
    80003142:	40d7d79b          	sraiw	a5,a5,0xd
    80003146:	01cb2583          	lw	a1,28(s6)
    8000314a:	9dbd                	addw	a1,a1,a5
    8000314c:	855e                	mv	a0,s7
    8000314e:	cdfff0ef          	jal	80002e2c <bread>
    80003152:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003154:	004b2503          	lw	a0,4(s6)
    80003158:	000a849b          	sext.w	s1,s5
    8000315c:	8762                	mv	a4,s8
    8000315e:	fca4f1e3          	bgeu	s1,a0,80003120 <balloc+0x90>
      m = 1 << (bi % 8);
    80003162:	00777693          	andi	a3,a4,7
    80003166:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    8000316a:	41f7579b          	sraiw	a5,a4,0x1f
    8000316e:	01d7d79b          	srliw	a5,a5,0x1d
    80003172:	9fb9                	addw	a5,a5,a4
    80003174:	4037d79b          	sraiw	a5,a5,0x3
    80003178:	00f90633          	add	a2,s2,a5
    8000317c:	05864603          	lbu	a2,88(a2)
    80003180:	00c6f5b3          	and	a1,a3,a2
    80003184:	d5a1                	beqz	a1,800030cc <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003186:	2705                	addiw	a4,a4,1
    80003188:	2485                	addiw	s1,s1,1
    8000318a:	fd471ae3          	bne	a4,s4,8000315e <balloc+0xce>
    8000318e:	bf49                	j	80003120 <balloc+0x90>
    80003190:	6906                	ld	s2,64(sp)
    80003192:	79e2                	ld	s3,56(sp)
    80003194:	7a42                	ld	s4,48(sp)
    80003196:	7aa2                	ld	s5,40(sp)
    80003198:	7b02                	ld	s6,32(sp)
    8000319a:	6be2                	ld	s7,24(sp)
    8000319c:	6c42                	ld	s8,16(sp)
    8000319e:	6ca2                	ld	s9,8(sp)
  printf("balloc: out of blocks\n");
    800031a0:	00004517          	auipc	a0,0x4
    800031a4:	3a050513          	addi	a0,a0,928 # 80007540 <etext+0x540>
    800031a8:	b52fd0ef          	jal	800004fa <printf>
  return 0;
    800031ac:	4481                	li	s1,0
    800031ae:	b79d                	j	80003114 <balloc+0x84>

00000000800031b0 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800031b0:	7179                	addi	sp,sp,-48
    800031b2:	f406                	sd	ra,40(sp)
    800031b4:	f022                	sd	s0,32(sp)
    800031b6:	ec26                	sd	s1,24(sp)
    800031b8:	e84a                	sd	s2,16(sp)
    800031ba:	e44e                	sd	s3,8(sp)
    800031bc:	1800                	addi	s0,sp,48
    800031be:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800031c0:	47ad                	li	a5,11
    800031c2:	02b7e663          	bltu	a5,a1,800031ee <bmap+0x3e>
    if((addr = ip->addrs[bn]) == 0){
    800031c6:	02059793          	slli	a5,a1,0x20
    800031ca:	01e7d593          	srli	a1,a5,0x1e
    800031ce:	00b504b3          	add	s1,a0,a1
    800031d2:	0504a903          	lw	s2,80(s1)
    800031d6:	06091a63          	bnez	s2,8000324a <bmap+0x9a>
      addr = balloc(ip->dev);
    800031da:	4108                	lw	a0,0(a0)
    800031dc:	eb5ff0ef          	jal	80003090 <balloc>
    800031e0:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800031e4:	06090363          	beqz	s2,8000324a <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    800031e8:	0524a823          	sw	s2,80(s1)
    800031ec:	a8b9                	j	8000324a <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800031ee:	ff45849b          	addiw	s1,a1,-12
    800031f2:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    800031f6:	0ff00793          	li	a5,255
    800031fa:	06e7ee63          	bltu	a5,a4,80003276 <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800031fe:	08052903          	lw	s2,128(a0)
    80003202:	00091d63          	bnez	s2,8000321c <bmap+0x6c>
      addr = balloc(ip->dev);
    80003206:	4108                	lw	a0,0(a0)
    80003208:	e89ff0ef          	jal	80003090 <balloc>
    8000320c:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003210:	02090d63          	beqz	s2,8000324a <bmap+0x9a>
    80003214:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003216:	0929a023          	sw	s2,128(s3)
    8000321a:	a011                	j	8000321e <bmap+0x6e>
    8000321c:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    8000321e:	85ca                	mv	a1,s2
    80003220:	0009a503          	lw	a0,0(s3)
    80003224:	c09ff0ef          	jal	80002e2c <bread>
    80003228:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    8000322a:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    8000322e:	02049713          	slli	a4,s1,0x20
    80003232:	01e75593          	srli	a1,a4,0x1e
    80003236:	00b784b3          	add	s1,a5,a1
    8000323a:	0004a903          	lw	s2,0(s1)
    8000323e:	00090e63          	beqz	s2,8000325a <bmap+0xaa>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003242:	8552                	mv	a0,s4
    80003244:	cf1ff0ef          	jal	80002f34 <brelse>
    return addr;
    80003248:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000324a:	854a                	mv	a0,s2
    8000324c:	70a2                	ld	ra,40(sp)
    8000324e:	7402                	ld	s0,32(sp)
    80003250:	64e2                	ld	s1,24(sp)
    80003252:	6942                	ld	s2,16(sp)
    80003254:	69a2                	ld	s3,8(sp)
    80003256:	6145                	addi	sp,sp,48
    80003258:	8082                	ret
      addr = balloc(ip->dev);
    8000325a:	0009a503          	lw	a0,0(s3)
    8000325e:	e33ff0ef          	jal	80003090 <balloc>
    80003262:	0005091b          	sext.w	s2,a0
      if(addr){
    80003266:	fc090ee3          	beqz	s2,80003242 <bmap+0x92>
        a[bn] = addr;
    8000326a:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    8000326e:	8552                	mv	a0,s4
    80003270:	5f7000ef          	jal	80004066 <log_write>
    80003274:	b7f9                	j	80003242 <bmap+0x92>
    80003276:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003278:	00004517          	auipc	a0,0x4
    8000327c:	2e050513          	addi	a0,a0,736 # 80007558 <etext+0x558>
    80003280:	d60fd0ef          	jal	800007e0 <panic>

0000000080003284 <iget>:
{
    80003284:	7179                	addi	sp,sp,-48
    80003286:	f406                	sd	ra,40(sp)
    80003288:	f022                	sd	s0,32(sp)
    8000328a:	ec26                	sd	s1,24(sp)
    8000328c:	e84a                	sd	s2,16(sp)
    8000328e:	e44e                	sd	s3,8(sp)
    80003290:	e052                	sd	s4,0(sp)
    80003292:	1800                	addi	s0,sp,48
    80003294:	89aa                	mv	s3,a0
    80003296:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003298:	0003d517          	auipc	a0,0x3d
    8000329c:	7f050513          	addi	a0,a0,2032 # 80040a88 <itable>
    800032a0:	b6dfd0ef          	jal	80000e0c <acquire>
  empty = 0;
    800032a4:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800032a6:	0003d497          	auipc	s1,0x3d
    800032aa:	7fa48493          	addi	s1,s1,2042 # 80040aa0 <itable+0x18>
    800032ae:	0003f697          	auipc	a3,0x3f
    800032b2:	28268693          	addi	a3,a3,642 # 80042530 <log>
    800032b6:	a039                	j	800032c4 <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800032b8:	02090963          	beqz	s2,800032ea <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800032bc:	08848493          	addi	s1,s1,136
    800032c0:	02d48863          	beq	s1,a3,800032f0 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800032c4:	449c                	lw	a5,8(s1)
    800032c6:	fef059e3          	blez	a5,800032b8 <iget+0x34>
    800032ca:	4098                	lw	a4,0(s1)
    800032cc:	ff3716e3          	bne	a4,s3,800032b8 <iget+0x34>
    800032d0:	40d8                	lw	a4,4(s1)
    800032d2:	ff4713e3          	bne	a4,s4,800032b8 <iget+0x34>
      ip->ref++;
    800032d6:	2785                	addiw	a5,a5,1
    800032d8:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800032da:	0003d517          	auipc	a0,0x3d
    800032de:	7ae50513          	addi	a0,a0,1966 # 80040a88 <itable>
    800032e2:	bc3fd0ef          	jal	80000ea4 <release>
      return ip;
    800032e6:	8926                	mv	s2,s1
    800032e8:	a02d                	j	80003312 <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800032ea:	fbe9                	bnez	a5,800032bc <iget+0x38>
      empty = ip;
    800032ec:	8926                	mv	s2,s1
    800032ee:	b7f9                	j	800032bc <iget+0x38>
  if(empty == 0)
    800032f0:	02090a63          	beqz	s2,80003324 <iget+0xa0>
  ip->dev = dev;
    800032f4:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800032f8:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800032fc:	4785                	li	a5,1
    800032fe:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003302:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80003306:	0003d517          	auipc	a0,0x3d
    8000330a:	78250513          	addi	a0,a0,1922 # 80040a88 <itable>
    8000330e:	b97fd0ef          	jal	80000ea4 <release>
}
    80003312:	854a                	mv	a0,s2
    80003314:	70a2                	ld	ra,40(sp)
    80003316:	7402                	ld	s0,32(sp)
    80003318:	64e2                	ld	s1,24(sp)
    8000331a:	6942                	ld	s2,16(sp)
    8000331c:	69a2                	ld	s3,8(sp)
    8000331e:	6a02                	ld	s4,0(sp)
    80003320:	6145                	addi	sp,sp,48
    80003322:	8082                	ret
    panic("iget: no inodes");
    80003324:	00004517          	auipc	a0,0x4
    80003328:	24c50513          	addi	a0,a0,588 # 80007570 <etext+0x570>
    8000332c:	cb4fd0ef          	jal	800007e0 <panic>

0000000080003330 <iinit>:
{
    80003330:	7179                	addi	sp,sp,-48
    80003332:	f406                	sd	ra,40(sp)
    80003334:	f022                	sd	s0,32(sp)
    80003336:	ec26                	sd	s1,24(sp)
    80003338:	e84a                	sd	s2,16(sp)
    8000333a:	e44e                	sd	s3,8(sp)
    8000333c:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000333e:	00004597          	auipc	a1,0x4
    80003342:	24258593          	addi	a1,a1,578 # 80007580 <etext+0x580>
    80003346:	0003d517          	auipc	a0,0x3d
    8000334a:	74250513          	addi	a0,a0,1858 # 80040a88 <itable>
    8000334e:	a3ffd0ef          	jal	80000d8c <initlock>
  for(i = 0; i < NINODE; i++) {
    80003352:	0003d497          	auipc	s1,0x3d
    80003356:	75e48493          	addi	s1,s1,1886 # 80040ab0 <itable+0x28>
    8000335a:	0003f997          	auipc	s3,0x3f
    8000335e:	1e698993          	addi	s3,s3,486 # 80042540 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003362:	00004917          	auipc	s2,0x4
    80003366:	22690913          	addi	s2,s2,550 # 80007588 <etext+0x588>
    8000336a:	85ca                	mv	a1,s2
    8000336c:	8526                	mv	a0,s1
    8000336e:	5bb000ef          	jal	80004128 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003372:	08848493          	addi	s1,s1,136
    80003376:	ff349ae3          	bne	s1,s3,8000336a <iinit+0x3a>
}
    8000337a:	70a2                	ld	ra,40(sp)
    8000337c:	7402                	ld	s0,32(sp)
    8000337e:	64e2                	ld	s1,24(sp)
    80003380:	6942                	ld	s2,16(sp)
    80003382:	69a2                	ld	s3,8(sp)
    80003384:	6145                	addi	sp,sp,48
    80003386:	8082                	ret

0000000080003388 <ialloc>:
{
    80003388:	7139                	addi	sp,sp,-64
    8000338a:	fc06                	sd	ra,56(sp)
    8000338c:	f822                	sd	s0,48(sp)
    8000338e:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003390:	0003d717          	auipc	a4,0x3d
    80003394:	6e472703          	lw	a4,1764(a4) # 80040a74 <sb+0xc>
    80003398:	4785                	li	a5,1
    8000339a:	06e7f063          	bgeu	a5,a4,800033fa <ialloc+0x72>
    8000339e:	f426                	sd	s1,40(sp)
    800033a0:	f04a                	sd	s2,32(sp)
    800033a2:	ec4e                	sd	s3,24(sp)
    800033a4:	e852                	sd	s4,16(sp)
    800033a6:	e456                	sd	s5,8(sp)
    800033a8:	e05a                	sd	s6,0(sp)
    800033aa:	8aaa                	mv	s5,a0
    800033ac:	8b2e                	mv	s6,a1
    800033ae:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    800033b0:	0003da17          	auipc	s4,0x3d
    800033b4:	6b8a0a13          	addi	s4,s4,1720 # 80040a68 <sb>
    800033b8:	00495593          	srli	a1,s2,0x4
    800033bc:	018a2783          	lw	a5,24(s4)
    800033c0:	9dbd                	addw	a1,a1,a5
    800033c2:	8556                	mv	a0,s5
    800033c4:	a69ff0ef          	jal	80002e2c <bread>
    800033c8:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800033ca:	05850993          	addi	s3,a0,88
    800033ce:	00f97793          	andi	a5,s2,15
    800033d2:	079a                	slli	a5,a5,0x6
    800033d4:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800033d6:	00099783          	lh	a5,0(s3)
    800033da:	cb9d                	beqz	a5,80003410 <ialloc+0x88>
    brelse(bp);
    800033dc:	b59ff0ef          	jal	80002f34 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800033e0:	0905                	addi	s2,s2,1
    800033e2:	00ca2703          	lw	a4,12(s4)
    800033e6:	0009079b          	sext.w	a5,s2
    800033ea:	fce7e7e3          	bltu	a5,a4,800033b8 <ialloc+0x30>
    800033ee:	74a2                	ld	s1,40(sp)
    800033f0:	7902                	ld	s2,32(sp)
    800033f2:	69e2                	ld	s3,24(sp)
    800033f4:	6a42                	ld	s4,16(sp)
    800033f6:	6aa2                	ld	s5,8(sp)
    800033f8:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800033fa:	00004517          	auipc	a0,0x4
    800033fe:	19650513          	addi	a0,a0,406 # 80007590 <etext+0x590>
    80003402:	8f8fd0ef          	jal	800004fa <printf>
  return 0;
    80003406:	4501                	li	a0,0
}
    80003408:	70e2                	ld	ra,56(sp)
    8000340a:	7442                	ld	s0,48(sp)
    8000340c:	6121                	addi	sp,sp,64
    8000340e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003410:	04000613          	li	a2,64
    80003414:	4581                	li	a1,0
    80003416:	854e                	mv	a0,s3
    80003418:	ac9fd0ef          	jal	80000ee0 <memset>
      dip->type = type;
    8000341c:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003420:	8526                	mv	a0,s1
    80003422:	445000ef          	jal	80004066 <log_write>
      brelse(bp);
    80003426:	8526                	mv	a0,s1
    80003428:	b0dff0ef          	jal	80002f34 <brelse>
      return iget(dev, inum);
    8000342c:	0009059b          	sext.w	a1,s2
    80003430:	8556                	mv	a0,s5
    80003432:	e53ff0ef          	jal	80003284 <iget>
    80003436:	74a2                	ld	s1,40(sp)
    80003438:	7902                	ld	s2,32(sp)
    8000343a:	69e2                	ld	s3,24(sp)
    8000343c:	6a42                	ld	s4,16(sp)
    8000343e:	6aa2                	ld	s5,8(sp)
    80003440:	6b02                	ld	s6,0(sp)
    80003442:	b7d9                	j	80003408 <ialloc+0x80>

0000000080003444 <iupdate>:
{
    80003444:	1101                	addi	sp,sp,-32
    80003446:	ec06                	sd	ra,24(sp)
    80003448:	e822                	sd	s0,16(sp)
    8000344a:	e426                	sd	s1,8(sp)
    8000344c:	e04a                	sd	s2,0(sp)
    8000344e:	1000                	addi	s0,sp,32
    80003450:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003452:	415c                	lw	a5,4(a0)
    80003454:	0047d79b          	srliw	a5,a5,0x4
    80003458:	0003d597          	auipc	a1,0x3d
    8000345c:	6285a583          	lw	a1,1576(a1) # 80040a80 <sb+0x18>
    80003460:	9dbd                	addw	a1,a1,a5
    80003462:	4108                	lw	a0,0(a0)
    80003464:	9c9ff0ef          	jal	80002e2c <bread>
    80003468:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000346a:	05850793          	addi	a5,a0,88
    8000346e:	40d8                	lw	a4,4(s1)
    80003470:	8b3d                	andi	a4,a4,15
    80003472:	071a                	slli	a4,a4,0x6
    80003474:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003476:	04449703          	lh	a4,68(s1)
    8000347a:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000347e:	04649703          	lh	a4,70(s1)
    80003482:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003486:	04849703          	lh	a4,72(s1)
    8000348a:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000348e:	04a49703          	lh	a4,74(s1)
    80003492:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003496:	44f8                	lw	a4,76(s1)
    80003498:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000349a:	03400613          	li	a2,52
    8000349e:	05048593          	addi	a1,s1,80
    800034a2:	00c78513          	addi	a0,a5,12
    800034a6:	a97fd0ef          	jal	80000f3c <memmove>
  log_write(bp);
    800034aa:	854a                	mv	a0,s2
    800034ac:	3bb000ef          	jal	80004066 <log_write>
  brelse(bp);
    800034b0:	854a                	mv	a0,s2
    800034b2:	a83ff0ef          	jal	80002f34 <brelse>
}
    800034b6:	60e2                	ld	ra,24(sp)
    800034b8:	6442                	ld	s0,16(sp)
    800034ba:	64a2                	ld	s1,8(sp)
    800034bc:	6902                	ld	s2,0(sp)
    800034be:	6105                	addi	sp,sp,32
    800034c0:	8082                	ret

00000000800034c2 <idup>:
{
    800034c2:	1101                	addi	sp,sp,-32
    800034c4:	ec06                	sd	ra,24(sp)
    800034c6:	e822                	sd	s0,16(sp)
    800034c8:	e426                	sd	s1,8(sp)
    800034ca:	1000                	addi	s0,sp,32
    800034cc:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800034ce:	0003d517          	auipc	a0,0x3d
    800034d2:	5ba50513          	addi	a0,a0,1466 # 80040a88 <itable>
    800034d6:	937fd0ef          	jal	80000e0c <acquire>
  ip->ref++;
    800034da:	449c                	lw	a5,8(s1)
    800034dc:	2785                	addiw	a5,a5,1
    800034de:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034e0:	0003d517          	auipc	a0,0x3d
    800034e4:	5a850513          	addi	a0,a0,1448 # 80040a88 <itable>
    800034e8:	9bdfd0ef          	jal	80000ea4 <release>
}
    800034ec:	8526                	mv	a0,s1
    800034ee:	60e2                	ld	ra,24(sp)
    800034f0:	6442                	ld	s0,16(sp)
    800034f2:	64a2                	ld	s1,8(sp)
    800034f4:	6105                	addi	sp,sp,32
    800034f6:	8082                	ret

00000000800034f8 <ilock>:
{
    800034f8:	1101                	addi	sp,sp,-32
    800034fa:	ec06                	sd	ra,24(sp)
    800034fc:	e822                	sd	s0,16(sp)
    800034fe:	e426                	sd	s1,8(sp)
    80003500:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003502:	cd19                	beqz	a0,80003520 <ilock+0x28>
    80003504:	84aa                	mv	s1,a0
    80003506:	451c                	lw	a5,8(a0)
    80003508:	00f05c63          	blez	a5,80003520 <ilock+0x28>
  acquiresleep(&ip->lock);
    8000350c:	0541                	addi	a0,a0,16
    8000350e:	451000ef          	jal	8000415e <acquiresleep>
  if(ip->valid == 0){
    80003512:	40bc                	lw	a5,64(s1)
    80003514:	cf89                	beqz	a5,8000352e <ilock+0x36>
}
    80003516:	60e2                	ld	ra,24(sp)
    80003518:	6442                	ld	s0,16(sp)
    8000351a:	64a2                	ld	s1,8(sp)
    8000351c:	6105                	addi	sp,sp,32
    8000351e:	8082                	ret
    80003520:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003522:	00004517          	auipc	a0,0x4
    80003526:	08650513          	addi	a0,a0,134 # 800075a8 <etext+0x5a8>
    8000352a:	ab6fd0ef          	jal	800007e0 <panic>
    8000352e:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003530:	40dc                	lw	a5,4(s1)
    80003532:	0047d79b          	srliw	a5,a5,0x4
    80003536:	0003d597          	auipc	a1,0x3d
    8000353a:	54a5a583          	lw	a1,1354(a1) # 80040a80 <sb+0x18>
    8000353e:	9dbd                	addw	a1,a1,a5
    80003540:	4088                	lw	a0,0(s1)
    80003542:	8ebff0ef          	jal	80002e2c <bread>
    80003546:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003548:	05850593          	addi	a1,a0,88
    8000354c:	40dc                	lw	a5,4(s1)
    8000354e:	8bbd                	andi	a5,a5,15
    80003550:	079a                	slli	a5,a5,0x6
    80003552:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003554:	00059783          	lh	a5,0(a1)
    80003558:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000355c:	00259783          	lh	a5,2(a1)
    80003560:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003564:	00459783          	lh	a5,4(a1)
    80003568:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000356c:	00659783          	lh	a5,6(a1)
    80003570:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003574:	459c                	lw	a5,8(a1)
    80003576:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003578:	03400613          	li	a2,52
    8000357c:	05b1                	addi	a1,a1,12
    8000357e:	05048513          	addi	a0,s1,80
    80003582:	9bbfd0ef          	jal	80000f3c <memmove>
    brelse(bp);
    80003586:	854a                	mv	a0,s2
    80003588:	9adff0ef          	jal	80002f34 <brelse>
    ip->valid = 1;
    8000358c:	4785                	li	a5,1
    8000358e:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003590:	04449783          	lh	a5,68(s1)
    80003594:	c399                	beqz	a5,8000359a <ilock+0xa2>
    80003596:	6902                	ld	s2,0(sp)
    80003598:	bfbd                	j	80003516 <ilock+0x1e>
      panic("ilock: no type");
    8000359a:	00004517          	auipc	a0,0x4
    8000359e:	01650513          	addi	a0,a0,22 # 800075b0 <etext+0x5b0>
    800035a2:	a3efd0ef          	jal	800007e0 <panic>

00000000800035a6 <iunlock>:
{
    800035a6:	1101                	addi	sp,sp,-32
    800035a8:	ec06                	sd	ra,24(sp)
    800035aa:	e822                	sd	s0,16(sp)
    800035ac:	e426                	sd	s1,8(sp)
    800035ae:	e04a                	sd	s2,0(sp)
    800035b0:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800035b2:	c505                	beqz	a0,800035da <iunlock+0x34>
    800035b4:	84aa                	mv	s1,a0
    800035b6:	01050913          	addi	s2,a0,16
    800035ba:	854a                	mv	a0,s2
    800035bc:	421000ef          	jal	800041dc <holdingsleep>
    800035c0:	cd09                	beqz	a0,800035da <iunlock+0x34>
    800035c2:	449c                	lw	a5,8(s1)
    800035c4:	00f05b63          	blez	a5,800035da <iunlock+0x34>
  releasesleep(&ip->lock);
    800035c8:	854a                	mv	a0,s2
    800035ca:	3db000ef          	jal	800041a4 <releasesleep>
}
    800035ce:	60e2                	ld	ra,24(sp)
    800035d0:	6442                	ld	s0,16(sp)
    800035d2:	64a2                	ld	s1,8(sp)
    800035d4:	6902                	ld	s2,0(sp)
    800035d6:	6105                	addi	sp,sp,32
    800035d8:	8082                	ret
    panic("iunlock");
    800035da:	00004517          	auipc	a0,0x4
    800035de:	fe650513          	addi	a0,a0,-26 # 800075c0 <etext+0x5c0>
    800035e2:	9fefd0ef          	jal	800007e0 <panic>

00000000800035e6 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800035e6:	7179                	addi	sp,sp,-48
    800035e8:	f406                	sd	ra,40(sp)
    800035ea:	f022                	sd	s0,32(sp)
    800035ec:	ec26                	sd	s1,24(sp)
    800035ee:	e84a                	sd	s2,16(sp)
    800035f0:	e44e                	sd	s3,8(sp)
    800035f2:	1800                	addi	s0,sp,48
    800035f4:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800035f6:	05050493          	addi	s1,a0,80
    800035fa:	08050913          	addi	s2,a0,128
    800035fe:	a021                	j	80003606 <itrunc+0x20>
    80003600:	0491                	addi	s1,s1,4
    80003602:	01248b63          	beq	s1,s2,80003618 <itrunc+0x32>
    if(ip->addrs[i]){
    80003606:	408c                	lw	a1,0(s1)
    80003608:	dde5                	beqz	a1,80003600 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000360a:	0009a503          	lw	a0,0(s3)
    8000360e:	a17ff0ef          	jal	80003024 <bfree>
      ip->addrs[i] = 0;
    80003612:	0004a023          	sw	zero,0(s1)
    80003616:	b7ed                	j	80003600 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003618:	0809a583          	lw	a1,128(s3)
    8000361c:	ed89                	bnez	a1,80003636 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000361e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003622:	854e                	mv	a0,s3
    80003624:	e21ff0ef          	jal	80003444 <iupdate>
}
    80003628:	70a2                	ld	ra,40(sp)
    8000362a:	7402                	ld	s0,32(sp)
    8000362c:	64e2                	ld	s1,24(sp)
    8000362e:	6942                	ld	s2,16(sp)
    80003630:	69a2                	ld	s3,8(sp)
    80003632:	6145                	addi	sp,sp,48
    80003634:	8082                	ret
    80003636:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003638:	0009a503          	lw	a0,0(s3)
    8000363c:	ff0ff0ef          	jal	80002e2c <bread>
    80003640:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003642:	05850493          	addi	s1,a0,88
    80003646:	45850913          	addi	s2,a0,1112
    8000364a:	a021                	j	80003652 <itrunc+0x6c>
    8000364c:	0491                	addi	s1,s1,4
    8000364e:	01248963          	beq	s1,s2,80003660 <itrunc+0x7a>
      if(a[j])
    80003652:	408c                	lw	a1,0(s1)
    80003654:	dde5                	beqz	a1,8000364c <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003656:	0009a503          	lw	a0,0(s3)
    8000365a:	9cbff0ef          	jal	80003024 <bfree>
    8000365e:	b7fd                	j	8000364c <itrunc+0x66>
    brelse(bp);
    80003660:	8552                	mv	a0,s4
    80003662:	8d3ff0ef          	jal	80002f34 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003666:	0809a583          	lw	a1,128(s3)
    8000366a:	0009a503          	lw	a0,0(s3)
    8000366e:	9b7ff0ef          	jal	80003024 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003672:	0809a023          	sw	zero,128(s3)
    80003676:	6a02                	ld	s4,0(sp)
    80003678:	b75d                	j	8000361e <itrunc+0x38>

000000008000367a <iput>:
{
    8000367a:	1101                	addi	sp,sp,-32
    8000367c:	ec06                	sd	ra,24(sp)
    8000367e:	e822                	sd	s0,16(sp)
    80003680:	e426                	sd	s1,8(sp)
    80003682:	1000                	addi	s0,sp,32
    80003684:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003686:	0003d517          	auipc	a0,0x3d
    8000368a:	40250513          	addi	a0,a0,1026 # 80040a88 <itable>
    8000368e:	f7efd0ef          	jal	80000e0c <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003692:	4498                	lw	a4,8(s1)
    80003694:	4785                	li	a5,1
    80003696:	02f70063          	beq	a4,a5,800036b6 <iput+0x3c>
  ip->ref--;
    8000369a:	449c                	lw	a5,8(s1)
    8000369c:	37fd                	addiw	a5,a5,-1
    8000369e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800036a0:	0003d517          	auipc	a0,0x3d
    800036a4:	3e850513          	addi	a0,a0,1000 # 80040a88 <itable>
    800036a8:	ffcfd0ef          	jal	80000ea4 <release>
}
    800036ac:	60e2                	ld	ra,24(sp)
    800036ae:	6442                	ld	s0,16(sp)
    800036b0:	64a2                	ld	s1,8(sp)
    800036b2:	6105                	addi	sp,sp,32
    800036b4:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800036b6:	40bc                	lw	a5,64(s1)
    800036b8:	d3ed                	beqz	a5,8000369a <iput+0x20>
    800036ba:	04a49783          	lh	a5,74(s1)
    800036be:	fff1                	bnez	a5,8000369a <iput+0x20>
    800036c0:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    800036c2:	01048913          	addi	s2,s1,16
    800036c6:	854a                	mv	a0,s2
    800036c8:	297000ef          	jal	8000415e <acquiresleep>
    release(&itable.lock);
    800036cc:	0003d517          	auipc	a0,0x3d
    800036d0:	3bc50513          	addi	a0,a0,956 # 80040a88 <itable>
    800036d4:	fd0fd0ef          	jal	80000ea4 <release>
    itrunc(ip);
    800036d8:	8526                	mv	a0,s1
    800036da:	f0dff0ef          	jal	800035e6 <itrunc>
    ip->type = 0;
    800036de:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800036e2:	8526                	mv	a0,s1
    800036e4:	d61ff0ef          	jal	80003444 <iupdate>
    ip->valid = 0;
    800036e8:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800036ec:	854a                	mv	a0,s2
    800036ee:	2b7000ef          	jal	800041a4 <releasesleep>
    acquire(&itable.lock);
    800036f2:	0003d517          	auipc	a0,0x3d
    800036f6:	39650513          	addi	a0,a0,918 # 80040a88 <itable>
    800036fa:	f12fd0ef          	jal	80000e0c <acquire>
    800036fe:	6902                	ld	s2,0(sp)
    80003700:	bf69                	j	8000369a <iput+0x20>

0000000080003702 <iunlockput>:
{
    80003702:	1101                	addi	sp,sp,-32
    80003704:	ec06                	sd	ra,24(sp)
    80003706:	e822                	sd	s0,16(sp)
    80003708:	e426                	sd	s1,8(sp)
    8000370a:	1000                	addi	s0,sp,32
    8000370c:	84aa                	mv	s1,a0
  iunlock(ip);
    8000370e:	e99ff0ef          	jal	800035a6 <iunlock>
  iput(ip);
    80003712:	8526                	mv	a0,s1
    80003714:	f67ff0ef          	jal	8000367a <iput>
}
    80003718:	60e2                	ld	ra,24(sp)
    8000371a:	6442                	ld	s0,16(sp)
    8000371c:	64a2                	ld	s1,8(sp)
    8000371e:	6105                	addi	sp,sp,32
    80003720:	8082                	ret

0000000080003722 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003722:	0003d717          	auipc	a4,0x3d
    80003726:	35272703          	lw	a4,850(a4) # 80040a74 <sb+0xc>
    8000372a:	4785                	li	a5,1
    8000372c:	0ae7ff63          	bgeu	a5,a4,800037ea <ireclaim+0xc8>
{
    80003730:	7139                	addi	sp,sp,-64
    80003732:	fc06                	sd	ra,56(sp)
    80003734:	f822                	sd	s0,48(sp)
    80003736:	f426                	sd	s1,40(sp)
    80003738:	f04a                	sd	s2,32(sp)
    8000373a:	ec4e                	sd	s3,24(sp)
    8000373c:	e852                	sd	s4,16(sp)
    8000373e:	e456                	sd	s5,8(sp)
    80003740:	e05a                	sd	s6,0(sp)
    80003742:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003744:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003746:	00050a1b          	sext.w	s4,a0
    8000374a:	0003da97          	auipc	s5,0x3d
    8000374e:	31ea8a93          	addi	s5,s5,798 # 80040a68 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    80003752:	00004b17          	auipc	s6,0x4
    80003756:	e76b0b13          	addi	s6,s6,-394 # 800075c8 <etext+0x5c8>
    8000375a:	a099                	j	800037a0 <ireclaim+0x7e>
    8000375c:	85ce                	mv	a1,s3
    8000375e:	855a                	mv	a0,s6
    80003760:	d9bfc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    80003764:	85ce                	mv	a1,s3
    80003766:	8552                	mv	a0,s4
    80003768:	b1dff0ef          	jal	80003284 <iget>
    8000376c:	89aa                	mv	s3,a0
    brelse(bp);
    8000376e:	854a                	mv	a0,s2
    80003770:	fc4ff0ef          	jal	80002f34 <brelse>
    if (ip) {
    80003774:	00098f63          	beqz	s3,80003792 <ireclaim+0x70>
      begin_op();
    80003778:	76a000ef          	jal	80003ee2 <begin_op>
      ilock(ip);
    8000377c:	854e                	mv	a0,s3
    8000377e:	d7bff0ef          	jal	800034f8 <ilock>
      iunlock(ip);
    80003782:	854e                	mv	a0,s3
    80003784:	e23ff0ef          	jal	800035a6 <iunlock>
      iput(ip);
    80003788:	854e                	mv	a0,s3
    8000378a:	ef1ff0ef          	jal	8000367a <iput>
      end_op();
    8000378e:	7be000ef          	jal	80003f4c <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003792:	0485                	addi	s1,s1,1
    80003794:	00caa703          	lw	a4,12(s5)
    80003798:	0004879b          	sext.w	a5,s1
    8000379c:	02e7fd63          	bgeu	a5,a4,800037d6 <ireclaim+0xb4>
    800037a0:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800037a4:	0044d593          	srli	a1,s1,0x4
    800037a8:	018aa783          	lw	a5,24(s5)
    800037ac:	9dbd                	addw	a1,a1,a5
    800037ae:	8552                	mv	a0,s4
    800037b0:	e7cff0ef          	jal	80002e2c <bread>
    800037b4:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800037b6:	05850793          	addi	a5,a0,88
    800037ba:	00f9f713          	andi	a4,s3,15
    800037be:	071a                	slli	a4,a4,0x6
    800037c0:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    800037c2:	00079703          	lh	a4,0(a5)
    800037c6:	c701                	beqz	a4,800037ce <ireclaim+0xac>
    800037c8:	00679783          	lh	a5,6(a5)
    800037cc:	dbc1                	beqz	a5,8000375c <ireclaim+0x3a>
    brelse(bp);
    800037ce:	854a                	mv	a0,s2
    800037d0:	f64ff0ef          	jal	80002f34 <brelse>
    if (ip) {
    800037d4:	bf7d                	j	80003792 <ireclaim+0x70>
}
    800037d6:	70e2                	ld	ra,56(sp)
    800037d8:	7442                	ld	s0,48(sp)
    800037da:	74a2                	ld	s1,40(sp)
    800037dc:	7902                	ld	s2,32(sp)
    800037de:	69e2                	ld	s3,24(sp)
    800037e0:	6a42                	ld	s4,16(sp)
    800037e2:	6aa2                	ld	s5,8(sp)
    800037e4:	6b02                	ld	s6,0(sp)
    800037e6:	6121                	addi	sp,sp,64
    800037e8:	8082                	ret
    800037ea:	8082                	ret

00000000800037ec <fsinit>:
fsinit(int dev) {
    800037ec:	7179                	addi	sp,sp,-48
    800037ee:	f406                	sd	ra,40(sp)
    800037f0:	f022                	sd	s0,32(sp)
    800037f2:	ec26                	sd	s1,24(sp)
    800037f4:	e84a                	sd	s2,16(sp)
    800037f6:	e44e                	sd	s3,8(sp)
    800037f8:	1800                	addi	s0,sp,48
    800037fa:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    800037fc:	4585                	li	a1,1
    800037fe:	e2eff0ef          	jal	80002e2c <bread>
    80003802:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003804:	0003d997          	auipc	s3,0x3d
    80003808:	26498993          	addi	s3,s3,612 # 80040a68 <sb>
    8000380c:	02000613          	li	a2,32
    80003810:	05850593          	addi	a1,a0,88
    80003814:	854e                	mv	a0,s3
    80003816:	f26fd0ef          	jal	80000f3c <memmove>
  brelse(bp);
    8000381a:	854a                	mv	a0,s2
    8000381c:	f18ff0ef          	jal	80002f34 <brelse>
  if(sb.magic != FSMAGIC)
    80003820:	0009a703          	lw	a4,0(s3)
    80003824:	102037b7          	lui	a5,0x10203
    80003828:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000382c:	02f71363          	bne	a4,a5,80003852 <fsinit+0x66>
  initlog(dev, &sb);
    80003830:	0003d597          	auipc	a1,0x3d
    80003834:	23858593          	addi	a1,a1,568 # 80040a68 <sb>
    80003838:	8526                	mv	a0,s1
    8000383a:	62a000ef          	jal	80003e64 <initlog>
  ireclaim(dev);
    8000383e:	8526                	mv	a0,s1
    80003840:	ee3ff0ef          	jal	80003722 <ireclaim>
}
    80003844:	70a2                	ld	ra,40(sp)
    80003846:	7402                	ld	s0,32(sp)
    80003848:	64e2                	ld	s1,24(sp)
    8000384a:	6942                	ld	s2,16(sp)
    8000384c:	69a2                	ld	s3,8(sp)
    8000384e:	6145                	addi	sp,sp,48
    80003850:	8082                	ret
    panic("invalid file system");
    80003852:	00004517          	auipc	a0,0x4
    80003856:	d9650513          	addi	a0,a0,-618 # 800075e8 <etext+0x5e8>
    8000385a:	f87fc0ef          	jal	800007e0 <panic>

000000008000385e <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000385e:	1141                	addi	sp,sp,-16
    80003860:	e422                	sd	s0,8(sp)
    80003862:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003864:	411c                	lw	a5,0(a0)
    80003866:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003868:	415c                	lw	a5,4(a0)
    8000386a:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000386c:	04451783          	lh	a5,68(a0)
    80003870:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003874:	04a51783          	lh	a5,74(a0)
    80003878:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000387c:	04c56783          	lwu	a5,76(a0)
    80003880:	e99c                	sd	a5,16(a1)
}
    80003882:	6422                	ld	s0,8(sp)
    80003884:	0141                	addi	sp,sp,16
    80003886:	8082                	ret

0000000080003888 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003888:	457c                	lw	a5,76(a0)
    8000388a:	0ed7eb63          	bltu	a5,a3,80003980 <readi+0xf8>
{
    8000388e:	7159                	addi	sp,sp,-112
    80003890:	f486                	sd	ra,104(sp)
    80003892:	f0a2                	sd	s0,96(sp)
    80003894:	eca6                	sd	s1,88(sp)
    80003896:	e0d2                	sd	s4,64(sp)
    80003898:	fc56                	sd	s5,56(sp)
    8000389a:	f85a                	sd	s6,48(sp)
    8000389c:	f45e                	sd	s7,40(sp)
    8000389e:	1880                	addi	s0,sp,112
    800038a0:	8b2a                	mv	s6,a0
    800038a2:	8bae                	mv	s7,a1
    800038a4:	8a32                	mv	s4,a2
    800038a6:	84b6                	mv	s1,a3
    800038a8:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800038aa:	9f35                	addw	a4,a4,a3
    return 0;
    800038ac:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800038ae:	0cd76063          	bltu	a4,a3,8000396e <readi+0xe6>
    800038b2:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    800038b4:	00e7f463          	bgeu	a5,a4,800038bc <readi+0x34>
    n = ip->size - off;
    800038b8:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800038bc:	080a8f63          	beqz	s5,8000395a <readi+0xd2>
    800038c0:	e8ca                	sd	s2,80(sp)
    800038c2:	f062                	sd	s8,32(sp)
    800038c4:	ec66                	sd	s9,24(sp)
    800038c6:	e86a                	sd	s10,16(sp)
    800038c8:	e46e                	sd	s11,8(sp)
    800038ca:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800038cc:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800038d0:	5c7d                	li	s8,-1
    800038d2:	a80d                	j	80003904 <readi+0x7c>
    800038d4:	020d1d93          	slli	s11,s10,0x20
    800038d8:	020ddd93          	srli	s11,s11,0x20
    800038dc:	05890613          	addi	a2,s2,88
    800038e0:	86ee                	mv	a3,s11
    800038e2:	963a                	add	a2,a2,a4
    800038e4:	85d2                	mv	a1,s4
    800038e6:	855e                	mv	a0,s7
    800038e8:	c35fe0ef          	jal	8000251c <either_copyout>
    800038ec:	05850763          	beq	a0,s8,8000393a <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800038f0:	854a                	mv	a0,s2
    800038f2:	e42ff0ef          	jal	80002f34 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800038f6:	013d09bb          	addw	s3,s10,s3
    800038fa:	009d04bb          	addw	s1,s10,s1
    800038fe:	9a6e                	add	s4,s4,s11
    80003900:	0559f763          	bgeu	s3,s5,8000394e <readi+0xc6>
    uint addr = bmap(ip, off/BSIZE);
    80003904:	00a4d59b          	srliw	a1,s1,0xa
    80003908:	855a                	mv	a0,s6
    8000390a:	8a7ff0ef          	jal	800031b0 <bmap>
    8000390e:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003912:	c5b1                	beqz	a1,8000395e <readi+0xd6>
    bp = bread(ip->dev, addr);
    80003914:	000b2503          	lw	a0,0(s6)
    80003918:	d14ff0ef          	jal	80002e2c <bread>
    8000391c:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000391e:	3ff4f713          	andi	a4,s1,1023
    80003922:	40ec87bb          	subw	a5,s9,a4
    80003926:	413a86bb          	subw	a3,s5,s3
    8000392a:	8d3e                	mv	s10,a5
    8000392c:	2781                	sext.w	a5,a5
    8000392e:	0006861b          	sext.w	a2,a3
    80003932:	faf671e3          	bgeu	a2,a5,800038d4 <readi+0x4c>
    80003936:	8d36                	mv	s10,a3
    80003938:	bf71                	j	800038d4 <readi+0x4c>
      brelse(bp);
    8000393a:	854a                	mv	a0,s2
    8000393c:	df8ff0ef          	jal	80002f34 <brelse>
      tot = -1;
    80003940:	59fd                	li	s3,-1
      break;
    80003942:	6946                	ld	s2,80(sp)
    80003944:	7c02                	ld	s8,32(sp)
    80003946:	6ce2                	ld	s9,24(sp)
    80003948:	6d42                	ld	s10,16(sp)
    8000394a:	6da2                	ld	s11,8(sp)
    8000394c:	a831                	j	80003968 <readi+0xe0>
    8000394e:	6946                	ld	s2,80(sp)
    80003950:	7c02                	ld	s8,32(sp)
    80003952:	6ce2                	ld	s9,24(sp)
    80003954:	6d42                	ld	s10,16(sp)
    80003956:	6da2                	ld	s11,8(sp)
    80003958:	a801                	j	80003968 <readi+0xe0>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000395a:	89d6                	mv	s3,s5
    8000395c:	a031                	j	80003968 <readi+0xe0>
    8000395e:	6946                	ld	s2,80(sp)
    80003960:	7c02                	ld	s8,32(sp)
    80003962:	6ce2                	ld	s9,24(sp)
    80003964:	6d42                	ld	s10,16(sp)
    80003966:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003968:	0009851b          	sext.w	a0,s3
    8000396c:	69a6                	ld	s3,72(sp)
}
    8000396e:	70a6                	ld	ra,104(sp)
    80003970:	7406                	ld	s0,96(sp)
    80003972:	64e6                	ld	s1,88(sp)
    80003974:	6a06                	ld	s4,64(sp)
    80003976:	7ae2                	ld	s5,56(sp)
    80003978:	7b42                	ld	s6,48(sp)
    8000397a:	7ba2                	ld	s7,40(sp)
    8000397c:	6165                	addi	sp,sp,112
    8000397e:	8082                	ret
    return 0;
    80003980:	4501                	li	a0,0
}
    80003982:	8082                	ret

0000000080003984 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003984:	457c                	lw	a5,76(a0)
    80003986:	10d7e063          	bltu	a5,a3,80003a86 <writei+0x102>
{
    8000398a:	7159                	addi	sp,sp,-112
    8000398c:	f486                	sd	ra,104(sp)
    8000398e:	f0a2                	sd	s0,96(sp)
    80003990:	e8ca                	sd	s2,80(sp)
    80003992:	e0d2                	sd	s4,64(sp)
    80003994:	fc56                	sd	s5,56(sp)
    80003996:	f85a                	sd	s6,48(sp)
    80003998:	f45e                	sd	s7,40(sp)
    8000399a:	1880                	addi	s0,sp,112
    8000399c:	8aaa                	mv	s5,a0
    8000399e:	8bae                	mv	s7,a1
    800039a0:	8a32                	mv	s4,a2
    800039a2:	8936                	mv	s2,a3
    800039a4:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800039a6:	00e687bb          	addw	a5,a3,a4
    800039aa:	0ed7e063          	bltu	a5,a3,80003a8a <writei+0x106>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800039ae:	00043737          	lui	a4,0x43
    800039b2:	0cf76e63          	bltu	a4,a5,80003a8e <writei+0x10a>
    800039b6:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800039b8:	0a0b0f63          	beqz	s6,80003a76 <writei+0xf2>
    800039bc:	eca6                	sd	s1,88(sp)
    800039be:	f062                	sd	s8,32(sp)
    800039c0:	ec66                	sd	s9,24(sp)
    800039c2:	e86a                	sd	s10,16(sp)
    800039c4:	e46e                	sd	s11,8(sp)
    800039c6:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800039c8:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800039cc:	5c7d                	li	s8,-1
    800039ce:	a825                	j	80003a06 <writei+0x82>
    800039d0:	020d1d93          	slli	s11,s10,0x20
    800039d4:	020ddd93          	srli	s11,s11,0x20
    800039d8:	05848513          	addi	a0,s1,88
    800039dc:	86ee                	mv	a3,s11
    800039de:	8652                	mv	a2,s4
    800039e0:	85de                	mv	a1,s7
    800039e2:	953a                	add	a0,a0,a4
    800039e4:	b83fe0ef          	jal	80002566 <either_copyin>
    800039e8:	05850a63          	beq	a0,s8,80003a3c <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    800039ec:	8526                	mv	a0,s1
    800039ee:	678000ef          	jal	80004066 <log_write>
    brelse(bp);
    800039f2:	8526                	mv	a0,s1
    800039f4:	d40ff0ef          	jal	80002f34 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800039f8:	013d09bb          	addw	s3,s10,s3
    800039fc:	012d093b          	addw	s2,s10,s2
    80003a00:	9a6e                	add	s4,s4,s11
    80003a02:	0569f063          	bgeu	s3,s6,80003a42 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003a06:	00a9559b          	srliw	a1,s2,0xa
    80003a0a:	8556                	mv	a0,s5
    80003a0c:	fa4ff0ef          	jal	800031b0 <bmap>
    80003a10:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003a14:	c59d                	beqz	a1,80003a42 <writei+0xbe>
    bp = bread(ip->dev, addr);
    80003a16:	000aa503          	lw	a0,0(s5)
    80003a1a:	c12ff0ef          	jal	80002e2c <bread>
    80003a1e:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003a20:	3ff97713          	andi	a4,s2,1023
    80003a24:	40ec87bb          	subw	a5,s9,a4
    80003a28:	413b06bb          	subw	a3,s6,s3
    80003a2c:	8d3e                	mv	s10,a5
    80003a2e:	2781                	sext.w	a5,a5
    80003a30:	0006861b          	sext.w	a2,a3
    80003a34:	f8f67ee3          	bgeu	a2,a5,800039d0 <writei+0x4c>
    80003a38:	8d36                	mv	s10,a3
    80003a3a:	bf59                	j	800039d0 <writei+0x4c>
      brelse(bp);
    80003a3c:	8526                	mv	a0,s1
    80003a3e:	cf6ff0ef          	jal	80002f34 <brelse>
  }

  if(off > ip->size)
    80003a42:	04caa783          	lw	a5,76(s5)
    80003a46:	0327fa63          	bgeu	a5,s2,80003a7a <writei+0xf6>
    ip->size = off;
    80003a4a:	052aa623          	sw	s2,76(s5)
    80003a4e:	64e6                	ld	s1,88(sp)
    80003a50:	7c02                	ld	s8,32(sp)
    80003a52:	6ce2                	ld	s9,24(sp)
    80003a54:	6d42                	ld	s10,16(sp)
    80003a56:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003a58:	8556                	mv	a0,s5
    80003a5a:	9ebff0ef          	jal	80003444 <iupdate>

  return tot;
    80003a5e:	0009851b          	sext.w	a0,s3
    80003a62:	69a6                	ld	s3,72(sp)
}
    80003a64:	70a6                	ld	ra,104(sp)
    80003a66:	7406                	ld	s0,96(sp)
    80003a68:	6946                	ld	s2,80(sp)
    80003a6a:	6a06                	ld	s4,64(sp)
    80003a6c:	7ae2                	ld	s5,56(sp)
    80003a6e:	7b42                	ld	s6,48(sp)
    80003a70:	7ba2                	ld	s7,40(sp)
    80003a72:	6165                	addi	sp,sp,112
    80003a74:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003a76:	89da                	mv	s3,s6
    80003a78:	b7c5                	j	80003a58 <writei+0xd4>
    80003a7a:	64e6                	ld	s1,88(sp)
    80003a7c:	7c02                	ld	s8,32(sp)
    80003a7e:	6ce2                	ld	s9,24(sp)
    80003a80:	6d42                	ld	s10,16(sp)
    80003a82:	6da2                	ld	s11,8(sp)
    80003a84:	bfd1                	j	80003a58 <writei+0xd4>
    return -1;
    80003a86:	557d                	li	a0,-1
}
    80003a88:	8082                	ret
    return -1;
    80003a8a:	557d                	li	a0,-1
    80003a8c:	bfe1                	j	80003a64 <writei+0xe0>
    return -1;
    80003a8e:	557d                	li	a0,-1
    80003a90:	bfd1                	j	80003a64 <writei+0xe0>

0000000080003a92 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003a92:	1141                	addi	sp,sp,-16
    80003a94:	e406                	sd	ra,8(sp)
    80003a96:	e022                	sd	s0,0(sp)
    80003a98:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003a9a:	4639                	li	a2,14
    80003a9c:	d10fd0ef          	jal	80000fac <strncmp>
}
    80003aa0:	60a2                	ld	ra,8(sp)
    80003aa2:	6402                	ld	s0,0(sp)
    80003aa4:	0141                	addi	sp,sp,16
    80003aa6:	8082                	ret

0000000080003aa8 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003aa8:	7139                	addi	sp,sp,-64
    80003aaa:	fc06                	sd	ra,56(sp)
    80003aac:	f822                	sd	s0,48(sp)
    80003aae:	f426                	sd	s1,40(sp)
    80003ab0:	f04a                	sd	s2,32(sp)
    80003ab2:	ec4e                	sd	s3,24(sp)
    80003ab4:	e852                	sd	s4,16(sp)
    80003ab6:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003ab8:	04451703          	lh	a4,68(a0)
    80003abc:	4785                	li	a5,1
    80003abe:	00f71a63          	bne	a4,a5,80003ad2 <dirlookup+0x2a>
    80003ac2:	892a                	mv	s2,a0
    80003ac4:	89ae                	mv	s3,a1
    80003ac6:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ac8:	457c                	lw	a5,76(a0)
    80003aca:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003acc:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ace:	e39d                	bnez	a5,80003af4 <dirlookup+0x4c>
    80003ad0:	a095                	j	80003b34 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003ad2:	00004517          	auipc	a0,0x4
    80003ad6:	b2e50513          	addi	a0,a0,-1234 # 80007600 <etext+0x600>
    80003ada:	d07fc0ef          	jal	800007e0 <panic>
      panic("dirlookup read");
    80003ade:	00004517          	auipc	a0,0x4
    80003ae2:	b3a50513          	addi	a0,a0,-1222 # 80007618 <etext+0x618>
    80003ae6:	cfbfc0ef          	jal	800007e0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003aea:	24c1                	addiw	s1,s1,16
    80003aec:	04c92783          	lw	a5,76(s2)
    80003af0:	04f4f163          	bgeu	s1,a5,80003b32 <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003af4:	4741                	li	a4,16
    80003af6:	86a6                	mv	a3,s1
    80003af8:	fc040613          	addi	a2,s0,-64
    80003afc:	4581                	li	a1,0
    80003afe:	854a                	mv	a0,s2
    80003b00:	d89ff0ef          	jal	80003888 <readi>
    80003b04:	47c1                	li	a5,16
    80003b06:	fcf51ce3          	bne	a0,a5,80003ade <dirlookup+0x36>
    if(de.inum == 0)
    80003b0a:	fc045783          	lhu	a5,-64(s0)
    80003b0e:	dff1                	beqz	a5,80003aea <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80003b10:	fc240593          	addi	a1,s0,-62
    80003b14:	854e                	mv	a0,s3
    80003b16:	f7dff0ef          	jal	80003a92 <namecmp>
    80003b1a:	f961                	bnez	a0,80003aea <dirlookup+0x42>
      if(poff)
    80003b1c:	000a0463          	beqz	s4,80003b24 <dirlookup+0x7c>
        *poff = off;
    80003b20:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003b24:	fc045583          	lhu	a1,-64(s0)
    80003b28:	00092503          	lw	a0,0(s2)
    80003b2c:	f58ff0ef          	jal	80003284 <iget>
    80003b30:	a011                	j	80003b34 <dirlookup+0x8c>
  return 0;
    80003b32:	4501                	li	a0,0
}
    80003b34:	70e2                	ld	ra,56(sp)
    80003b36:	7442                	ld	s0,48(sp)
    80003b38:	74a2                	ld	s1,40(sp)
    80003b3a:	7902                	ld	s2,32(sp)
    80003b3c:	69e2                	ld	s3,24(sp)
    80003b3e:	6a42                	ld	s4,16(sp)
    80003b40:	6121                	addi	sp,sp,64
    80003b42:	8082                	ret

0000000080003b44 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003b44:	711d                	addi	sp,sp,-96
    80003b46:	ec86                	sd	ra,88(sp)
    80003b48:	e8a2                	sd	s0,80(sp)
    80003b4a:	e4a6                	sd	s1,72(sp)
    80003b4c:	e0ca                	sd	s2,64(sp)
    80003b4e:	fc4e                	sd	s3,56(sp)
    80003b50:	f852                	sd	s4,48(sp)
    80003b52:	f456                	sd	s5,40(sp)
    80003b54:	f05a                	sd	s6,32(sp)
    80003b56:	ec5e                	sd	s7,24(sp)
    80003b58:	e862                	sd	s8,16(sp)
    80003b5a:	e466                	sd	s9,8(sp)
    80003b5c:	1080                	addi	s0,sp,96
    80003b5e:	84aa                	mv	s1,a0
    80003b60:	8b2e                	mv	s6,a1
    80003b62:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003b64:	00054703          	lbu	a4,0(a0)
    80003b68:	02f00793          	li	a5,47
    80003b6c:	00f70e63          	beq	a4,a5,80003b88 <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003b70:	858fe0ef          	jal	80001bc8 <myproc>
    80003b74:	15053503          	ld	a0,336(a0)
    80003b78:	94bff0ef          	jal	800034c2 <idup>
    80003b7c:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003b7e:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003b82:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003b84:	4b85                	li	s7,1
    80003b86:	a871                	j	80003c22 <namex+0xde>
    ip = iget(ROOTDEV, ROOTINO);
    80003b88:	4585                	li	a1,1
    80003b8a:	4505                	li	a0,1
    80003b8c:	ef8ff0ef          	jal	80003284 <iget>
    80003b90:	8a2a                	mv	s4,a0
    80003b92:	b7f5                	j	80003b7e <namex+0x3a>
      iunlockput(ip);
    80003b94:	8552                	mv	a0,s4
    80003b96:	b6dff0ef          	jal	80003702 <iunlockput>
      return 0;
    80003b9a:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003b9c:	8552                	mv	a0,s4
    80003b9e:	60e6                	ld	ra,88(sp)
    80003ba0:	6446                	ld	s0,80(sp)
    80003ba2:	64a6                	ld	s1,72(sp)
    80003ba4:	6906                	ld	s2,64(sp)
    80003ba6:	79e2                	ld	s3,56(sp)
    80003ba8:	7a42                	ld	s4,48(sp)
    80003baa:	7aa2                	ld	s5,40(sp)
    80003bac:	7b02                	ld	s6,32(sp)
    80003bae:	6be2                	ld	s7,24(sp)
    80003bb0:	6c42                	ld	s8,16(sp)
    80003bb2:	6ca2                	ld	s9,8(sp)
    80003bb4:	6125                	addi	sp,sp,96
    80003bb6:	8082                	ret
      iunlock(ip);
    80003bb8:	8552                	mv	a0,s4
    80003bba:	9edff0ef          	jal	800035a6 <iunlock>
      return ip;
    80003bbe:	bff9                	j	80003b9c <namex+0x58>
      iunlockput(ip);
    80003bc0:	8552                	mv	a0,s4
    80003bc2:	b41ff0ef          	jal	80003702 <iunlockput>
      return 0;
    80003bc6:	8a4e                	mv	s4,s3
    80003bc8:	bfd1                	j	80003b9c <namex+0x58>
  len = path - s;
    80003bca:	40998633          	sub	a2,s3,s1
    80003bce:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003bd2:	099c5063          	bge	s8,s9,80003c52 <namex+0x10e>
    memmove(name, s, DIRSIZ);
    80003bd6:	4639                	li	a2,14
    80003bd8:	85a6                	mv	a1,s1
    80003bda:	8556                	mv	a0,s5
    80003bdc:	b60fd0ef          	jal	80000f3c <memmove>
    80003be0:	84ce                	mv	s1,s3
  while(*path == '/')
    80003be2:	0004c783          	lbu	a5,0(s1)
    80003be6:	01279763          	bne	a5,s2,80003bf4 <namex+0xb0>
    path++;
    80003bea:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003bec:	0004c783          	lbu	a5,0(s1)
    80003bf0:	ff278de3          	beq	a5,s2,80003bea <namex+0xa6>
    ilock(ip);
    80003bf4:	8552                	mv	a0,s4
    80003bf6:	903ff0ef          	jal	800034f8 <ilock>
    if(ip->type != T_DIR){
    80003bfa:	044a1783          	lh	a5,68(s4)
    80003bfe:	f9779be3          	bne	a5,s7,80003b94 <namex+0x50>
    if(nameiparent && *path == '\0'){
    80003c02:	000b0563          	beqz	s6,80003c0c <namex+0xc8>
    80003c06:	0004c783          	lbu	a5,0(s1)
    80003c0a:	d7dd                	beqz	a5,80003bb8 <namex+0x74>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003c0c:	4601                	li	a2,0
    80003c0e:	85d6                	mv	a1,s5
    80003c10:	8552                	mv	a0,s4
    80003c12:	e97ff0ef          	jal	80003aa8 <dirlookup>
    80003c16:	89aa                	mv	s3,a0
    80003c18:	d545                	beqz	a0,80003bc0 <namex+0x7c>
    iunlockput(ip);
    80003c1a:	8552                	mv	a0,s4
    80003c1c:	ae7ff0ef          	jal	80003702 <iunlockput>
    ip = next;
    80003c20:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003c22:	0004c783          	lbu	a5,0(s1)
    80003c26:	01279763          	bne	a5,s2,80003c34 <namex+0xf0>
    path++;
    80003c2a:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003c2c:	0004c783          	lbu	a5,0(s1)
    80003c30:	ff278de3          	beq	a5,s2,80003c2a <namex+0xe6>
  if(*path == 0)
    80003c34:	cb8d                	beqz	a5,80003c66 <namex+0x122>
  while(*path != '/' && *path != 0)
    80003c36:	0004c783          	lbu	a5,0(s1)
    80003c3a:	89a6                	mv	s3,s1
  len = path - s;
    80003c3c:	4c81                	li	s9,0
    80003c3e:	4601                	li	a2,0
  while(*path != '/' && *path != 0)
    80003c40:	01278963          	beq	a5,s2,80003c52 <namex+0x10e>
    80003c44:	d3d9                	beqz	a5,80003bca <namex+0x86>
    path++;
    80003c46:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003c48:	0009c783          	lbu	a5,0(s3)
    80003c4c:	ff279ce3          	bne	a5,s2,80003c44 <namex+0x100>
    80003c50:	bfad                	j	80003bca <namex+0x86>
    memmove(name, s, len);
    80003c52:	2601                	sext.w	a2,a2
    80003c54:	85a6                	mv	a1,s1
    80003c56:	8556                	mv	a0,s5
    80003c58:	ae4fd0ef          	jal	80000f3c <memmove>
    name[len] = 0;
    80003c5c:	9cd6                	add	s9,s9,s5
    80003c5e:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003c62:	84ce                	mv	s1,s3
    80003c64:	bfbd                	j	80003be2 <namex+0x9e>
  if(nameiparent){
    80003c66:	f20b0be3          	beqz	s6,80003b9c <namex+0x58>
    iput(ip);
    80003c6a:	8552                	mv	a0,s4
    80003c6c:	a0fff0ef          	jal	8000367a <iput>
    return 0;
    80003c70:	4a01                	li	s4,0
    80003c72:	b72d                	j	80003b9c <namex+0x58>

0000000080003c74 <dirlink>:
{
    80003c74:	7139                	addi	sp,sp,-64
    80003c76:	fc06                	sd	ra,56(sp)
    80003c78:	f822                	sd	s0,48(sp)
    80003c7a:	f04a                	sd	s2,32(sp)
    80003c7c:	ec4e                	sd	s3,24(sp)
    80003c7e:	e852                	sd	s4,16(sp)
    80003c80:	0080                	addi	s0,sp,64
    80003c82:	892a                	mv	s2,a0
    80003c84:	8a2e                	mv	s4,a1
    80003c86:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003c88:	4601                	li	a2,0
    80003c8a:	e1fff0ef          	jal	80003aa8 <dirlookup>
    80003c8e:	e535                	bnez	a0,80003cfa <dirlink+0x86>
    80003c90:	f426                	sd	s1,40(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c92:	04c92483          	lw	s1,76(s2)
    80003c96:	c48d                	beqz	s1,80003cc0 <dirlink+0x4c>
    80003c98:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c9a:	4741                	li	a4,16
    80003c9c:	86a6                	mv	a3,s1
    80003c9e:	fc040613          	addi	a2,s0,-64
    80003ca2:	4581                	li	a1,0
    80003ca4:	854a                	mv	a0,s2
    80003ca6:	be3ff0ef          	jal	80003888 <readi>
    80003caa:	47c1                	li	a5,16
    80003cac:	04f51b63          	bne	a0,a5,80003d02 <dirlink+0x8e>
    if(de.inum == 0)
    80003cb0:	fc045783          	lhu	a5,-64(s0)
    80003cb4:	c791                	beqz	a5,80003cc0 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003cb6:	24c1                	addiw	s1,s1,16
    80003cb8:	04c92783          	lw	a5,76(s2)
    80003cbc:	fcf4efe3          	bltu	s1,a5,80003c9a <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003cc0:	4639                	li	a2,14
    80003cc2:	85d2                	mv	a1,s4
    80003cc4:	fc240513          	addi	a0,s0,-62
    80003cc8:	b1afd0ef          	jal	80000fe2 <strncpy>
  de.inum = inum;
    80003ccc:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003cd0:	4741                	li	a4,16
    80003cd2:	86a6                	mv	a3,s1
    80003cd4:	fc040613          	addi	a2,s0,-64
    80003cd8:	4581                	li	a1,0
    80003cda:	854a                	mv	a0,s2
    80003cdc:	ca9ff0ef          	jal	80003984 <writei>
    80003ce0:	1541                	addi	a0,a0,-16
    80003ce2:	00a03533          	snez	a0,a0
    80003ce6:	40a00533          	neg	a0,a0
    80003cea:	74a2                	ld	s1,40(sp)
}
    80003cec:	70e2                	ld	ra,56(sp)
    80003cee:	7442                	ld	s0,48(sp)
    80003cf0:	7902                	ld	s2,32(sp)
    80003cf2:	69e2                	ld	s3,24(sp)
    80003cf4:	6a42                	ld	s4,16(sp)
    80003cf6:	6121                	addi	sp,sp,64
    80003cf8:	8082                	ret
    iput(ip);
    80003cfa:	981ff0ef          	jal	8000367a <iput>
    return -1;
    80003cfe:	557d                	li	a0,-1
    80003d00:	b7f5                	j	80003cec <dirlink+0x78>
      panic("dirlink read");
    80003d02:	00004517          	auipc	a0,0x4
    80003d06:	92650513          	addi	a0,a0,-1754 # 80007628 <etext+0x628>
    80003d0a:	ad7fc0ef          	jal	800007e0 <panic>

0000000080003d0e <namei>:

struct inode*
namei(char *path)
{
    80003d0e:	1101                	addi	sp,sp,-32
    80003d10:	ec06                	sd	ra,24(sp)
    80003d12:	e822                	sd	s0,16(sp)
    80003d14:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003d16:	fe040613          	addi	a2,s0,-32
    80003d1a:	4581                	li	a1,0
    80003d1c:	e29ff0ef          	jal	80003b44 <namex>
}
    80003d20:	60e2                	ld	ra,24(sp)
    80003d22:	6442                	ld	s0,16(sp)
    80003d24:	6105                	addi	sp,sp,32
    80003d26:	8082                	ret

0000000080003d28 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003d28:	1141                	addi	sp,sp,-16
    80003d2a:	e406                	sd	ra,8(sp)
    80003d2c:	e022                	sd	s0,0(sp)
    80003d2e:	0800                	addi	s0,sp,16
    80003d30:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003d32:	4585                	li	a1,1
    80003d34:	e11ff0ef          	jal	80003b44 <namex>
}
    80003d38:	60a2                	ld	ra,8(sp)
    80003d3a:	6402                	ld	s0,0(sp)
    80003d3c:	0141                	addi	sp,sp,16
    80003d3e:	8082                	ret

0000000080003d40 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003d40:	1101                	addi	sp,sp,-32
    80003d42:	ec06                	sd	ra,24(sp)
    80003d44:	e822                	sd	s0,16(sp)
    80003d46:	e426                	sd	s1,8(sp)
    80003d48:	e04a                	sd	s2,0(sp)
    80003d4a:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003d4c:	0003e917          	auipc	s2,0x3e
    80003d50:	7e490913          	addi	s2,s2,2020 # 80042530 <log>
    80003d54:	01892583          	lw	a1,24(s2)
    80003d58:	02492503          	lw	a0,36(s2)
    80003d5c:	8d0ff0ef          	jal	80002e2c <bread>
    80003d60:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003d62:	02892603          	lw	a2,40(s2)
    80003d66:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003d68:	00c05f63          	blez	a2,80003d86 <write_head+0x46>
    80003d6c:	0003e717          	auipc	a4,0x3e
    80003d70:	7f070713          	addi	a4,a4,2032 # 8004255c <log+0x2c>
    80003d74:	87aa                	mv	a5,a0
    80003d76:	060a                	slli	a2,a2,0x2
    80003d78:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003d7a:	4314                	lw	a3,0(a4)
    80003d7c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003d7e:	0711                	addi	a4,a4,4
    80003d80:	0791                	addi	a5,a5,4
    80003d82:	fec79ce3          	bne	a5,a2,80003d7a <write_head+0x3a>
  }
  bwrite(buf);
    80003d86:	8526                	mv	a0,s1
    80003d88:	97aff0ef          	jal	80002f02 <bwrite>
  brelse(buf);
    80003d8c:	8526                	mv	a0,s1
    80003d8e:	9a6ff0ef          	jal	80002f34 <brelse>
}
    80003d92:	60e2                	ld	ra,24(sp)
    80003d94:	6442                	ld	s0,16(sp)
    80003d96:	64a2                	ld	s1,8(sp)
    80003d98:	6902                	ld	s2,0(sp)
    80003d9a:	6105                	addi	sp,sp,32
    80003d9c:	8082                	ret

0000000080003d9e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d9e:	0003e797          	auipc	a5,0x3e
    80003da2:	7ba7a783          	lw	a5,1978(a5) # 80042558 <log+0x28>
    80003da6:	0af05e63          	blez	a5,80003e62 <install_trans+0xc4>
{
    80003daa:	715d                	addi	sp,sp,-80
    80003dac:	e486                	sd	ra,72(sp)
    80003dae:	e0a2                	sd	s0,64(sp)
    80003db0:	fc26                	sd	s1,56(sp)
    80003db2:	f84a                	sd	s2,48(sp)
    80003db4:	f44e                	sd	s3,40(sp)
    80003db6:	f052                	sd	s4,32(sp)
    80003db8:	ec56                	sd	s5,24(sp)
    80003dba:	e85a                	sd	s6,16(sp)
    80003dbc:	e45e                	sd	s7,8(sp)
    80003dbe:	0880                	addi	s0,sp,80
    80003dc0:	8b2a                	mv	s6,a0
    80003dc2:	0003ea97          	auipc	s5,0x3e
    80003dc6:	79aa8a93          	addi	s5,s5,1946 # 8004255c <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003dca:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003dcc:	00004b97          	auipc	s7,0x4
    80003dd0:	86cb8b93          	addi	s7,s7,-1940 # 80007638 <etext+0x638>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003dd4:	0003ea17          	auipc	s4,0x3e
    80003dd8:	75ca0a13          	addi	s4,s4,1884 # 80042530 <log>
    80003ddc:	a025                	j	80003e04 <install_trans+0x66>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003dde:	000aa603          	lw	a2,0(s5)
    80003de2:	85ce                	mv	a1,s3
    80003de4:	855e                	mv	a0,s7
    80003de6:	f14fc0ef          	jal	800004fa <printf>
    80003dea:	a839                	j	80003e08 <install_trans+0x6a>
    brelse(lbuf);
    80003dec:	854a                	mv	a0,s2
    80003dee:	946ff0ef          	jal	80002f34 <brelse>
    brelse(dbuf);
    80003df2:	8526                	mv	a0,s1
    80003df4:	940ff0ef          	jal	80002f34 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003df8:	2985                	addiw	s3,s3,1
    80003dfa:	0a91                	addi	s5,s5,4
    80003dfc:	028a2783          	lw	a5,40(s4)
    80003e00:	04f9d663          	bge	s3,a5,80003e4c <install_trans+0xae>
    if(recovering) {
    80003e04:	fc0b1de3          	bnez	s6,80003dde <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003e08:	018a2583          	lw	a1,24(s4)
    80003e0c:	013585bb          	addw	a1,a1,s3
    80003e10:	2585                	addiw	a1,a1,1
    80003e12:	024a2503          	lw	a0,36(s4)
    80003e16:	816ff0ef          	jal	80002e2c <bread>
    80003e1a:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003e1c:	000aa583          	lw	a1,0(s5)
    80003e20:	024a2503          	lw	a0,36(s4)
    80003e24:	808ff0ef          	jal	80002e2c <bread>
    80003e28:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003e2a:	40000613          	li	a2,1024
    80003e2e:	05890593          	addi	a1,s2,88
    80003e32:	05850513          	addi	a0,a0,88
    80003e36:	906fd0ef          	jal	80000f3c <memmove>
    bwrite(dbuf);  // write dst to disk
    80003e3a:	8526                	mv	a0,s1
    80003e3c:	8c6ff0ef          	jal	80002f02 <bwrite>
    if(recovering == 0)
    80003e40:	fa0b16e3          	bnez	s6,80003dec <install_trans+0x4e>
      bunpin(dbuf);
    80003e44:	8526                	mv	a0,s1
    80003e46:	9aaff0ef          	jal	80002ff0 <bunpin>
    80003e4a:	b74d                	j	80003dec <install_trans+0x4e>
}
    80003e4c:	60a6                	ld	ra,72(sp)
    80003e4e:	6406                	ld	s0,64(sp)
    80003e50:	74e2                	ld	s1,56(sp)
    80003e52:	7942                	ld	s2,48(sp)
    80003e54:	79a2                	ld	s3,40(sp)
    80003e56:	7a02                	ld	s4,32(sp)
    80003e58:	6ae2                	ld	s5,24(sp)
    80003e5a:	6b42                	ld	s6,16(sp)
    80003e5c:	6ba2                	ld	s7,8(sp)
    80003e5e:	6161                	addi	sp,sp,80
    80003e60:	8082                	ret
    80003e62:	8082                	ret

0000000080003e64 <initlog>:
{
    80003e64:	7179                	addi	sp,sp,-48
    80003e66:	f406                	sd	ra,40(sp)
    80003e68:	f022                	sd	s0,32(sp)
    80003e6a:	ec26                	sd	s1,24(sp)
    80003e6c:	e84a                	sd	s2,16(sp)
    80003e6e:	e44e                	sd	s3,8(sp)
    80003e70:	1800                	addi	s0,sp,48
    80003e72:	892a                	mv	s2,a0
    80003e74:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003e76:	0003e497          	auipc	s1,0x3e
    80003e7a:	6ba48493          	addi	s1,s1,1722 # 80042530 <log>
    80003e7e:	00003597          	auipc	a1,0x3
    80003e82:	7da58593          	addi	a1,a1,2010 # 80007658 <etext+0x658>
    80003e86:	8526                	mv	a0,s1
    80003e88:	f05fc0ef          	jal	80000d8c <initlock>
  log.start = sb->logstart;
    80003e8c:	0149a583          	lw	a1,20(s3)
    80003e90:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003e92:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003e96:	854a                	mv	a0,s2
    80003e98:	f95fe0ef          	jal	80002e2c <bread>
  log.lh.n = lh->n;
    80003e9c:	4d30                	lw	a2,88(a0)
    80003e9e:	d490                	sw	a2,40(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003ea0:	00c05f63          	blez	a2,80003ebe <initlog+0x5a>
    80003ea4:	87aa                	mv	a5,a0
    80003ea6:	0003e717          	auipc	a4,0x3e
    80003eaa:	6b670713          	addi	a4,a4,1718 # 8004255c <log+0x2c>
    80003eae:	060a                	slli	a2,a2,0x2
    80003eb0:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003eb2:	4ff4                	lw	a3,92(a5)
    80003eb4:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003eb6:	0791                	addi	a5,a5,4
    80003eb8:	0711                	addi	a4,a4,4
    80003eba:	fec79ce3          	bne	a5,a2,80003eb2 <initlog+0x4e>
  brelse(buf);
    80003ebe:	876ff0ef          	jal	80002f34 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003ec2:	4505                	li	a0,1
    80003ec4:	edbff0ef          	jal	80003d9e <install_trans>
  log.lh.n = 0;
    80003ec8:	0003e797          	auipc	a5,0x3e
    80003ecc:	6807a823          	sw	zero,1680(a5) # 80042558 <log+0x28>
  write_head(); // clear the log
    80003ed0:	e71ff0ef          	jal	80003d40 <write_head>
}
    80003ed4:	70a2                	ld	ra,40(sp)
    80003ed6:	7402                	ld	s0,32(sp)
    80003ed8:	64e2                	ld	s1,24(sp)
    80003eda:	6942                	ld	s2,16(sp)
    80003edc:	69a2                	ld	s3,8(sp)
    80003ede:	6145                	addi	sp,sp,48
    80003ee0:	8082                	ret

0000000080003ee2 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003ee2:	1101                	addi	sp,sp,-32
    80003ee4:	ec06                	sd	ra,24(sp)
    80003ee6:	e822                	sd	s0,16(sp)
    80003ee8:	e426                	sd	s1,8(sp)
    80003eea:	e04a                	sd	s2,0(sp)
    80003eec:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003eee:	0003e517          	auipc	a0,0x3e
    80003ef2:	64250513          	addi	a0,a0,1602 # 80042530 <log>
    80003ef6:	f17fc0ef          	jal	80000e0c <acquire>
  while(1){
    if(log.committing){
    80003efa:	0003e497          	auipc	s1,0x3e
    80003efe:	63648493          	addi	s1,s1,1590 # 80042530 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003f02:	4979                	li	s2,30
    80003f04:	a029                	j	80003f0e <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003f06:	85a6                	mv	a1,s1
    80003f08:	8526                	mv	a0,s1
    80003f0a:	ab6fe0ef          	jal	800021c0 <sleep>
    if(log.committing){
    80003f0e:	509c                	lw	a5,32(s1)
    80003f10:	fbfd                	bnez	a5,80003f06 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003f12:	4cd8                	lw	a4,28(s1)
    80003f14:	2705                	addiw	a4,a4,1
    80003f16:	0027179b          	slliw	a5,a4,0x2
    80003f1a:	9fb9                	addw	a5,a5,a4
    80003f1c:	0017979b          	slliw	a5,a5,0x1
    80003f20:	5494                	lw	a3,40(s1)
    80003f22:	9fb5                	addw	a5,a5,a3
    80003f24:	00f95763          	bge	s2,a5,80003f32 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003f28:	85a6                	mv	a1,s1
    80003f2a:	8526                	mv	a0,s1
    80003f2c:	a94fe0ef          	jal	800021c0 <sleep>
    80003f30:	bff9                	j	80003f0e <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003f32:	0003e517          	auipc	a0,0x3e
    80003f36:	5fe50513          	addi	a0,a0,1534 # 80042530 <log>
    80003f3a:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80003f3c:	f69fc0ef          	jal	80000ea4 <release>
      break;
    }
  }
}
    80003f40:	60e2                	ld	ra,24(sp)
    80003f42:	6442                	ld	s0,16(sp)
    80003f44:	64a2                	ld	s1,8(sp)
    80003f46:	6902                	ld	s2,0(sp)
    80003f48:	6105                	addi	sp,sp,32
    80003f4a:	8082                	ret

0000000080003f4c <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003f4c:	7139                	addi	sp,sp,-64
    80003f4e:	fc06                	sd	ra,56(sp)
    80003f50:	f822                	sd	s0,48(sp)
    80003f52:	f426                	sd	s1,40(sp)
    80003f54:	f04a                	sd	s2,32(sp)
    80003f56:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003f58:	0003e497          	auipc	s1,0x3e
    80003f5c:	5d848493          	addi	s1,s1,1496 # 80042530 <log>
    80003f60:	8526                	mv	a0,s1
    80003f62:	eabfc0ef          	jal	80000e0c <acquire>
  log.outstanding -= 1;
    80003f66:	4cdc                	lw	a5,28(s1)
    80003f68:	37fd                	addiw	a5,a5,-1
    80003f6a:	0007891b          	sext.w	s2,a5
    80003f6e:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003f70:	509c                	lw	a5,32(s1)
    80003f72:	ef9d                	bnez	a5,80003fb0 <end_op+0x64>
    panic("log.committing");
  if(log.outstanding == 0){
    80003f74:	04091763          	bnez	s2,80003fc2 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003f78:	0003e497          	auipc	s1,0x3e
    80003f7c:	5b848493          	addi	s1,s1,1464 # 80042530 <log>
    80003f80:	4785                	li	a5,1
    80003f82:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003f84:	8526                	mv	a0,s1
    80003f86:	f1ffc0ef          	jal	80000ea4 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003f8a:	549c                	lw	a5,40(s1)
    80003f8c:	04f04b63          	bgtz	a5,80003fe2 <end_op+0x96>
    acquire(&log.lock);
    80003f90:	0003e497          	auipc	s1,0x3e
    80003f94:	5a048493          	addi	s1,s1,1440 # 80042530 <log>
    80003f98:	8526                	mv	a0,s1
    80003f9a:	e73fc0ef          	jal	80000e0c <acquire>
    log.committing = 0;
    80003f9e:	0204a023          	sw	zero,32(s1)
    wakeup(&log);
    80003fa2:	8526                	mv	a0,s1
    80003fa4:	a68fe0ef          	jal	8000220c <wakeup>
    release(&log.lock);
    80003fa8:	8526                	mv	a0,s1
    80003faa:	efbfc0ef          	jal	80000ea4 <release>
}
    80003fae:	a025                	j	80003fd6 <end_op+0x8a>
    80003fb0:	ec4e                	sd	s3,24(sp)
    80003fb2:	e852                	sd	s4,16(sp)
    80003fb4:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003fb6:	00003517          	auipc	a0,0x3
    80003fba:	6aa50513          	addi	a0,a0,1706 # 80007660 <etext+0x660>
    80003fbe:	823fc0ef          	jal	800007e0 <panic>
    wakeup(&log);
    80003fc2:	0003e497          	auipc	s1,0x3e
    80003fc6:	56e48493          	addi	s1,s1,1390 # 80042530 <log>
    80003fca:	8526                	mv	a0,s1
    80003fcc:	a40fe0ef          	jal	8000220c <wakeup>
  release(&log.lock);
    80003fd0:	8526                	mv	a0,s1
    80003fd2:	ed3fc0ef          	jal	80000ea4 <release>
}
    80003fd6:	70e2                	ld	ra,56(sp)
    80003fd8:	7442                	ld	s0,48(sp)
    80003fda:	74a2                	ld	s1,40(sp)
    80003fdc:	7902                	ld	s2,32(sp)
    80003fde:	6121                	addi	sp,sp,64
    80003fe0:	8082                	ret
    80003fe2:	ec4e                	sd	s3,24(sp)
    80003fe4:	e852                	sd	s4,16(sp)
    80003fe6:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fe8:	0003ea97          	auipc	s5,0x3e
    80003fec:	574a8a93          	addi	s5,s5,1396 # 8004255c <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003ff0:	0003ea17          	auipc	s4,0x3e
    80003ff4:	540a0a13          	addi	s4,s4,1344 # 80042530 <log>
    80003ff8:	018a2583          	lw	a1,24(s4)
    80003ffc:	012585bb          	addw	a1,a1,s2
    80004000:	2585                	addiw	a1,a1,1
    80004002:	024a2503          	lw	a0,36(s4)
    80004006:	e27fe0ef          	jal	80002e2c <bread>
    8000400a:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    8000400c:	000aa583          	lw	a1,0(s5)
    80004010:	024a2503          	lw	a0,36(s4)
    80004014:	e19fe0ef          	jal	80002e2c <bread>
    80004018:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    8000401a:	40000613          	li	a2,1024
    8000401e:	05850593          	addi	a1,a0,88
    80004022:	05848513          	addi	a0,s1,88
    80004026:	f17fc0ef          	jal	80000f3c <memmove>
    bwrite(to);  // write the log
    8000402a:	8526                	mv	a0,s1
    8000402c:	ed7fe0ef          	jal	80002f02 <bwrite>
    brelse(from);
    80004030:	854e                	mv	a0,s3
    80004032:	f03fe0ef          	jal	80002f34 <brelse>
    brelse(to);
    80004036:	8526                	mv	a0,s1
    80004038:	efdfe0ef          	jal	80002f34 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000403c:	2905                	addiw	s2,s2,1
    8000403e:	0a91                	addi	s5,s5,4
    80004040:	028a2783          	lw	a5,40(s4)
    80004044:	faf94ae3          	blt	s2,a5,80003ff8 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80004048:	cf9ff0ef          	jal	80003d40 <write_head>
    install_trans(0); // Now install writes to home locations
    8000404c:	4501                	li	a0,0
    8000404e:	d51ff0ef          	jal	80003d9e <install_trans>
    log.lh.n = 0;
    80004052:	0003e797          	auipc	a5,0x3e
    80004056:	5007a323          	sw	zero,1286(a5) # 80042558 <log+0x28>
    write_head();    // Erase the transaction from the log
    8000405a:	ce7ff0ef          	jal	80003d40 <write_head>
    8000405e:	69e2                	ld	s3,24(sp)
    80004060:	6a42                	ld	s4,16(sp)
    80004062:	6aa2                	ld	s5,8(sp)
    80004064:	b735                	j	80003f90 <end_op+0x44>

0000000080004066 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80004066:	1101                	addi	sp,sp,-32
    80004068:	ec06                	sd	ra,24(sp)
    8000406a:	e822                	sd	s0,16(sp)
    8000406c:	e426                	sd	s1,8(sp)
    8000406e:	e04a                	sd	s2,0(sp)
    80004070:	1000                	addi	s0,sp,32
    80004072:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004074:	0003e917          	auipc	s2,0x3e
    80004078:	4bc90913          	addi	s2,s2,1212 # 80042530 <log>
    8000407c:	854a                	mv	a0,s2
    8000407e:	d8ffc0ef          	jal	80000e0c <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80004082:	02892603          	lw	a2,40(s2)
    80004086:	47f5                	li	a5,29
    80004088:	04c7cc63          	blt	a5,a2,800040e0 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000408c:	0003e797          	auipc	a5,0x3e
    80004090:	4c07a783          	lw	a5,1216(a5) # 8004254c <log+0x1c>
    80004094:	04f05c63          	blez	a5,800040ec <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004098:	4781                	li	a5,0
    8000409a:	04c05f63          	blez	a2,800040f8 <log_write+0x92>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000409e:	44cc                	lw	a1,12(s1)
    800040a0:	0003e717          	auipc	a4,0x3e
    800040a4:	4bc70713          	addi	a4,a4,1212 # 8004255c <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    800040a8:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800040aa:	4314                	lw	a3,0(a4)
    800040ac:	04b68663          	beq	a3,a1,800040f8 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    800040b0:	2785                	addiw	a5,a5,1
    800040b2:	0711                	addi	a4,a4,4
    800040b4:	fef61be3          	bne	a2,a5,800040aa <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    800040b8:	0621                	addi	a2,a2,8
    800040ba:	060a                	slli	a2,a2,0x2
    800040bc:	0003e797          	auipc	a5,0x3e
    800040c0:	47478793          	addi	a5,a5,1140 # 80042530 <log>
    800040c4:	97b2                	add	a5,a5,a2
    800040c6:	44d8                	lw	a4,12(s1)
    800040c8:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    800040ca:	8526                	mv	a0,s1
    800040cc:	ef1fe0ef          	jal	80002fbc <bpin>
    log.lh.n++;
    800040d0:	0003e717          	auipc	a4,0x3e
    800040d4:	46070713          	addi	a4,a4,1120 # 80042530 <log>
    800040d8:	571c                	lw	a5,40(a4)
    800040da:	2785                	addiw	a5,a5,1
    800040dc:	d71c                	sw	a5,40(a4)
    800040de:	a80d                	j	80004110 <log_write+0xaa>
    panic("too big a transaction");
    800040e0:	00003517          	auipc	a0,0x3
    800040e4:	59050513          	addi	a0,a0,1424 # 80007670 <etext+0x670>
    800040e8:	ef8fc0ef          	jal	800007e0 <panic>
    panic("log_write outside of trans");
    800040ec:	00003517          	auipc	a0,0x3
    800040f0:	59c50513          	addi	a0,a0,1436 # 80007688 <etext+0x688>
    800040f4:	eecfc0ef          	jal	800007e0 <panic>
  log.lh.block[i] = b->blockno;
    800040f8:	00878693          	addi	a3,a5,8
    800040fc:	068a                	slli	a3,a3,0x2
    800040fe:	0003e717          	auipc	a4,0x3e
    80004102:	43270713          	addi	a4,a4,1074 # 80042530 <log>
    80004106:	9736                	add	a4,a4,a3
    80004108:	44d4                	lw	a3,12(s1)
    8000410a:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000410c:	faf60fe3          	beq	a2,a5,800040ca <log_write+0x64>
  }
  release(&log.lock);
    80004110:	0003e517          	auipc	a0,0x3e
    80004114:	42050513          	addi	a0,a0,1056 # 80042530 <log>
    80004118:	d8dfc0ef          	jal	80000ea4 <release>
}
    8000411c:	60e2                	ld	ra,24(sp)
    8000411e:	6442                	ld	s0,16(sp)
    80004120:	64a2                	ld	s1,8(sp)
    80004122:	6902                	ld	s2,0(sp)
    80004124:	6105                	addi	sp,sp,32
    80004126:	8082                	ret

0000000080004128 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80004128:	1101                	addi	sp,sp,-32
    8000412a:	ec06                	sd	ra,24(sp)
    8000412c:	e822                	sd	s0,16(sp)
    8000412e:	e426                	sd	s1,8(sp)
    80004130:	e04a                	sd	s2,0(sp)
    80004132:	1000                	addi	s0,sp,32
    80004134:	84aa                	mv	s1,a0
    80004136:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004138:	00003597          	auipc	a1,0x3
    8000413c:	57058593          	addi	a1,a1,1392 # 800076a8 <etext+0x6a8>
    80004140:	0521                	addi	a0,a0,8
    80004142:	c4bfc0ef          	jal	80000d8c <initlock>
  lk->name = name;
    80004146:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000414a:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000414e:	0204a423          	sw	zero,40(s1)
}
    80004152:	60e2                	ld	ra,24(sp)
    80004154:	6442                	ld	s0,16(sp)
    80004156:	64a2                	ld	s1,8(sp)
    80004158:	6902                	ld	s2,0(sp)
    8000415a:	6105                	addi	sp,sp,32
    8000415c:	8082                	ret

000000008000415e <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000415e:	1101                	addi	sp,sp,-32
    80004160:	ec06                	sd	ra,24(sp)
    80004162:	e822                	sd	s0,16(sp)
    80004164:	e426                	sd	s1,8(sp)
    80004166:	e04a                	sd	s2,0(sp)
    80004168:	1000                	addi	s0,sp,32
    8000416a:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000416c:	00850913          	addi	s2,a0,8
    80004170:	854a                	mv	a0,s2
    80004172:	c9bfc0ef          	jal	80000e0c <acquire>
  while (lk->locked) {
    80004176:	409c                	lw	a5,0(s1)
    80004178:	c799                	beqz	a5,80004186 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    8000417a:	85ca                	mv	a1,s2
    8000417c:	8526                	mv	a0,s1
    8000417e:	842fe0ef          	jal	800021c0 <sleep>
  while (lk->locked) {
    80004182:	409c                	lw	a5,0(s1)
    80004184:	fbfd                	bnez	a5,8000417a <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004186:	4785                	li	a5,1
    80004188:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    8000418a:	a3ffd0ef          	jal	80001bc8 <myproc>
    8000418e:	591c                	lw	a5,48(a0)
    80004190:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004192:	854a                	mv	a0,s2
    80004194:	d11fc0ef          	jal	80000ea4 <release>
}
    80004198:	60e2                	ld	ra,24(sp)
    8000419a:	6442                	ld	s0,16(sp)
    8000419c:	64a2                	ld	s1,8(sp)
    8000419e:	6902                	ld	s2,0(sp)
    800041a0:	6105                	addi	sp,sp,32
    800041a2:	8082                	ret

00000000800041a4 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800041a4:	1101                	addi	sp,sp,-32
    800041a6:	ec06                	sd	ra,24(sp)
    800041a8:	e822                	sd	s0,16(sp)
    800041aa:	e426                	sd	s1,8(sp)
    800041ac:	e04a                	sd	s2,0(sp)
    800041ae:	1000                	addi	s0,sp,32
    800041b0:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800041b2:	00850913          	addi	s2,a0,8
    800041b6:	854a                	mv	a0,s2
    800041b8:	c55fc0ef          	jal	80000e0c <acquire>
  lk->locked = 0;
    800041bc:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800041c0:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800041c4:	8526                	mv	a0,s1
    800041c6:	846fe0ef          	jal	8000220c <wakeup>
  release(&lk->lk);
    800041ca:	854a                	mv	a0,s2
    800041cc:	cd9fc0ef          	jal	80000ea4 <release>
}
    800041d0:	60e2                	ld	ra,24(sp)
    800041d2:	6442                	ld	s0,16(sp)
    800041d4:	64a2                	ld	s1,8(sp)
    800041d6:	6902                	ld	s2,0(sp)
    800041d8:	6105                	addi	sp,sp,32
    800041da:	8082                	ret

00000000800041dc <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800041dc:	7179                	addi	sp,sp,-48
    800041de:	f406                	sd	ra,40(sp)
    800041e0:	f022                	sd	s0,32(sp)
    800041e2:	ec26                	sd	s1,24(sp)
    800041e4:	e84a                	sd	s2,16(sp)
    800041e6:	1800                	addi	s0,sp,48
    800041e8:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800041ea:	00850913          	addi	s2,a0,8
    800041ee:	854a                	mv	a0,s2
    800041f0:	c1dfc0ef          	jal	80000e0c <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800041f4:	409c                	lw	a5,0(s1)
    800041f6:	ef81                	bnez	a5,8000420e <holdingsleep+0x32>
    800041f8:	4481                	li	s1,0
  release(&lk->lk);
    800041fa:	854a                	mv	a0,s2
    800041fc:	ca9fc0ef          	jal	80000ea4 <release>
  return r;
}
    80004200:	8526                	mv	a0,s1
    80004202:	70a2                	ld	ra,40(sp)
    80004204:	7402                	ld	s0,32(sp)
    80004206:	64e2                	ld	s1,24(sp)
    80004208:	6942                	ld	s2,16(sp)
    8000420a:	6145                	addi	sp,sp,48
    8000420c:	8082                	ret
    8000420e:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80004210:	0284a983          	lw	s3,40(s1)
    80004214:	9b5fd0ef          	jal	80001bc8 <myproc>
    80004218:	5904                	lw	s1,48(a0)
    8000421a:	413484b3          	sub	s1,s1,s3
    8000421e:	0014b493          	seqz	s1,s1
    80004222:	69a2                	ld	s3,8(sp)
    80004224:	bfd9                	j	800041fa <holdingsleep+0x1e>

0000000080004226 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004226:	1141                	addi	sp,sp,-16
    80004228:	e406                	sd	ra,8(sp)
    8000422a:	e022                	sd	s0,0(sp)
    8000422c:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000422e:	00003597          	auipc	a1,0x3
    80004232:	48a58593          	addi	a1,a1,1162 # 800076b8 <etext+0x6b8>
    80004236:	0003e517          	auipc	a0,0x3e
    8000423a:	44250513          	addi	a0,a0,1090 # 80042678 <ftable>
    8000423e:	b4ffc0ef          	jal	80000d8c <initlock>
}
    80004242:	60a2                	ld	ra,8(sp)
    80004244:	6402                	ld	s0,0(sp)
    80004246:	0141                	addi	sp,sp,16
    80004248:	8082                	ret

000000008000424a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000424a:	1101                	addi	sp,sp,-32
    8000424c:	ec06                	sd	ra,24(sp)
    8000424e:	e822                	sd	s0,16(sp)
    80004250:	e426                	sd	s1,8(sp)
    80004252:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004254:	0003e517          	auipc	a0,0x3e
    80004258:	42450513          	addi	a0,a0,1060 # 80042678 <ftable>
    8000425c:	bb1fc0ef          	jal	80000e0c <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004260:	0003e497          	auipc	s1,0x3e
    80004264:	43048493          	addi	s1,s1,1072 # 80042690 <ftable+0x18>
    80004268:	0003f717          	auipc	a4,0x3f
    8000426c:	3c870713          	addi	a4,a4,968 # 80043630 <disk>
    if(f->ref == 0){
    80004270:	40dc                	lw	a5,4(s1)
    80004272:	cf89                	beqz	a5,8000428c <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004274:	02848493          	addi	s1,s1,40
    80004278:	fee49ce3          	bne	s1,a4,80004270 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000427c:	0003e517          	auipc	a0,0x3e
    80004280:	3fc50513          	addi	a0,a0,1020 # 80042678 <ftable>
    80004284:	c21fc0ef          	jal	80000ea4 <release>
  return 0;
    80004288:	4481                	li	s1,0
    8000428a:	a809                	j	8000429c <filealloc+0x52>
      f->ref = 1;
    8000428c:	4785                	li	a5,1
    8000428e:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004290:	0003e517          	auipc	a0,0x3e
    80004294:	3e850513          	addi	a0,a0,1000 # 80042678 <ftable>
    80004298:	c0dfc0ef          	jal	80000ea4 <release>
}
    8000429c:	8526                	mv	a0,s1
    8000429e:	60e2                	ld	ra,24(sp)
    800042a0:	6442                	ld	s0,16(sp)
    800042a2:	64a2                	ld	s1,8(sp)
    800042a4:	6105                	addi	sp,sp,32
    800042a6:	8082                	ret

00000000800042a8 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800042a8:	1101                	addi	sp,sp,-32
    800042aa:	ec06                	sd	ra,24(sp)
    800042ac:	e822                	sd	s0,16(sp)
    800042ae:	e426                	sd	s1,8(sp)
    800042b0:	1000                	addi	s0,sp,32
    800042b2:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800042b4:	0003e517          	auipc	a0,0x3e
    800042b8:	3c450513          	addi	a0,a0,964 # 80042678 <ftable>
    800042bc:	b51fc0ef          	jal	80000e0c <acquire>
  if(f->ref < 1)
    800042c0:	40dc                	lw	a5,4(s1)
    800042c2:	02f05063          	blez	a5,800042e2 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    800042c6:	2785                	addiw	a5,a5,1
    800042c8:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800042ca:	0003e517          	auipc	a0,0x3e
    800042ce:	3ae50513          	addi	a0,a0,942 # 80042678 <ftable>
    800042d2:	bd3fc0ef          	jal	80000ea4 <release>
  return f;
}
    800042d6:	8526                	mv	a0,s1
    800042d8:	60e2                	ld	ra,24(sp)
    800042da:	6442                	ld	s0,16(sp)
    800042dc:	64a2                	ld	s1,8(sp)
    800042de:	6105                	addi	sp,sp,32
    800042e0:	8082                	ret
    panic("filedup");
    800042e2:	00003517          	auipc	a0,0x3
    800042e6:	3de50513          	addi	a0,a0,990 # 800076c0 <etext+0x6c0>
    800042ea:	cf6fc0ef          	jal	800007e0 <panic>

00000000800042ee <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800042ee:	7139                	addi	sp,sp,-64
    800042f0:	fc06                	sd	ra,56(sp)
    800042f2:	f822                	sd	s0,48(sp)
    800042f4:	f426                	sd	s1,40(sp)
    800042f6:	0080                	addi	s0,sp,64
    800042f8:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800042fa:	0003e517          	auipc	a0,0x3e
    800042fe:	37e50513          	addi	a0,a0,894 # 80042678 <ftable>
    80004302:	b0bfc0ef          	jal	80000e0c <acquire>
  if(f->ref < 1)
    80004306:	40dc                	lw	a5,4(s1)
    80004308:	04f05a63          	blez	a5,8000435c <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    8000430c:	37fd                	addiw	a5,a5,-1
    8000430e:	0007871b          	sext.w	a4,a5
    80004312:	c0dc                	sw	a5,4(s1)
    80004314:	04e04e63          	bgtz	a4,80004370 <fileclose+0x82>
    80004318:	f04a                	sd	s2,32(sp)
    8000431a:	ec4e                	sd	s3,24(sp)
    8000431c:	e852                	sd	s4,16(sp)
    8000431e:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004320:	0004a903          	lw	s2,0(s1)
    80004324:	0094ca83          	lbu	s5,9(s1)
    80004328:	0104ba03          	ld	s4,16(s1)
    8000432c:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80004330:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004334:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004338:	0003e517          	auipc	a0,0x3e
    8000433c:	34050513          	addi	a0,a0,832 # 80042678 <ftable>
    80004340:	b65fc0ef          	jal	80000ea4 <release>

  if(ff.type == FD_PIPE){
    80004344:	4785                	li	a5,1
    80004346:	04f90063          	beq	s2,a5,80004386 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000434a:	3979                	addiw	s2,s2,-2
    8000434c:	4785                	li	a5,1
    8000434e:	0527f563          	bgeu	a5,s2,80004398 <fileclose+0xaa>
    80004352:	7902                	ld	s2,32(sp)
    80004354:	69e2                	ld	s3,24(sp)
    80004356:	6a42                	ld	s4,16(sp)
    80004358:	6aa2                	ld	s5,8(sp)
    8000435a:	a00d                	j	8000437c <fileclose+0x8e>
    8000435c:	f04a                	sd	s2,32(sp)
    8000435e:	ec4e                	sd	s3,24(sp)
    80004360:	e852                	sd	s4,16(sp)
    80004362:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004364:	00003517          	auipc	a0,0x3
    80004368:	36450513          	addi	a0,a0,868 # 800076c8 <etext+0x6c8>
    8000436c:	c74fc0ef          	jal	800007e0 <panic>
    release(&ftable.lock);
    80004370:	0003e517          	auipc	a0,0x3e
    80004374:	30850513          	addi	a0,a0,776 # 80042678 <ftable>
    80004378:	b2dfc0ef          	jal	80000ea4 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000437c:	70e2                	ld	ra,56(sp)
    8000437e:	7442                	ld	s0,48(sp)
    80004380:	74a2                	ld	s1,40(sp)
    80004382:	6121                	addi	sp,sp,64
    80004384:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004386:	85d6                	mv	a1,s5
    80004388:	8552                	mv	a0,s4
    8000438a:	336000ef          	jal	800046c0 <pipeclose>
    8000438e:	7902                	ld	s2,32(sp)
    80004390:	69e2                	ld	s3,24(sp)
    80004392:	6a42                	ld	s4,16(sp)
    80004394:	6aa2                	ld	s5,8(sp)
    80004396:	b7dd                	j	8000437c <fileclose+0x8e>
    begin_op();
    80004398:	b4bff0ef          	jal	80003ee2 <begin_op>
    iput(ff.ip);
    8000439c:	854e                	mv	a0,s3
    8000439e:	adcff0ef          	jal	8000367a <iput>
    end_op();
    800043a2:	babff0ef          	jal	80003f4c <end_op>
    800043a6:	7902                	ld	s2,32(sp)
    800043a8:	69e2                	ld	s3,24(sp)
    800043aa:	6a42                	ld	s4,16(sp)
    800043ac:	6aa2                	ld	s5,8(sp)
    800043ae:	b7f9                	j	8000437c <fileclose+0x8e>

00000000800043b0 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800043b0:	715d                	addi	sp,sp,-80
    800043b2:	e486                	sd	ra,72(sp)
    800043b4:	e0a2                	sd	s0,64(sp)
    800043b6:	fc26                	sd	s1,56(sp)
    800043b8:	f44e                	sd	s3,40(sp)
    800043ba:	0880                	addi	s0,sp,80
    800043bc:	84aa                	mv	s1,a0
    800043be:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800043c0:	809fd0ef          	jal	80001bc8 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800043c4:	409c                	lw	a5,0(s1)
    800043c6:	37f9                	addiw	a5,a5,-2
    800043c8:	4705                	li	a4,1
    800043ca:	04f76063          	bltu	a4,a5,8000440a <filestat+0x5a>
    800043ce:	f84a                	sd	s2,48(sp)
    800043d0:	892a                	mv	s2,a0
    ilock(f->ip);
    800043d2:	6c88                	ld	a0,24(s1)
    800043d4:	924ff0ef          	jal	800034f8 <ilock>
    stati(f->ip, &st);
    800043d8:	fb840593          	addi	a1,s0,-72
    800043dc:	6c88                	ld	a0,24(s1)
    800043de:	c80ff0ef          	jal	8000385e <stati>
    iunlock(f->ip);
    800043e2:	6c88                	ld	a0,24(s1)
    800043e4:	9c2ff0ef          	jal	800035a6 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800043e8:	46e1                	li	a3,24
    800043ea:	fb840613          	addi	a2,s0,-72
    800043ee:	85ce                	mv	a1,s3
    800043f0:	05093503          	ld	a0,80(s2)
    800043f4:	ca4fd0ef          	jal	80001898 <copyout>
    800043f8:	41f5551b          	sraiw	a0,a0,0x1f
    800043fc:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800043fe:	60a6                	ld	ra,72(sp)
    80004400:	6406                	ld	s0,64(sp)
    80004402:	74e2                	ld	s1,56(sp)
    80004404:	79a2                	ld	s3,40(sp)
    80004406:	6161                	addi	sp,sp,80
    80004408:	8082                	ret
  return -1;
    8000440a:	557d                	li	a0,-1
    8000440c:	bfcd                	j	800043fe <filestat+0x4e>

000000008000440e <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000440e:	7179                	addi	sp,sp,-48
    80004410:	f406                	sd	ra,40(sp)
    80004412:	f022                	sd	s0,32(sp)
    80004414:	e84a                	sd	s2,16(sp)
    80004416:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004418:	00854783          	lbu	a5,8(a0)
    8000441c:	cfd1                	beqz	a5,800044b8 <fileread+0xaa>
    8000441e:	ec26                	sd	s1,24(sp)
    80004420:	e44e                	sd	s3,8(sp)
    80004422:	84aa                	mv	s1,a0
    80004424:	89ae                	mv	s3,a1
    80004426:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80004428:	411c                	lw	a5,0(a0)
    8000442a:	4705                	li	a4,1
    8000442c:	04e78363          	beq	a5,a4,80004472 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004430:	470d                	li	a4,3
    80004432:	04e78763          	beq	a5,a4,80004480 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004436:	4709                	li	a4,2
    80004438:	06e79a63          	bne	a5,a4,800044ac <fileread+0x9e>
    ilock(f->ip);
    8000443c:	6d08                	ld	a0,24(a0)
    8000443e:	8baff0ef          	jal	800034f8 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004442:	874a                	mv	a4,s2
    80004444:	5094                	lw	a3,32(s1)
    80004446:	864e                	mv	a2,s3
    80004448:	4585                	li	a1,1
    8000444a:	6c88                	ld	a0,24(s1)
    8000444c:	c3cff0ef          	jal	80003888 <readi>
    80004450:	892a                	mv	s2,a0
    80004452:	00a05563          	blez	a0,8000445c <fileread+0x4e>
      f->off += r;
    80004456:	509c                	lw	a5,32(s1)
    80004458:	9fa9                	addw	a5,a5,a0
    8000445a:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000445c:	6c88                	ld	a0,24(s1)
    8000445e:	948ff0ef          	jal	800035a6 <iunlock>
    80004462:	64e2                	ld	s1,24(sp)
    80004464:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004466:	854a                	mv	a0,s2
    80004468:	70a2                	ld	ra,40(sp)
    8000446a:	7402                	ld	s0,32(sp)
    8000446c:	6942                	ld	s2,16(sp)
    8000446e:	6145                	addi	sp,sp,48
    80004470:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004472:	6908                	ld	a0,16(a0)
    80004474:	388000ef          	jal	800047fc <piperead>
    80004478:	892a                	mv	s2,a0
    8000447a:	64e2                	ld	s1,24(sp)
    8000447c:	69a2                	ld	s3,8(sp)
    8000447e:	b7e5                	j	80004466 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004480:	02451783          	lh	a5,36(a0)
    80004484:	03079693          	slli	a3,a5,0x30
    80004488:	92c1                	srli	a3,a3,0x30
    8000448a:	4725                	li	a4,9
    8000448c:	02d76863          	bltu	a4,a3,800044bc <fileread+0xae>
    80004490:	0792                	slli	a5,a5,0x4
    80004492:	0003e717          	auipc	a4,0x3e
    80004496:	14670713          	addi	a4,a4,326 # 800425d8 <devsw>
    8000449a:	97ba                	add	a5,a5,a4
    8000449c:	639c                	ld	a5,0(a5)
    8000449e:	c39d                	beqz	a5,800044c4 <fileread+0xb6>
    r = devsw[f->major].read(1, addr, n);
    800044a0:	4505                	li	a0,1
    800044a2:	9782                	jalr	a5
    800044a4:	892a                	mv	s2,a0
    800044a6:	64e2                	ld	s1,24(sp)
    800044a8:	69a2                	ld	s3,8(sp)
    800044aa:	bf75                	j	80004466 <fileread+0x58>
    panic("fileread");
    800044ac:	00003517          	auipc	a0,0x3
    800044b0:	22c50513          	addi	a0,a0,556 # 800076d8 <etext+0x6d8>
    800044b4:	b2cfc0ef          	jal	800007e0 <panic>
    return -1;
    800044b8:	597d                	li	s2,-1
    800044ba:	b775                	j	80004466 <fileread+0x58>
      return -1;
    800044bc:	597d                	li	s2,-1
    800044be:	64e2                	ld	s1,24(sp)
    800044c0:	69a2                	ld	s3,8(sp)
    800044c2:	b755                	j	80004466 <fileread+0x58>
    800044c4:	597d                	li	s2,-1
    800044c6:	64e2                	ld	s1,24(sp)
    800044c8:	69a2                	ld	s3,8(sp)
    800044ca:	bf71                	j	80004466 <fileread+0x58>

00000000800044cc <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    800044cc:	00954783          	lbu	a5,9(a0)
    800044d0:	10078b63          	beqz	a5,800045e6 <filewrite+0x11a>
{
    800044d4:	715d                	addi	sp,sp,-80
    800044d6:	e486                	sd	ra,72(sp)
    800044d8:	e0a2                	sd	s0,64(sp)
    800044da:	f84a                	sd	s2,48(sp)
    800044dc:	f052                	sd	s4,32(sp)
    800044de:	e85a                	sd	s6,16(sp)
    800044e0:	0880                	addi	s0,sp,80
    800044e2:	892a                	mv	s2,a0
    800044e4:	8b2e                	mv	s6,a1
    800044e6:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800044e8:	411c                	lw	a5,0(a0)
    800044ea:	4705                	li	a4,1
    800044ec:	02e78763          	beq	a5,a4,8000451a <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800044f0:	470d                	li	a4,3
    800044f2:	02e78863          	beq	a5,a4,80004522 <filewrite+0x56>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800044f6:	4709                	li	a4,2
    800044f8:	0ce79c63          	bne	a5,a4,800045d0 <filewrite+0x104>
    800044fc:	f44e                	sd	s3,40(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800044fe:	0ac05863          	blez	a2,800045ae <filewrite+0xe2>
    80004502:	fc26                	sd	s1,56(sp)
    80004504:	ec56                	sd	s5,24(sp)
    80004506:	e45e                	sd	s7,8(sp)
    80004508:	e062                	sd	s8,0(sp)
    int i = 0;
    8000450a:	4981                	li	s3,0
      int n1 = n - i;
      if(n1 > max)
    8000450c:	6b85                	lui	s7,0x1
    8000450e:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004512:	6c05                	lui	s8,0x1
    80004514:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    80004518:	a8b5                	j	80004594 <filewrite+0xc8>
    ret = pipewrite(f->pipe, addr, n);
    8000451a:	6908                	ld	a0,16(a0)
    8000451c:	1fc000ef          	jal	80004718 <pipewrite>
    80004520:	a04d                	j	800045c2 <filewrite+0xf6>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004522:	02451783          	lh	a5,36(a0)
    80004526:	03079693          	slli	a3,a5,0x30
    8000452a:	92c1                	srli	a3,a3,0x30
    8000452c:	4725                	li	a4,9
    8000452e:	0ad76e63          	bltu	a4,a3,800045ea <filewrite+0x11e>
    80004532:	0792                	slli	a5,a5,0x4
    80004534:	0003e717          	auipc	a4,0x3e
    80004538:	0a470713          	addi	a4,a4,164 # 800425d8 <devsw>
    8000453c:	97ba                	add	a5,a5,a4
    8000453e:	679c                	ld	a5,8(a5)
    80004540:	c7dd                	beqz	a5,800045ee <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    80004542:	4505                	li	a0,1
    80004544:	9782                	jalr	a5
    80004546:	a8b5                	j	800045c2 <filewrite+0xf6>
      if(n1 > max)
    80004548:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    8000454c:	997ff0ef          	jal	80003ee2 <begin_op>
      ilock(f->ip);
    80004550:	01893503          	ld	a0,24(s2)
    80004554:	fa5fe0ef          	jal	800034f8 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004558:	8756                	mv	a4,s5
    8000455a:	02092683          	lw	a3,32(s2)
    8000455e:	01698633          	add	a2,s3,s6
    80004562:	4585                	li	a1,1
    80004564:	01893503          	ld	a0,24(s2)
    80004568:	c1cff0ef          	jal	80003984 <writei>
    8000456c:	84aa                	mv	s1,a0
    8000456e:	00a05763          	blez	a0,8000457c <filewrite+0xb0>
        f->off += r;
    80004572:	02092783          	lw	a5,32(s2)
    80004576:	9fa9                	addw	a5,a5,a0
    80004578:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000457c:	01893503          	ld	a0,24(s2)
    80004580:	826ff0ef          	jal	800035a6 <iunlock>
      end_op();
    80004584:	9c9ff0ef          	jal	80003f4c <end_op>

      if(r != n1){
    80004588:	029a9563          	bne	s5,s1,800045b2 <filewrite+0xe6>
        // error from writei
        break;
      }
      i += r;
    8000458c:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80004590:	0149da63          	bge	s3,s4,800045a4 <filewrite+0xd8>
      int n1 = n - i;
    80004594:	413a04bb          	subw	s1,s4,s3
      if(n1 > max)
    80004598:	0004879b          	sext.w	a5,s1
    8000459c:	fafbd6e3          	bge	s7,a5,80004548 <filewrite+0x7c>
    800045a0:	84e2                	mv	s1,s8
    800045a2:	b75d                	j	80004548 <filewrite+0x7c>
    800045a4:	74e2                	ld	s1,56(sp)
    800045a6:	6ae2                	ld	s5,24(sp)
    800045a8:	6ba2                	ld	s7,8(sp)
    800045aa:	6c02                	ld	s8,0(sp)
    800045ac:	a039                	j	800045ba <filewrite+0xee>
    int i = 0;
    800045ae:	4981                	li	s3,0
    800045b0:	a029                	j	800045ba <filewrite+0xee>
    800045b2:	74e2                	ld	s1,56(sp)
    800045b4:	6ae2                	ld	s5,24(sp)
    800045b6:	6ba2                	ld	s7,8(sp)
    800045b8:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    800045ba:	033a1c63          	bne	s4,s3,800045f2 <filewrite+0x126>
    800045be:	8552                	mv	a0,s4
    800045c0:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800045c2:	60a6                	ld	ra,72(sp)
    800045c4:	6406                	ld	s0,64(sp)
    800045c6:	7942                	ld	s2,48(sp)
    800045c8:	7a02                	ld	s4,32(sp)
    800045ca:	6b42                	ld	s6,16(sp)
    800045cc:	6161                	addi	sp,sp,80
    800045ce:	8082                	ret
    800045d0:	fc26                	sd	s1,56(sp)
    800045d2:	f44e                	sd	s3,40(sp)
    800045d4:	ec56                	sd	s5,24(sp)
    800045d6:	e45e                	sd	s7,8(sp)
    800045d8:	e062                	sd	s8,0(sp)
    panic("filewrite");
    800045da:	00003517          	auipc	a0,0x3
    800045de:	10e50513          	addi	a0,a0,270 # 800076e8 <etext+0x6e8>
    800045e2:	9fefc0ef          	jal	800007e0 <panic>
    return -1;
    800045e6:	557d                	li	a0,-1
}
    800045e8:	8082                	ret
      return -1;
    800045ea:	557d                	li	a0,-1
    800045ec:	bfd9                	j	800045c2 <filewrite+0xf6>
    800045ee:	557d                	li	a0,-1
    800045f0:	bfc9                	j	800045c2 <filewrite+0xf6>
    ret = (i == n ? n : -1);
    800045f2:	557d                	li	a0,-1
    800045f4:	79a2                	ld	s3,40(sp)
    800045f6:	b7f1                	j	800045c2 <filewrite+0xf6>

00000000800045f8 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800045f8:	7179                	addi	sp,sp,-48
    800045fa:	f406                	sd	ra,40(sp)
    800045fc:	f022                	sd	s0,32(sp)
    800045fe:	ec26                	sd	s1,24(sp)
    80004600:	e052                	sd	s4,0(sp)
    80004602:	1800                	addi	s0,sp,48
    80004604:	84aa                	mv	s1,a0
    80004606:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004608:	0005b023          	sd	zero,0(a1)
    8000460c:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004610:	c3bff0ef          	jal	8000424a <filealloc>
    80004614:	e088                	sd	a0,0(s1)
    80004616:	c549                	beqz	a0,800046a0 <pipealloc+0xa8>
    80004618:	c33ff0ef          	jal	8000424a <filealloc>
    8000461c:	00aa3023          	sd	a0,0(s4)
    80004620:	cd25                	beqz	a0,80004698 <pipealloc+0xa0>
    80004622:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004624:	e26fc0ef          	jal	80000c4a <kalloc>
    80004628:	892a                	mv	s2,a0
    8000462a:	c12d                	beqz	a0,8000468c <pipealloc+0x94>
    8000462c:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    8000462e:	4985                	li	s3,1
    80004630:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004634:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004638:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000463c:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004640:	00003597          	auipc	a1,0x3
    80004644:	0b858593          	addi	a1,a1,184 # 800076f8 <etext+0x6f8>
    80004648:	f44fc0ef          	jal	80000d8c <initlock>
  (*f0)->type = FD_PIPE;
    8000464c:	609c                	ld	a5,0(s1)
    8000464e:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004652:	609c                	ld	a5,0(s1)
    80004654:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004658:	609c                	ld	a5,0(s1)
    8000465a:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000465e:	609c                	ld	a5,0(s1)
    80004660:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004664:	000a3783          	ld	a5,0(s4)
    80004668:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000466c:	000a3783          	ld	a5,0(s4)
    80004670:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004674:	000a3783          	ld	a5,0(s4)
    80004678:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000467c:	000a3783          	ld	a5,0(s4)
    80004680:	0127b823          	sd	s2,16(a5)
  return 0;
    80004684:	4501                	li	a0,0
    80004686:	6942                	ld	s2,16(sp)
    80004688:	69a2                	ld	s3,8(sp)
    8000468a:	a01d                	j	800046b0 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000468c:	6088                	ld	a0,0(s1)
    8000468e:	c119                	beqz	a0,80004694 <pipealloc+0x9c>
    80004690:	6942                	ld	s2,16(sp)
    80004692:	a029                	j	8000469c <pipealloc+0xa4>
    80004694:	6942                	ld	s2,16(sp)
    80004696:	a029                	j	800046a0 <pipealloc+0xa8>
    80004698:	6088                	ld	a0,0(s1)
    8000469a:	c10d                	beqz	a0,800046bc <pipealloc+0xc4>
    fileclose(*f0);
    8000469c:	c53ff0ef          	jal	800042ee <fileclose>
  if(*f1)
    800046a0:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800046a4:	557d                	li	a0,-1
  if(*f1)
    800046a6:	c789                	beqz	a5,800046b0 <pipealloc+0xb8>
    fileclose(*f1);
    800046a8:	853e                	mv	a0,a5
    800046aa:	c45ff0ef          	jal	800042ee <fileclose>
  return -1;
    800046ae:	557d                	li	a0,-1
}
    800046b0:	70a2                	ld	ra,40(sp)
    800046b2:	7402                	ld	s0,32(sp)
    800046b4:	64e2                	ld	s1,24(sp)
    800046b6:	6a02                	ld	s4,0(sp)
    800046b8:	6145                	addi	sp,sp,48
    800046ba:	8082                	ret
  return -1;
    800046bc:	557d                	li	a0,-1
    800046be:	bfcd                	j	800046b0 <pipealloc+0xb8>

00000000800046c0 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800046c0:	1101                	addi	sp,sp,-32
    800046c2:	ec06                	sd	ra,24(sp)
    800046c4:	e822                	sd	s0,16(sp)
    800046c6:	e426                	sd	s1,8(sp)
    800046c8:	e04a                	sd	s2,0(sp)
    800046ca:	1000                	addi	s0,sp,32
    800046cc:	84aa                	mv	s1,a0
    800046ce:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800046d0:	f3cfc0ef          	jal	80000e0c <acquire>
  if(writable){
    800046d4:	02090763          	beqz	s2,80004702 <pipeclose+0x42>
    pi->writeopen = 0;
    800046d8:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800046dc:	21848513          	addi	a0,s1,536
    800046e0:	b2dfd0ef          	jal	8000220c <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800046e4:	2204b783          	ld	a5,544(s1)
    800046e8:	e785                	bnez	a5,80004710 <pipeclose+0x50>
    release(&pi->lock);
    800046ea:	8526                	mv	a0,s1
    800046ec:	fb8fc0ef          	jal	80000ea4 <release>
    kfree((char*)pi);
    800046f0:	8526                	mv	a0,s1
    800046f2:	bd8fc0ef          	jal	80000aca <kfree>
  } else
    release(&pi->lock);
}
    800046f6:	60e2                	ld	ra,24(sp)
    800046f8:	6442                	ld	s0,16(sp)
    800046fa:	64a2                	ld	s1,8(sp)
    800046fc:	6902                	ld	s2,0(sp)
    800046fe:	6105                	addi	sp,sp,32
    80004700:	8082                	ret
    pi->readopen = 0;
    80004702:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004706:	21c48513          	addi	a0,s1,540
    8000470a:	b03fd0ef          	jal	8000220c <wakeup>
    8000470e:	bfd9                	j	800046e4 <pipeclose+0x24>
    release(&pi->lock);
    80004710:	8526                	mv	a0,s1
    80004712:	f92fc0ef          	jal	80000ea4 <release>
}
    80004716:	b7c5                	j	800046f6 <pipeclose+0x36>

0000000080004718 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004718:	711d                	addi	sp,sp,-96
    8000471a:	ec86                	sd	ra,88(sp)
    8000471c:	e8a2                	sd	s0,80(sp)
    8000471e:	e4a6                	sd	s1,72(sp)
    80004720:	e0ca                	sd	s2,64(sp)
    80004722:	fc4e                	sd	s3,56(sp)
    80004724:	f852                	sd	s4,48(sp)
    80004726:	f456                	sd	s5,40(sp)
    80004728:	1080                	addi	s0,sp,96
    8000472a:	84aa                	mv	s1,a0
    8000472c:	8aae                	mv	s5,a1
    8000472e:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004730:	c98fd0ef          	jal	80001bc8 <myproc>
    80004734:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004736:	8526                	mv	a0,s1
    80004738:	ed4fc0ef          	jal	80000e0c <acquire>
  while(i < n){
    8000473c:	0b405a63          	blez	s4,800047f0 <pipewrite+0xd8>
    80004740:	f05a                	sd	s6,32(sp)
    80004742:	ec5e                	sd	s7,24(sp)
    80004744:	e862                	sd	s8,16(sp)
  int i = 0;
    80004746:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004748:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000474a:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000474e:	21c48b93          	addi	s7,s1,540
    80004752:	a81d                	j	80004788 <pipewrite+0x70>
      release(&pi->lock);
    80004754:	8526                	mv	a0,s1
    80004756:	f4efc0ef          	jal	80000ea4 <release>
      return -1;
    8000475a:	597d                	li	s2,-1
    8000475c:	7b02                	ld	s6,32(sp)
    8000475e:	6be2                	ld	s7,24(sp)
    80004760:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004762:	854a                	mv	a0,s2
    80004764:	60e6                	ld	ra,88(sp)
    80004766:	6446                	ld	s0,80(sp)
    80004768:	64a6                	ld	s1,72(sp)
    8000476a:	6906                	ld	s2,64(sp)
    8000476c:	79e2                	ld	s3,56(sp)
    8000476e:	7a42                	ld	s4,48(sp)
    80004770:	7aa2                	ld	s5,40(sp)
    80004772:	6125                	addi	sp,sp,96
    80004774:	8082                	ret
      wakeup(&pi->nread);
    80004776:	8562                	mv	a0,s8
    80004778:	a95fd0ef          	jal	8000220c <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    8000477c:	85a6                	mv	a1,s1
    8000477e:	855e                	mv	a0,s7
    80004780:	a41fd0ef          	jal	800021c0 <sleep>
  while(i < n){
    80004784:	05495b63          	bge	s2,s4,800047da <pipewrite+0xc2>
    if(pi->readopen == 0 || killed(pr)){
    80004788:	2204a783          	lw	a5,544(s1)
    8000478c:	d7e1                	beqz	a5,80004754 <pipewrite+0x3c>
    8000478e:	854e                	mv	a0,s3
    80004790:	c69fd0ef          	jal	800023f8 <killed>
    80004794:	f161                	bnez	a0,80004754 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004796:	2184a783          	lw	a5,536(s1)
    8000479a:	21c4a703          	lw	a4,540(s1)
    8000479e:	2007879b          	addiw	a5,a5,512
    800047a2:	fcf70ae3          	beq	a4,a5,80004776 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800047a6:	4685                	li	a3,1
    800047a8:	01590633          	add	a2,s2,s5
    800047ac:	faf40593          	addi	a1,s0,-81
    800047b0:	0509b503          	ld	a0,80(s3)
    800047b4:	9ecfd0ef          	jal	800019a0 <copyin>
    800047b8:	03650e63          	beq	a0,s6,800047f4 <pipewrite+0xdc>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800047bc:	21c4a783          	lw	a5,540(s1)
    800047c0:	0017871b          	addiw	a4,a5,1
    800047c4:	20e4ae23          	sw	a4,540(s1)
    800047c8:	1ff7f793          	andi	a5,a5,511
    800047cc:	97a6                	add	a5,a5,s1
    800047ce:	faf44703          	lbu	a4,-81(s0)
    800047d2:	00e78c23          	sb	a4,24(a5)
      i++;
    800047d6:	2905                	addiw	s2,s2,1
    800047d8:	b775                	j	80004784 <pipewrite+0x6c>
    800047da:	7b02                	ld	s6,32(sp)
    800047dc:	6be2                	ld	s7,24(sp)
    800047de:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    800047e0:	21848513          	addi	a0,s1,536
    800047e4:	a29fd0ef          	jal	8000220c <wakeup>
  release(&pi->lock);
    800047e8:	8526                	mv	a0,s1
    800047ea:	ebafc0ef          	jal	80000ea4 <release>
  return i;
    800047ee:	bf95                	j	80004762 <pipewrite+0x4a>
  int i = 0;
    800047f0:	4901                	li	s2,0
    800047f2:	b7fd                	j	800047e0 <pipewrite+0xc8>
    800047f4:	7b02                	ld	s6,32(sp)
    800047f6:	6be2                	ld	s7,24(sp)
    800047f8:	6c42                	ld	s8,16(sp)
    800047fa:	b7dd                	j	800047e0 <pipewrite+0xc8>

00000000800047fc <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800047fc:	715d                	addi	sp,sp,-80
    800047fe:	e486                	sd	ra,72(sp)
    80004800:	e0a2                	sd	s0,64(sp)
    80004802:	fc26                	sd	s1,56(sp)
    80004804:	f84a                	sd	s2,48(sp)
    80004806:	f44e                	sd	s3,40(sp)
    80004808:	f052                	sd	s4,32(sp)
    8000480a:	ec56                	sd	s5,24(sp)
    8000480c:	0880                	addi	s0,sp,80
    8000480e:	84aa                	mv	s1,a0
    80004810:	892e                	mv	s2,a1
    80004812:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004814:	bb4fd0ef          	jal	80001bc8 <myproc>
    80004818:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    8000481a:	8526                	mv	a0,s1
    8000481c:	df0fc0ef          	jal	80000e0c <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004820:	2184a703          	lw	a4,536(s1)
    80004824:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004828:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000482c:	02f71563          	bne	a4,a5,80004856 <piperead+0x5a>
    80004830:	2244a783          	lw	a5,548(s1)
    80004834:	cb85                	beqz	a5,80004864 <piperead+0x68>
    if(killed(pr)){
    80004836:	8552                	mv	a0,s4
    80004838:	bc1fd0ef          	jal	800023f8 <killed>
    8000483c:	ed19                	bnez	a0,8000485a <piperead+0x5e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000483e:	85a6                	mv	a1,s1
    80004840:	854e                	mv	a0,s3
    80004842:	97ffd0ef          	jal	800021c0 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004846:	2184a703          	lw	a4,536(s1)
    8000484a:	21c4a783          	lw	a5,540(s1)
    8000484e:	fef701e3          	beq	a4,a5,80004830 <piperead+0x34>
    80004852:	e85a                	sd	s6,16(sp)
    80004854:	a809                	j	80004866 <piperead+0x6a>
    80004856:	e85a                	sd	s6,16(sp)
    80004858:	a039                	j	80004866 <piperead+0x6a>
      release(&pi->lock);
    8000485a:	8526                	mv	a0,s1
    8000485c:	e48fc0ef          	jal	80000ea4 <release>
      return -1;
    80004860:	59fd                	li	s3,-1
    80004862:	a8b1                	j	800048be <piperead+0xc2>
    80004864:	e85a                	sd	s6,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004866:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004868:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000486a:	05505263          	blez	s5,800048ae <piperead+0xb2>
    if(pi->nread == pi->nwrite)
    8000486e:	2184a783          	lw	a5,536(s1)
    80004872:	21c4a703          	lw	a4,540(s1)
    80004876:	02f70c63          	beq	a4,a5,800048ae <piperead+0xb2>
    ch = pi->data[pi->nread++ % PIPESIZE];
    8000487a:	0017871b          	addiw	a4,a5,1
    8000487e:	20e4ac23          	sw	a4,536(s1)
    80004882:	1ff7f793          	andi	a5,a5,511
    80004886:	97a6                	add	a5,a5,s1
    80004888:	0187c783          	lbu	a5,24(a5)
    8000488c:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004890:	4685                	li	a3,1
    80004892:	fbf40613          	addi	a2,s0,-65
    80004896:	85ca                	mv	a1,s2
    80004898:	050a3503          	ld	a0,80(s4)
    8000489c:	ffdfc0ef          	jal	80001898 <copyout>
    800048a0:	01650763          	beq	a0,s6,800048ae <piperead+0xb2>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800048a4:	2985                	addiw	s3,s3,1
    800048a6:	0905                	addi	s2,s2,1
    800048a8:	fd3a93e3          	bne	s5,s3,8000486e <piperead+0x72>
    800048ac:	89d6                	mv	s3,s5
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    800048ae:	21c48513          	addi	a0,s1,540
    800048b2:	95bfd0ef          	jal	8000220c <wakeup>
  release(&pi->lock);
    800048b6:	8526                	mv	a0,s1
    800048b8:	decfc0ef          	jal	80000ea4 <release>
    800048bc:	6b42                	ld	s6,16(sp)
  return i;
}
    800048be:	854e                	mv	a0,s3
    800048c0:	60a6                	ld	ra,72(sp)
    800048c2:	6406                	ld	s0,64(sp)
    800048c4:	74e2                	ld	s1,56(sp)
    800048c6:	7942                	ld	s2,48(sp)
    800048c8:	79a2                	ld	s3,40(sp)
    800048ca:	7a02                	ld	s4,32(sp)
    800048cc:	6ae2                	ld	s5,24(sp)
    800048ce:	6161                	addi	sp,sp,80
    800048d0:	8082                	ret

00000000800048d2 <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    800048d2:	1141                	addi	sp,sp,-16
    800048d4:	e422                	sd	s0,8(sp)
    800048d6:	0800                	addi	s0,sp,16
    800048d8:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800048da:	8905                	andi	a0,a0,1
    800048dc:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    800048de:	8b89                	andi	a5,a5,2
    800048e0:	c399                	beqz	a5,800048e6 <flags2perm+0x14>
      perm |= PTE_W;
    800048e2:	00456513          	ori	a0,a0,4
    return perm;
}
    800048e6:	6422                	ld	s0,8(sp)
    800048e8:	0141                	addi	sp,sp,16
    800048ea:	8082                	ret

00000000800048ec <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800048ec:	df010113          	addi	sp,sp,-528
    800048f0:	20113423          	sd	ra,520(sp)
    800048f4:	20813023          	sd	s0,512(sp)
    800048f8:	ffa6                	sd	s1,504(sp)
    800048fa:	fbca                	sd	s2,496(sp)
    800048fc:	0c00                	addi	s0,sp,528
    800048fe:	892a                	mv	s2,a0
    80004900:	dea43c23          	sd	a0,-520(s0)
    80004904:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004908:	ac0fd0ef          	jal	80001bc8 <myproc>
    8000490c:	84aa                	mv	s1,a0

  begin_op();
    8000490e:	dd4ff0ef          	jal	80003ee2 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    80004912:	854a                	mv	a0,s2
    80004914:	bfaff0ef          	jal	80003d0e <namei>
    80004918:	c931                	beqz	a0,8000496c <kexec+0x80>
    8000491a:	f3d2                	sd	s4,480(sp)
    8000491c:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000491e:	bdbfe0ef          	jal	800034f8 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004922:	04000713          	li	a4,64
    80004926:	4681                	li	a3,0
    80004928:	e5040613          	addi	a2,s0,-432
    8000492c:	4581                	li	a1,0
    8000492e:	8552                	mv	a0,s4
    80004930:	f59fe0ef          	jal	80003888 <readi>
    80004934:	04000793          	li	a5,64
    80004938:	00f51a63          	bne	a0,a5,8000494c <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    8000493c:	e5042703          	lw	a4,-432(s0)
    80004940:	464c47b7          	lui	a5,0x464c4
    80004944:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004948:	02f70663          	beq	a4,a5,80004974 <kexec+0x88>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    8000494c:	8552                	mv	a0,s4
    8000494e:	db5fe0ef          	jal	80003702 <iunlockput>
    end_op();
    80004952:	dfaff0ef          	jal	80003f4c <end_op>
  }
  return -1;
    80004956:	557d                	li	a0,-1
    80004958:	7a1e                	ld	s4,480(sp)
}
    8000495a:	20813083          	ld	ra,520(sp)
    8000495e:	20013403          	ld	s0,512(sp)
    80004962:	74fe                	ld	s1,504(sp)
    80004964:	795e                	ld	s2,496(sp)
    80004966:	21010113          	addi	sp,sp,528
    8000496a:	8082                	ret
    end_op();
    8000496c:	de0ff0ef          	jal	80003f4c <end_op>
    return -1;
    80004970:	557d                	li	a0,-1
    80004972:	b7e5                	j	8000495a <kexec+0x6e>
    80004974:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004976:	8526                	mv	a0,s1
    80004978:	b56fd0ef          	jal	80001cce <proc_pagetable>
    8000497c:	8b2a                	mv	s6,a0
    8000497e:	2c050b63          	beqz	a0,80004c54 <kexec+0x368>
    80004982:	f7ce                	sd	s3,488(sp)
    80004984:	efd6                	sd	s5,472(sp)
    80004986:	e7de                	sd	s7,456(sp)
    80004988:	e3e2                	sd	s8,448(sp)
    8000498a:	ff66                	sd	s9,440(sp)
    8000498c:	fb6a                	sd	s10,432(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000498e:	e7042d03          	lw	s10,-400(s0)
    80004992:	e8845783          	lhu	a5,-376(s0)
    80004996:	12078963          	beqz	a5,80004ac8 <kexec+0x1dc>
    8000499a:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000499c:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000499e:	4d81                	li	s11,0
    if(ph.vaddr % PGSIZE != 0)
    800049a0:	6c85                	lui	s9,0x1
    800049a2:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800049a6:	def43823          	sd	a5,-528(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800049aa:	6a85                	lui	s5,0x1
    800049ac:	a085                	j	80004a0c <kexec+0x120>
      panic("loadseg: address should exist");
    800049ae:	00003517          	auipc	a0,0x3
    800049b2:	d5250513          	addi	a0,a0,-686 # 80007700 <etext+0x700>
    800049b6:	e2bfb0ef          	jal	800007e0 <panic>
    if(sz - i < PGSIZE)
    800049ba:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800049bc:	8726                	mv	a4,s1
    800049be:	012c06bb          	addw	a3,s8,s2
    800049c2:	4581                	li	a1,0
    800049c4:	8552                	mv	a0,s4
    800049c6:	ec3fe0ef          	jal	80003888 <readi>
    800049ca:	2501                	sext.w	a0,a0
    800049cc:	24a49a63          	bne	s1,a0,80004c20 <kexec+0x334>
  for(i = 0; i < sz; i += PGSIZE){
    800049d0:	012a893b          	addw	s2,s5,s2
    800049d4:	03397363          	bgeu	s2,s3,800049fa <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    800049d8:	02091593          	slli	a1,s2,0x20
    800049dc:	9181                	srli	a1,a1,0x20
    800049de:	95de                	add	a1,a1,s7
    800049e0:	855a                	mv	a0,s6
    800049e2:	811fc0ef          	jal	800011f2 <walkaddr>
    800049e6:	862a                	mv	a2,a0
    if(pa == 0)
    800049e8:	d179                	beqz	a0,800049ae <kexec+0xc2>
    if(sz - i < PGSIZE)
    800049ea:	412984bb          	subw	s1,s3,s2
    800049ee:	0004879b          	sext.w	a5,s1
    800049f2:	fcfcf4e3          	bgeu	s9,a5,800049ba <kexec+0xce>
    800049f6:	84d6                	mv	s1,s5
    800049f8:	b7c9                	j	800049ba <kexec+0xce>
    sz = sz1;
    800049fa:	e0843903          	ld	s2,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800049fe:	2d85                	addiw	s11,s11,1 # 1001 <_entry-0x7fffefff>
    80004a00:	038d0d1b          	addiw	s10,s10,56
    80004a04:	e8845783          	lhu	a5,-376(s0)
    80004a08:	08fdd063          	bge	s11,a5,80004a88 <kexec+0x19c>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004a0c:	2d01                	sext.w	s10,s10
    80004a0e:	03800713          	li	a4,56
    80004a12:	86ea                	mv	a3,s10
    80004a14:	e1840613          	addi	a2,s0,-488
    80004a18:	4581                	li	a1,0
    80004a1a:	8552                	mv	a0,s4
    80004a1c:	e6dfe0ef          	jal	80003888 <readi>
    80004a20:	03800793          	li	a5,56
    80004a24:	1cf51663          	bne	a0,a5,80004bf0 <kexec+0x304>
    if(ph.type != ELF_PROG_LOAD)
    80004a28:	e1842783          	lw	a5,-488(s0)
    80004a2c:	4705                	li	a4,1
    80004a2e:	fce798e3          	bne	a5,a4,800049fe <kexec+0x112>
    if(ph.memsz < ph.filesz)
    80004a32:	e4043483          	ld	s1,-448(s0)
    80004a36:	e3843783          	ld	a5,-456(s0)
    80004a3a:	1af4ef63          	bltu	s1,a5,80004bf8 <kexec+0x30c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004a3e:	e2843783          	ld	a5,-472(s0)
    80004a42:	94be                	add	s1,s1,a5
    80004a44:	1af4ee63          	bltu	s1,a5,80004c00 <kexec+0x314>
    if(ph.vaddr % PGSIZE != 0)
    80004a48:	df043703          	ld	a4,-528(s0)
    80004a4c:	8ff9                	and	a5,a5,a4
    80004a4e:	1a079d63          	bnez	a5,80004c08 <kexec+0x31c>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004a52:	e1c42503          	lw	a0,-484(s0)
    80004a56:	e7dff0ef          	jal	800048d2 <flags2perm>
    80004a5a:	86aa                	mv	a3,a0
    80004a5c:	8626                	mv	a2,s1
    80004a5e:	85ca                	mv	a1,s2
    80004a60:	855a                	mv	a0,s6
    80004a62:	a69fc0ef          	jal	800014ca <uvmalloc>
    80004a66:	e0a43423          	sd	a0,-504(s0)
    80004a6a:	1a050363          	beqz	a0,80004c10 <kexec+0x324>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a6e:	e2843b83          	ld	s7,-472(s0)
    80004a72:	e2042c03          	lw	s8,-480(s0)
    80004a76:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004a7a:	00098463          	beqz	s3,80004a82 <kexec+0x196>
    80004a7e:	4901                	li	s2,0
    80004a80:	bfa1                	j	800049d8 <kexec+0xec>
    sz = sz1;
    80004a82:	e0843903          	ld	s2,-504(s0)
    80004a86:	bfa5                	j	800049fe <kexec+0x112>
    80004a88:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004a8a:	8552                	mv	a0,s4
    80004a8c:	c77fe0ef          	jal	80003702 <iunlockput>
  end_op();
    80004a90:	cbcff0ef          	jal	80003f4c <end_op>
  p = myproc();
    80004a94:	934fd0ef          	jal	80001bc8 <myproc>
    80004a98:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004a9a:	04853c83          	ld	s9,72(a0)
  sz = PGROUNDUP(sz);
    80004a9e:	6985                	lui	s3,0x1
    80004aa0:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004aa2:	99ca                	add	s3,s3,s2
    80004aa4:	77fd                	lui	a5,0xfffff
    80004aa6:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004aaa:	4691                	li	a3,4
    80004aac:	6609                	lui	a2,0x2
    80004aae:	964e                	add	a2,a2,s3
    80004ab0:	85ce                	mv	a1,s3
    80004ab2:	855a                	mv	a0,s6
    80004ab4:	a17fc0ef          	jal	800014ca <uvmalloc>
    80004ab8:	892a                	mv	s2,a0
    80004aba:	e0a43423          	sd	a0,-504(s0)
    80004abe:	e519                	bnez	a0,80004acc <kexec+0x1e0>
  if(pagetable)
    80004ac0:	e1343423          	sd	s3,-504(s0)
    80004ac4:	4a01                	li	s4,0
    80004ac6:	aab1                	j	80004c22 <kexec+0x336>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004ac8:	4901                	li	s2,0
    80004aca:	b7c1                	j	80004a8a <kexec+0x19e>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004acc:	75f9                	lui	a1,0xffffe
    80004ace:	95aa                	add	a1,a1,a0
    80004ad0:	855a                	mv	a0,s6
    80004ad2:	bc5fc0ef          	jal	80001696 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004ad6:	7bfd                	lui	s7,0xfffff
    80004ad8:	9bca                	add	s7,s7,s2
  for(argc = 0; argv[argc]; argc++) {
    80004ada:	e0043783          	ld	a5,-512(s0)
    80004ade:	6388                	ld	a0,0(a5)
    80004ae0:	cd39                	beqz	a0,80004b3e <kexec+0x252>
    80004ae2:	e9040993          	addi	s3,s0,-368
    80004ae6:	f9040c13          	addi	s8,s0,-112
    80004aea:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004aec:	d64fc0ef          	jal	80001050 <strlen>
    80004af0:	0015079b          	addiw	a5,a0,1
    80004af4:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004af8:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004afc:	11796e63          	bltu	s2,s7,80004c18 <kexec+0x32c>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004b00:	e0043d03          	ld	s10,-512(s0)
    80004b04:	000d3a03          	ld	s4,0(s10)
    80004b08:	8552                	mv	a0,s4
    80004b0a:	d46fc0ef          	jal	80001050 <strlen>
    80004b0e:	0015069b          	addiw	a3,a0,1
    80004b12:	8652                	mv	a2,s4
    80004b14:	85ca                	mv	a1,s2
    80004b16:	855a                	mv	a0,s6
    80004b18:	d81fc0ef          	jal	80001898 <copyout>
    80004b1c:	10054063          	bltz	a0,80004c1c <kexec+0x330>
    ustack[argc] = sp;
    80004b20:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004b24:	0485                	addi	s1,s1,1
    80004b26:	008d0793          	addi	a5,s10,8
    80004b2a:	e0f43023          	sd	a5,-512(s0)
    80004b2e:	008d3503          	ld	a0,8(s10)
    80004b32:	c909                	beqz	a0,80004b44 <kexec+0x258>
    if(argc >= MAXARG)
    80004b34:	09a1                	addi	s3,s3,8
    80004b36:	fb899be3          	bne	s3,s8,80004aec <kexec+0x200>
  ip = 0;
    80004b3a:	4a01                	li	s4,0
    80004b3c:	a0dd                	j	80004c22 <kexec+0x336>
  sp = sz;
    80004b3e:	e0843903          	ld	s2,-504(s0)
  for(argc = 0; argv[argc]; argc++) {
    80004b42:	4481                	li	s1,0
  ustack[argc] = 0;
    80004b44:	00349793          	slli	a5,s1,0x3
    80004b48:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffbb820>
    80004b4c:	97a2                	add	a5,a5,s0
    80004b4e:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004b52:	00148693          	addi	a3,s1,1
    80004b56:	068e                	slli	a3,a3,0x3
    80004b58:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004b5c:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004b60:	e0843983          	ld	s3,-504(s0)
  if(sp < stackbase)
    80004b64:	f5796ee3          	bltu	s2,s7,80004ac0 <kexec+0x1d4>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004b68:	e9040613          	addi	a2,s0,-368
    80004b6c:	85ca                	mv	a1,s2
    80004b6e:	855a                	mv	a0,s6
    80004b70:	d29fc0ef          	jal	80001898 <copyout>
    80004b74:	0e054263          	bltz	a0,80004c58 <kexec+0x36c>
  p->trapframe->a1 = sp;
    80004b78:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004b7c:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004b80:	df843783          	ld	a5,-520(s0)
    80004b84:	0007c703          	lbu	a4,0(a5)
    80004b88:	cf11                	beqz	a4,80004ba4 <kexec+0x2b8>
    80004b8a:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004b8c:	02f00693          	li	a3,47
    80004b90:	a039                	j	80004b9e <kexec+0x2b2>
      last = s+1;
    80004b92:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    80004b96:	0785                	addi	a5,a5,1
    80004b98:	fff7c703          	lbu	a4,-1(a5)
    80004b9c:	c701                	beqz	a4,80004ba4 <kexec+0x2b8>
    if(*s == '/')
    80004b9e:	fed71ce3          	bne	a4,a3,80004b96 <kexec+0x2aa>
    80004ba2:	bfc5                	j	80004b92 <kexec+0x2a6>
  safestrcpy(p->name, last, sizeof(p->name));
    80004ba4:	4641                	li	a2,16
    80004ba6:	df843583          	ld	a1,-520(s0)
    80004baa:	158a8513          	addi	a0,s5,344
    80004bae:	c70fc0ef          	jal	8000101e <safestrcpy>
  oldpagetable = p->pagetable;
    80004bb2:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80004bb6:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80004bba:	e0843783          	ld	a5,-504(s0)
    80004bbe:	04fab423          	sd	a5,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004bc2:	058ab783          	ld	a5,88(s5)
    80004bc6:	e6843703          	ld	a4,-408(s0)
    80004bca:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004bcc:	058ab783          	ld	a5,88(s5)
    80004bd0:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004bd4:	85e6                	mv	a1,s9
    80004bd6:	97cfd0ef          	jal	80001d52 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004bda:	0004851b          	sext.w	a0,s1
    80004bde:	79be                	ld	s3,488(sp)
    80004be0:	7a1e                	ld	s4,480(sp)
    80004be2:	6afe                	ld	s5,472(sp)
    80004be4:	6b5e                	ld	s6,464(sp)
    80004be6:	6bbe                	ld	s7,456(sp)
    80004be8:	6c1e                	ld	s8,448(sp)
    80004bea:	7cfa                	ld	s9,440(sp)
    80004bec:	7d5a                	ld	s10,432(sp)
    80004bee:	b3b5                	j	8000495a <kexec+0x6e>
    80004bf0:	e1243423          	sd	s2,-504(s0)
    80004bf4:	7dba                	ld	s11,424(sp)
    80004bf6:	a035                	j	80004c22 <kexec+0x336>
    80004bf8:	e1243423          	sd	s2,-504(s0)
    80004bfc:	7dba                	ld	s11,424(sp)
    80004bfe:	a015                	j	80004c22 <kexec+0x336>
    80004c00:	e1243423          	sd	s2,-504(s0)
    80004c04:	7dba                	ld	s11,424(sp)
    80004c06:	a831                	j	80004c22 <kexec+0x336>
    80004c08:	e1243423          	sd	s2,-504(s0)
    80004c0c:	7dba                	ld	s11,424(sp)
    80004c0e:	a811                	j	80004c22 <kexec+0x336>
    80004c10:	e1243423          	sd	s2,-504(s0)
    80004c14:	7dba                	ld	s11,424(sp)
    80004c16:	a031                	j	80004c22 <kexec+0x336>
  ip = 0;
    80004c18:	4a01                	li	s4,0
    80004c1a:	a021                	j	80004c22 <kexec+0x336>
    80004c1c:	4a01                	li	s4,0
  if(pagetable)
    80004c1e:	a011                	j	80004c22 <kexec+0x336>
    80004c20:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    80004c22:	e0843583          	ld	a1,-504(s0)
    80004c26:	855a                	mv	a0,s6
    80004c28:	92afd0ef          	jal	80001d52 <proc_freepagetable>
  return -1;
    80004c2c:	557d                	li	a0,-1
  if(ip){
    80004c2e:	000a1b63          	bnez	s4,80004c44 <kexec+0x358>
    80004c32:	79be                	ld	s3,488(sp)
    80004c34:	7a1e                	ld	s4,480(sp)
    80004c36:	6afe                	ld	s5,472(sp)
    80004c38:	6b5e                	ld	s6,464(sp)
    80004c3a:	6bbe                	ld	s7,456(sp)
    80004c3c:	6c1e                	ld	s8,448(sp)
    80004c3e:	7cfa                	ld	s9,440(sp)
    80004c40:	7d5a                	ld	s10,432(sp)
    80004c42:	bb21                	j	8000495a <kexec+0x6e>
    80004c44:	79be                	ld	s3,488(sp)
    80004c46:	6afe                	ld	s5,472(sp)
    80004c48:	6b5e                	ld	s6,464(sp)
    80004c4a:	6bbe                	ld	s7,456(sp)
    80004c4c:	6c1e                	ld	s8,448(sp)
    80004c4e:	7cfa                	ld	s9,440(sp)
    80004c50:	7d5a                	ld	s10,432(sp)
    80004c52:	b9ed                	j	8000494c <kexec+0x60>
    80004c54:	6b5e                	ld	s6,464(sp)
    80004c56:	b9dd                	j	8000494c <kexec+0x60>
  sz = sz1;
    80004c58:	e0843983          	ld	s3,-504(s0)
    80004c5c:	b595                	j	80004ac0 <kexec+0x1d4>

0000000080004c5e <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004c5e:	7179                	addi	sp,sp,-48
    80004c60:	f406                	sd	ra,40(sp)
    80004c62:	f022                	sd	s0,32(sp)
    80004c64:	ec26                	sd	s1,24(sp)
    80004c66:	e84a                	sd	s2,16(sp)
    80004c68:	1800                	addi	s0,sp,48
    80004c6a:	892e                	mv	s2,a1
    80004c6c:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004c6e:	fdc40593          	addi	a1,s0,-36
    80004c72:	e53fd0ef          	jal	80002ac4 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004c76:	fdc42703          	lw	a4,-36(s0)
    80004c7a:	47bd                	li	a5,15
    80004c7c:	02e7e963          	bltu	a5,a4,80004cae <argfd+0x50>
    80004c80:	f49fc0ef          	jal	80001bc8 <myproc>
    80004c84:	fdc42703          	lw	a4,-36(s0)
    80004c88:	01a70793          	addi	a5,a4,26
    80004c8c:	078e                	slli	a5,a5,0x3
    80004c8e:	953e                	add	a0,a0,a5
    80004c90:	611c                	ld	a5,0(a0)
    80004c92:	c385                	beqz	a5,80004cb2 <argfd+0x54>
    return -1;
  if(pfd)
    80004c94:	00090463          	beqz	s2,80004c9c <argfd+0x3e>
    *pfd = fd;
    80004c98:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004c9c:	4501                	li	a0,0
  if(pf)
    80004c9e:	c091                	beqz	s1,80004ca2 <argfd+0x44>
    *pf = f;
    80004ca0:	e09c                	sd	a5,0(s1)
}
    80004ca2:	70a2                	ld	ra,40(sp)
    80004ca4:	7402                	ld	s0,32(sp)
    80004ca6:	64e2                	ld	s1,24(sp)
    80004ca8:	6942                	ld	s2,16(sp)
    80004caa:	6145                	addi	sp,sp,48
    80004cac:	8082                	ret
    return -1;
    80004cae:	557d                	li	a0,-1
    80004cb0:	bfcd                	j	80004ca2 <argfd+0x44>
    80004cb2:	557d                	li	a0,-1
    80004cb4:	b7fd                	j	80004ca2 <argfd+0x44>

0000000080004cb6 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004cb6:	1101                	addi	sp,sp,-32
    80004cb8:	ec06                	sd	ra,24(sp)
    80004cba:	e822                	sd	s0,16(sp)
    80004cbc:	e426                	sd	s1,8(sp)
    80004cbe:	1000                	addi	s0,sp,32
    80004cc0:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004cc2:	f07fc0ef          	jal	80001bc8 <myproc>
    80004cc6:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004cc8:	0d050793          	addi	a5,a0,208
    80004ccc:	4501                	li	a0,0
    80004cce:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004cd0:	6398                	ld	a4,0(a5)
    80004cd2:	cb19                	beqz	a4,80004ce8 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004cd4:	2505                	addiw	a0,a0,1
    80004cd6:	07a1                	addi	a5,a5,8
    80004cd8:	fed51ce3          	bne	a0,a3,80004cd0 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004cdc:	557d                	li	a0,-1
}
    80004cde:	60e2                	ld	ra,24(sp)
    80004ce0:	6442                	ld	s0,16(sp)
    80004ce2:	64a2                	ld	s1,8(sp)
    80004ce4:	6105                	addi	sp,sp,32
    80004ce6:	8082                	ret
      p->ofile[fd] = f;
    80004ce8:	01a50793          	addi	a5,a0,26
    80004cec:	078e                	slli	a5,a5,0x3
    80004cee:	963e                	add	a2,a2,a5
    80004cf0:	e204                	sd	s1,0(a2)
      return fd;
    80004cf2:	b7f5                	j	80004cde <fdalloc+0x28>

0000000080004cf4 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004cf4:	715d                	addi	sp,sp,-80
    80004cf6:	e486                	sd	ra,72(sp)
    80004cf8:	e0a2                	sd	s0,64(sp)
    80004cfa:	fc26                	sd	s1,56(sp)
    80004cfc:	f84a                	sd	s2,48(sp)
    80004cfe:	f44e                	sd	s3,40(sp)
    80004d00:	ec56                	sd	s5,24(sp)
    80004d02:	e85a                	sd	s6,16(sp)
    80004d04:	0880                	addi	s0,sp,80
    80004d06:	8b2e                	mv	s6,a1
    80004d08:	89b2                	mv	s3,a2
    80004d0a:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004d0c:	fb040593          	addi	a1,s0,-80
    80004d10:	818ff0ef          	jal	80003d28 <nameiparent>
    80004d14:	84aa                	mv	s1,a0
    80004d16:	10050a63          	beqz	a0,80004e2a <create+0x136>
    return 0;

  ilock(dp);
    80004d1a:	fdefe0ef          	jal	800034f8 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004d1e:	4601                	li	a2,0
    80004d20:	fb040593          	addi	a1,s0,-80
    80004d24:	8526                	mv	a0,s1
    80004d26:	d83fe0ef          	jal	80003aa8 <dirlookup>
    80004d2a:	8aaa                	mv	s5,a0
    80004d2c:	c129                	beqz	a0,80004d6e <create+0x7a>
    iunlockput(dp);
    80004d2e:	8526                	mv	a0,s1
    80004d30:	9d3fe0ef          	jal	80003702 <iunlockput>
    ilock(ip);
    80004d34:	8556                	mv	a0,s5
    80004d36:	fc2fe0ef          	jal	800034f8 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004d3a:	4789                	li	a5,2
    80004d3c:	02fb1463          	bne	s6,a5,80004d64 <create+0x70>
    80004d40:	044ad783          	lhu	a5,68(s5)
    80004d44:	37f9                	addiw	a5,a5,-2
    80004d46:	17c2                	slli	a5,a5,0x30
    80004d48:	93c1                	srli	a5,a5,0x30
    80004d4a:	4705                	li	a4,1
    80004d4c:	00f76c63          	bltu	a4,a5,80004d64 <create+0x70>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004d50:	8556                	mv	a0,s5
    80004d52:	60a6                	ld	ra,72(sp)
    80004d54:	6406                	ld	s0,64(sp)
    80004d56:	74e2                	ld	s1,56(sp)
    80004d58:	7942                	ld	s2,48(sp)
    80004d5a:	79a2                	ld	s3,40(sp)
    80004d5c:	6ae2                	ld	s5,24(sp)
    80004d5e:	6b42                	ld	s6,16(sp)
    80004d60:	6161                	addi	sp,sp,80
    80004d62:	8082                	ret
    iunlockput(ip);
    80004d64:	8556                	mv	a0,s5
    80004d66:	99dfe0ef          	jal	80003702 <iunlockput>
    return 0;
    80004d6a:	4a81                	li	s5,0
    80004d6c:	b7d5                	j	80004d50 <create+0x5c>
    80004d6e:	f052                	sd	s4,32(sp)
  if((ip = ialloc(dp->dev, type)) == 0){
    80004d70:	85da                	mv	a1,s6
    80004d72:	4088                	lw	a0,0(s1)
    80004d74:	e14fe0ef          	jal	80003388 <ialloc>
    80004d78:	8a2a                	mv	s4,a0
    80004d7a:	cd15                	beqz	a0,80004db6 <create+0xc2>
  ilock(ip);
    80004d7c:	f7cfe0ef          	jal	800034f8 <ilock>
  ip->major = major;
    80004d80:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004d84:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004d88:	4905                	li	s2,1
    80004d8a:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004d8e:	8552                	mv	a0,s4
    80004d90:	eb4fe0ef          	jal	80003444 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004d94:	032b0763          	beq	s6,s2,80004dc2 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004d98:	004a2603          	lw	a2,4(s4)
    80004d9c:	fb040593          	addi	a1,s0,-80
    80004da0:	8526                	mv	a0,s1
    80004da2:	ed3fe0ef          	jal	80003c74 <dirlink>
    80004da6:	06054563          	bltz	a0,80004e10 <create+0x11c>
  iunlockput(dp);
    80004daa:	8526                	mv	a0,s1
    80004dac:	957fe0ef          	jal	80003702 <iunlockput>
  return ip;
    80004db0:	8ad2                	mv	s5,s4
    80004db2:	7a02                	ld	s4,32(sp)
    80004db4:	bf71                	j	80004d50 <create+0x5c>
    iunlockput(dp);
    80004db6:	8526                	mv	a0,s1
    80004db8:	94bfe0ef          	jal	80003702 <iunlockput>
    return 0;
    80004dbc:	8ad2                	mv	s5,s4
    80004dbe:	7a02                	ld	s4,32(sp)
    80004dc0:	bf41                	j	80004d50 <create+0x5c>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004dc2:	004a2603          	lw	a2,4(s4)
    80004dc6:	00003597          	auipc	a1,0x3
    80004dca:	95a58593          	addi	a1,a1,-1702 # 80007720 <etext+0x720>
    80004dce:	8552                	mv	a0,s4
    80004dd0:	ea5fe0ef          	jal	80003c74 <dirlink>
    80004dd4:	02054e63          	bltz	a0,80004e10 <create+0x11c>
    80004dd8:	40d0                	lw	a2,4(s1)
    80004dda:	00003597          	auipc	a1,0x3
    80004dde:	94e58593          	addi	a1,a1,-1714 # 80007728 <etext+0x728>
    80004de2:	8552                	mv	a0,s4
    80004de4:	e91fe0ef          	jal	80003c74 <dirlink>
    80004de8:	02054463          	bltz	a0,80004e10 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004dec:	004a2603          	lw	a2,4(s4)
    80004df0:	fb040593          	addi	a1,s0,-80
    80004df4:	8526                	mv	a0,s1
    80004df6:	e7ffe0ef          	jal	80003c74 <dirlink>
    80004dfa:	00054b63          	bltz	a0,80004e10 <create+0x11c>
    dp->nlink++;  // for ".."
    80004dfe:	04a4d783          	lhu	a5,74(s1)
    80004e02:	2785                	addiw	a5,a5,1
    80004e04:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004e08:	8526                	mv	a0,s1
    80004e0a:	e3afe0ef          	jal	80003444 <iupdate>
    80004e0e:	bf71                	j	80004daa <create+0xb6>
  ip->nlink = 0;
    80004e10:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004e14:	8552                	mv	a0,s4
    80004e16:	e2efe0ef          	jal	80003444 <iupdate>
  iunlockput(ip);
    80004e1a:	8552                	mv	a0,s4
    80004e1c:	8e7fe0ef          	jal	80003702 <iunlockput>
  iunlockput(dp);
    80004e20:	8526                	mv	a0,s1
    80004e22:	8e1fe0ef          	jal	80003702 <iunlockput>
  return 0;
    80004e26:	7a02                	ld	s4,32(sp)
    80004e28:	b725                	j	80004d50 <create+0x5c>
    return 0;
    80004e2a:	8aaa                	mv	s5,a0
    80004e2c:	b715                	j	80004d50 <create+0x5c>

0000000080004e2e <sys_dup>:
{
    80004e2e:	7179                	addi	sp,sp,-48
    80004e30:	f406                	sd	ra,40(sp)
    80004e32:	f022                	sd	s0,32(sp)
    80004e34:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004e36:	fd840613          	addi	a2,s0,-40
    80004e3a:	4581                	li	a1,0
    80004e3c:	4501                	li	a0,0
    80004e3e:	e21ff0ef          	jal	80004c5e <argfd>
    return -1;
    80004e42:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004e44:	02054363          	bltz	a0,80004e6a <sys_dup+0x3c>
    80004e48:	ec26                	sd	s1,24(sp)
    80004e4a:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004e4c:	fd843903          	ld	s2,-40(s0)
    80004e50:	854a                	mv	a0,s2
    80004e52:	e65ff0ef          	jal	80004cb6 <fdalloc>
    80004e56:	84aa                	mv	s1,a0
    return -1;
    80004e58:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004e5a:	00054d63          	bltz	a0,80004e74 <sys_dup+0x46>
  filedup(f);
    80004e5e:	854a                	mv	a0,s2
    80004e60:	c48ff0ef          	jal	800042a8 <filedup>
  return fd;
    80004e64:	87a6                	mv	a5,s1
    80004e66:	64e2                	ld	s1,24(sp)
    80004e68:	6942                	ld	s2,16(sp)
}
    80004e6a:	853e                	mv	a0,a5
    80004e6c:	70a2                	ld	ra,40(sp)
    80004e6e:	7402                	ld	s0,32(sp)
    80004e70:	6145                	addi	sp,sp,48
    80004e72:	8082                	ret
    80004e74:	64e2                	ld	s1,24(sp)
    80004e76:	6942                	ld	s2,16(sp)
    80004e78:	bfcd                	j	80004e6a <sys_dup+0x3c>

0000000080004e7a <sys_read>:
{
    80004e7a:	7179                	addi	sp,sp,-48
    80004e7c:	f406                	sd	ra,40(sp)
    80004e7e:	f022                	sd	s0,32(sp)
    80004e80:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e82:	fd840593          	addi	a1,s0,-40
    80004e86:	4505                	li	a0,1
    80004e88:	c59fd0ef          	jal	80002ae0 <argaddr>
  argint(2, &n);
    80004e8c:	fe440593          	addi	a1,s0,-28
    80004e90:	4509                	li	a0,2
    80004e92:	c33fd0ef          	jal	80002ac4 <argint>
  if(argfd(0, 0, &f) < 0)
    80004e96:	fe840613          	addi	a2,s0,-24
    80004e9a:	4581                	li	a1,0
    80004e9c:	4501                	li	a0,0
    80004e9e:	dc1ff0ef          	jal	80004c5e <argfd>
    80004ea2:	87aa                	mv	a5,a0
    return -1;
    80004ea4:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004ea6:	0007ca63          	bltz	a5,80004eba <sys_read+0x40>
  return fileread(f, p, n);
    80004eaa:	fe442603          	lw	a2,-28(s0)
    80004eae:	fd843583          	ld	a1,-40(s0)
    80004eb2:	fe843503          	ld	a0,-24(s0)
    80004eb6:	d58ff0ef          	jal	8000440e <fileread>
}
    80004eba:	70a2                	ld	ra,40(sp)
    80004ebc:	7402                	ld	s0,32(sp)
    80004ebe:	6145                	addi	sp,sp,48
    80004ec0:	8082                	ret

0000000080004ec2 <sys_write>:
{
    80004ec2:	7179                	addi	sp,sp,-48
    80004ec4:	f406                	sd	ra,40(sp)
    80004ec6:	f022                	sd	s0,32(sp)
    80004ec8:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004eca:	fd840593          	addi	a1,s0,-40
    80004ece:	4505                	li	a0,1
    80004ed0:	c11fd0ef          	jal	80002ae0 <argaddr>
  argint(2, &n);
    80004ed4:	fe440593          	addi	a1,s0,-28
    80004ed8:	4509                	li	a0,2
    80004eda:	bebfd0ef          	jal	80002ac4 <argint>
  if(argfd(0, 0, &f) < 0)
    80004ede:	fe840613          	addi	a2,s0,-24
    80004ee2:	4581                	li	a1,0
    80004ee4:	4501                	li	a0,0
    80004ee6:	d79ff0ef          	jal	80004c5e <argfd>
    80004eea:	87aa                	mv	a5,a0
    return -1;
    80004eec:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004eee:	0007ca63          	bltz	a5,80004f02 <sys_write+0x40>
  return filewrite(f, p, n);
    80004ef2:	fe442603          	lw	a2,-28(s0)
    80004ef6:	fd843583          	ld	a1,-40(s0)
    80004efa:	fe843503          	ld	a0,-24(s0)
    80004efe:	dceff0ef          	jal	800044cc <filewrite>
}
    80004f02:	70a2                	ld	ra,40(sp)
    80004f04:	7402                	ld	s0,32(sp)
    80004f06:	6145                	addi	sp,sp,48
    80004f08:	8082                	ret

0000000080004f0a <sys_close>:
{
    80004f0a:	1101                	addi	sp,sp,-32
    80004f0c:	ec06                	sd	ra,24(sp)
    80004f0e:	e822                	sd	s0,16(sp)
    80004f10:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004f12:	fe040613          	addi	a2,s0,-32
    80004f16:	fec40593          	addi	a1,s0,-20
    80004f1a:	4501                	li	a0,0
    80004f1c:	d43ff0ef          	jal	80004c5e <argfd>
    return -1;
    80004f20:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004f22:	02054063          	bltz	a0,80004f42 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004f26:	ca3fc0ef          	jal	80001bc8 <myproc>
    80004f2a:	fec42783          	lw	a5,-20(s0)
    80004f2e:	07e9                	addi	a5,a5,26
    80004f30:	078e                	slli	a5,a5,0x3
    80004f32:	953e                	add	a0,a0,a5
    80004f34:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004f38:	fe043503          	ld	a0,-32(s0)
    80004f3c:	bb2ff0ef          	jal	800042ee <fileclose>
  return 0;
    80004f40:	4781                	li	a5,0
}
    80004f42:	853e                	mv	a0,a5
    80004f44:	60e2                	ld	ra,24(sp)
    80004f46:	6442                	ld	s0,16(sp)
    80004f48:	6105                	addi	sp,sp,32
    80004f4a:	8082                	ret

0000000080004f4c <sys_fstat>:
{
    80004f4c:	1101                	addi	sp,sp,-32
    80004f4e:	ec06                	sd	ra,24(sp)
    80004f50:	e822                	sd	s0,16(sp)
    80004f52:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004f54:	fe040593          	addi	a1,s0,-32
    80004f58:	4505                	li	a0,1
    80004f5a:	b87fd0ef          	jal	80002ae0 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004f5e:	fe840613          	addi	a2,s0,-24
    80004f62:	4581                	li	a1,0
    80004f64:	4501                	li	a0,0
    80004f66:	cf9ff0ef          	jal	80004c5e <argfd>
    80004f6a:	87aa                	mv	a5,a0
    return -1;
    80004f6c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004f6e:	0007c863          	bltz	a5,80004f7e <sys_fstat+0x32>
  return filestat(f, st);
    80004f72:	fe043583          	ld	a1,-32(s0)
    80004f76:	fe843503          	ld	a0,-24(s0)
    80004f7a:	c36ff0ef          	jal	800043b0 <filestat>
}
    80004f7e:	60e2                	ld	ra,24(sp)
    80004f80:	6442                	ld	s0,16(sp)
    80004f82:	6105                	addi	sp,sp,32
    80004f84:	8082                	ret

0000000080004f86 <sys_link>:
{
    80004f86:	7169                	addi	sp,sp,-304
    80004f88:	f606                	sd	ra,296(sp)
    80004f8a:	f222                	sd	s0,288(sp)
    80004f8c:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f8e:	08000613          	li	a2,128
    80004f92:	ed040593          	addi	a1,s0,-304
    80004f96:	4501                	li	a0,0
    80004f98:	b65fd0ef          	jal	80002afc <argstr>
    return -1;
    80004f9c:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f9e:	0c054e63          	bltz	a0,8000507a <sys_link+0xf4>
    80004fa2:	08000613          	li	a2,128
    80004fa6:	f5040593          	addi	a1,s0,-176
    80004faa:	4505                	li	a0,1
    80004fac:	b51fd0ef          	jal	80002afc <argstr>
    return -1;
    80004fb0:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004fb2:	0c054463          	bltz	a0,8000507a <sys_link+0xf4>
    80004fb6:	ee26                	sd	s1,280(sp)
  begin_op();
    80004fb8:	f2bfe0ef          	jal	80003ee2 <begin_op>
  if((ip = namei(old)) == 0){
    80004fbc:	ed040513          	addi	a0,s0,-304
    80004fc0:	d4ffe0ef          	jal	80003d0e <namei>
    80004fc4:	84aa                	mv	s1,a0
    80004fc6:	c53d                	beqz	a0,80005034 <sys_link+0xae>
  ilock(ip);
    80004fc8:	d30fe0ef          	jal	800034f8 <ilock>
  if(ip->type == T_DIR){
    80004fcc:	04449703          	lh	a4,68(s1)
    80004fd0:	4785                	li	a5,1
    80004fd2:	06f70663          	beq	a4,a5,8000503e <sys_link+0xb8>
    80004fd6:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004fd8:	04a4d783          	lhu	a5,74(s1)
    80004fdc:	2785                	addiw	a5,a5,1
    80004fde:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004fe2:	8526                	mv	a0,s1
    80004fe4:	c60fe0ef          	jal	80003444 <iupdate>
  iunlock(ip);
    80004fe8:	8526                	mv	a0,s1
    80004fea:	dbcfe0ef          	jal	800035a6 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004fee:	fd040593          	addi	a1,s0,-48
    80004ff2:	f5040513          	addi	a0,s0,-176
    80004ff6:	d33fe0ef          	jal	80003d28 <nameiparent>
    80004ffa:	892a                	mv	s2,a0
    80004ffc:	cd21                	beqz	a0,80005054 <sys_link+0xce>
  ilock(dp);
    80004ffe:	cfafe0ef          	jal	800034f8 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80005002:	00092703          	lw	a4,0(s2)
    80005006:	409c                	lw	a5,0(s1)
    80005008:	04f71363          	bne	a4,a5,8000504e <sys_link+0xc8>
    8000500c:	40d0                	lw	a2,4(s1)
    8000500e:	fd040593          	addi	a1,s0,-48
    80005012:	854a                	mv	a0,s2
    80005014:	c61fe0ef          	jal	80003c74 <dirlink>
    80005018:	02054b63          	bltz	a0,8000504e <sys_link+0xc8>
  iunlockput(dp);
    8000501c:	854a                	mv	a0,s2
    8000501e:	ee4fe0ef          	jal	80003702 <iunlockput>
  iput(ip);
    80005022:	8526                	mv	a0,s1
    80005024:	e56fe0ef          	jal	8000367a <iput>
  end_op();
    80005028:	f25fe0ef          	jal	80003f4c <end_op>
  return 0;
    8000502c:	4781                	li	a5,0
    8000502e:	64f2                	ld	s1,280(sp)
    80005030:	6952                	ld	s2,272(sp)
    80005032:	a0a1                	j	8000507a <sys_link+0xf4>
    end_op();
    80005034:	f19fe0ef          	jal	80003f4c <end_op>
    return -1;
    80005038:	57fd                	li	a5,-1
    8000503a:	64f2                	ld	s1,280(sp)
    8000503c:	a83d                	j	8000507a <sys_link+0xf4>
    iunlockput(ip);
    8000503e:	8526                	mv	a0,s1
    80005040:	ec2fe0ef          	jal	80003702 <iunlockput>
    end_op();
    80005044:	f09fe0ef          	jal	80003f4c <end_op>
    return -1;
    80005048:	57fd                	li	a5,-1
    8000504a:	64f2                	ld	s1,280(sp)
    8000504c:	a03d                	j	8000507a <sys_link+0xf4>
    iunlockput(dp);
    8000504e:	854a                	mv	a0,s2
    80005050:	eb2fe0ef          	jal	80003702 <iunlockput>
  ilock(ip);
    80005054:	8526                	mv	a0,s1
    80005056:	ca2fe0ef          	jal	800034f8 <ilock>
  ip->nlink--;
    8000505a:	04a4d783          	lhu	a5,74(s1)
    8000505e:	37fd                	addiw	a5,a5,-1
    80005060:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005064:	8526                	mv	a0,s1
    80005066:	bdefe0ef          	jal	80003444 <iupdate>
  iunlockput(ip);
    8000506a:	8526                	mv	a0,s1
    8000506c:	e96fe0ef          	jal	80003702 <iunlockput>
  end_op();
    80005070:	eddfe0ef          	jal	80003f4c <end_op>
  return -1;
    80005074:	57fd                	li	a5,-1
    80005076:	64f2                	ld	s1,280(sp)
    80005078:	6952                	ld	s2,272(sp)
}
    8000507a:	853e                	mv	a0,a5
    8000507c:	70b2                	ld	ra,296(sp)
    8000507e:	7412                	ld	s0,288(sp)
    80005080:	6155                	addi	sp,sp,304
    80005082:	8082                	ret

0000000080005084 <sys_unlink>:
{
    80005084:	7151                	addi	sp,sp,-240
    80005086:	f586                	sd	ra,232(sp)
    80005088:	f1a2                	sd	s0,224(sp)
    8000508a:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000508c:	08000613          	li	a2,128
    80005090:	f3040593          	addi	a1,s0,-208
    80005094:	4501                	li	a0,0
    80005096:	a67fd0ef          	jal	80002afc <argstr>
    8000509a:	16054063          	bltz	a0,800051fa <sys_unlink+0x176>
    8000509e:	eda6                	sd	s1,216(sp)
  begin_op();
    800050a0:	e43fe0ef          	jal	80003ee2 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    800050a4:	fb040593          	addi	a1,s0,-80
    800050a8:	f3040513          	addi	a0,s0,-208
    800050ac:	c7dfe0ef          	jal	80003d28 <nameiparent>
    800050b0:	84aa                	mv	s1,a0
    800050b2:	c945                	beqz	a0,80005162 <sys_unlink+0xde>
  ilock(dp);
    800050b4:	c44fe0ef          	jal	800034f8 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800050b8:	00002597          	auipc	a1,0x2
    800050bc:	66858593          	addi	a1,a1,1640 # 80007720 <etext+0x720>
    800050c0:	fb040513          	addi	a0,s0,-80
    800050c4:	9cffe0ef          	jal	80003a92 <namecmp>
    800050c8:	10050e63          	beqz	a0,800051e4 <sys_unlink+0x160>
    800050cc:	00002597          	auipc	a1,0x2
    800050d0:	65c58593          	addi	a1,a1,1628 # 80007728 <etext+0x728>
    800050d4:	fb040513          	addi	a0,s0,-80
    800050d8:	9bbfe0ef          	jal	80003a92 <namecmp>
    800050dc:	10050463          	beqz	a0,800051e4 <sys_unlink+0x160>
    800050e0:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800050e2:	f2c40613          	addi	a2,s0,-212
    800050e6:	fb040593          	addi	a1,s0,-80
    800050ea:	8526                	mv	a0,s1
    800050ec:	9bdfe0ef          	jal	80003aa8 <dirlookup>
    800050f0:	892a                	mv	s2,a0
    800050f2:	0e050863          	beqz	a0,800051e2 <sys_unlink+0x15e>
  ilock(ip);
    800050f6:	c02fe0ef          	jal	800034f8 <ilock>
  if(ip->nlink < 1)
    800050fa:	04a91783          	lh	a5,74(s2)
    800050fe:	06f05763          	blez	a5,8000516c <sys_unlink+0xe8>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80005102:	04491703          	lh	a4,68(s2)
    80005106:	4785                	li	a5,1
    80005108:	06f70963          	beq	a4,a5,8000517a <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    8000510c:	4641                	li	a2,16
    8000510e:	4581                	li	a1,0
    80005110:	fc040513          	addi	a0,s0,-64
    80005114:	dcdfb0ef          	jal	80000ee0 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005118:	4741                	li	a4,16
    8000511a:	f2c42683          	lw	a3,-212(s0)
    8000511e:	fc040613          	addi	a2,s0,-64
    80005122:	4581                	li	a1,0
    80005124:	8526                	mv	a0,s1
    80005126:	85ffe0ef          	jal	80003984 <writei>
    8000512a:	47c1                	li	a5,16
    8000512c:	08f51b63          	bne	a0,a5,800051c2 <sys_unlink+0x13e>
  if(ip->type == T_DIR){
    80005130:	04491703          	lh	a4,68(s2)
    80005134:	4785                	li	a5,1
    80005136:	08f70d63          	beq	a4,a5,800051d0 <sys_unlink+0x14c>
  iunlockput(dp);
    8000513a:	8526                	mv	a0,s1
    8000513c:	dc6fe0ef          	jal	80003702 <iunlockput>
  ip->nlink--;
    80005140:	04a95783          	lhu	a5,74(s2)
    80005144:	37fd                	addiw	a5,a5,-1
    80005146:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000514a:	854a                	mv	a0,s2
    8000514c:	af8fe0ef          	jal	80003444 <iupdate>
  iunlockput(ip);
    80005150:	854a                	mv	a0,s2
    80005152:	db0fe0ef          	jal	80003702 <iunlockput>
  end_op();
    80005156:	df7fe0ef          	jal	80003f4c <end_op>
  return 0;
    8000515a:	4501                	li	a0,0
    8000515c:	64ee                	ld	s1,216(sp)
    8000515e:	694e                	ld	s2,208(sp)
    80005160:	a849                	j	800051f2 <sys_unlink+0x16e>
    end_op();
    80005162:	debfe0ef          	jal	80003f4c <end_op>
    return -1;
    80005166:	557d                	li	a0,-1
    80005168:	64ee                	ld	s1,216(sp)
    8000516a:	a061                	j	800051f2 <sys_unlink+0x16e>
    8000516c:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    8000516e:	00002517          	auipc	a0,0x2
    80005172:	5c250513          	addi	a0,a0,1474 # 80007730 <etext+0x730>
    80005176:	e6afb0ef          	jal	800007e0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000517a:	04c92703          	lw	a4,76(s2)
    8000517e:	02000793          	li	a5,32
    80005182:	f8e7f5e3          	bgeu	a5,a4,8000510c <sys_unlink+0x88>
    80005186:	e5ce                	sd	s3,200(sp)
    80005188:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000518c:	4741                	li	a4,16
    8000518e:	86ce                	mv	a3,s3
    80005190:	f1840613          	addi	a2,s0,-232
    80005194:	4581                	li	a1,0
    80005196:	854a                	mv	a0,s2
    80005198:	ef0fe0ef          	jal	80003888 <readi>
    8000519c:	47c1                	li	a5,16
    8000519e:	00f51c63          	bne	a0,a5,800051b6 <sys_unlink+0x132>
    if(de.inum != 0)
    800051a2:	f1845783          	lhu	a5,-232(s0)
    800051a6:	efa1                	bnez	a5,800051fe <sys_unlink+0x17a>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800051a8:	29c1                	addiw	s3,s3,16
    800051aa:	04c92783          	lw	a5,76(s2)
    800051ae:	fcf9efe3          	bltu	s3,a5,8000518c <sys_unlink+0x108>
    800051b2:	69ae                	ld	s3,200(sp)
    800051b4:	bfa1                	j	8000510c <sys_unlink+0x88>
      panic("isdirempty: readi");
    800051b6:	00002517          	auipc	a0,0x2
    800051ba:	59250513          	addi	a0,a0,1426 # 80007748 <etext+0x748>
    800051be:	e22fb0ef          	jal	800007e0 <panic>
    800051c2:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    800051c4:	00002517          	auipc	a0,0x2
    800051c8:	59c50513          	addi	a0,a0,1436 # 80007760 <etext+0x760>
    800051cc:	e14fb0ef          	jal	800007e0 <panic>
    dp->nlink--;
    800051d0:	04a4d783          	lhu	a5,74(s1)
    800051d4:	37fd                	addiw	a5,a5,-1
    800051d6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800051da:	8526                	mv	a0,s1
    800051dc:	a68fe0ef          	jal	80003444 <iupdate>
    800051e0:	bfa9                	j	8000513a <sys_unlink+0xb6>
    800051e2:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800051e4:	8526                	mv	a0,s1
    800051e6:	d1cfe0ef          	jal	80003702 <iunlockput>
  end_op();
    800051ea:	d63fe0ef          	jal	80003f4c <end_op>
  return -1;
    800051ee:	557d                	li	a0,-1
    800051f0:	64ee                	ld	s1,216(sp)
}
    800051f2:	70ae                	ld	ra,232(sp)
    800051f4:	740e                	ld	s0,224(sp)
    800051f6:	616d                	addi	sp,sp,240
    800051f8:	8082                	ret
    return -1;
    800051fa:	557d                	li	a0,-1
    800051fc:	bfdd                	j	800051f2 <sys_unlink+0x16e>
    iunlockput(ip);
    800051fe:	854a                	mv	a0,s2
    80005200:	d02fe0ef          	jal	80003702 <iunlockput>
    goto bad;
    80005204:	694e                	ld	s2,208(sp)
    80005206:	69ae                	ld	s3,200(sp)
    80005208:	bff1                	j	800051e4 <sys_unlink+0x160>

000000008000520a <sys_open>:

uint64
sys_open(void)
{
    8000520a:	7131                	addi	sp,sp,-192
    8000520c:	fd06                	sd	ra,184(sp)
    8000520e:	f922                	sd	s0,176(sp)
    80005210:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005212:	f4c40593          	addi	a1,s0,-180
    80005216:	4505                	li	a0,1
    80005218:	8adfd0ef          	jal	80002ac4 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000521c:	08000613          	li	a2,128
    80005220:	f5040593          	addi	a1,s0,-176
    80005224:	4501                	li	a0,0
    80005226:	8d7fd0ef          	jal	80002afc <argstr>
    8000522a:	87aa                	mv	a5,a0
    return -1;
    8000522c:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000522e:	0a07c263          	bltz	a5,800052d2 <sys_open+0xc8>
    80005232:	f526                	sd	s1,168(sp)

  begin_op();
    80005234:	caffe0ef          	jal	80003ee2 <begin_op>

  if(omode & O_CREATE){
    80005238:	f4c42783          	lw	a5,-180(s0)
    8000523c:	2007f793          	andi	a5,a5,512
    80005240:	c3d5                	beqz	a5,800052e4 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80005242:	4681                	li	a3,0
    80005244:	4601                	li	a2,0
    80005246:	4589                	li	a1,2
    80005248:	f5040513          	addi	a0,s0,-176
    8000524c:	aa9ff0ef          	jal	80004cf4 <create>
    80005250:	84aa                	mv	s1,a0
    if(ip == 0){
    80005252:	c541                	beqz	a0,800052da <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80005254:	04449703          	lh	a4,68(s1)
    80005258:	478d                	li	a5,3
    8000525a:	00f71763          	bne	a4,a5,80005268 <sys_open+0x5e>
    8000525e:	0464d703          	lhu	a4,70(s1)
    80005262:	47a5                	li	a5,9
    80005264:	0ae7ed63          	bltu	a5,a4,8000531e <sys_open+0x114>
    80005268:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000526a:	fe1fe0ef          	jal	8000424a <filealloc>
    8000526e:	892a                	mv	s2,a0
    80005270:	c179                	beqz	a0,80005336 <sys_open+0x12c>
    80005272:	ed4e                	sd	s3,152(sp)
    80005274:	a43ff0ef          	jal	80004cb6 <fdalloc>
    80005278:	89aa                	mv	s3,a0
    8000527a:	0a054a63          	bltz	a0,8000532e <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000527e:	04449703          	lh	a4,68(s1)
    80005282:	478d                	li	a5,3
    80005284:	0cf70263          	beq	a4,a5,80005348 <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005288:	4789                	li	a5,2
    8000528a:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000528e:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005292:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005296:	f4c42783          	lw	a5,-180(s0)
    8000529a:	0017c713          	xori	a4,a5,1
    8000529e:	8b05                	andi	a4,a4,1
    800052a0:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800052a4:	0037f713          	andi	a4,a5,3
    800052a8:	00e03733          	snez	a4,a4
    800052ac:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800052b0:	4007f793          	andi	a5,a5,1024
    800052b4:	c791                	beqz	a5,800052c0 <sys_open+0xb6>
    800052b6:	04449703          	lh	a4,68(s1)
    800052ba:	4789                	li	a5,2
    800052bc:	08f70d63          	beq	a4,a5,80005356 <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    800052c0:	8526                	mv	a0,s1
    800052c2:	ae4fe0ef          	jal	800035a6 <iunlock>
  end_op();
    800052c6:	c87fe0ef          	jal	80003f4c <end_op>

  return fd;
    800052ca:	854e                	mv	a0,s3
    800052cc:	74aa                	ld	s1,168(sp)
    800052ce:	790a                	ld	s2,160(sp)
    800052d0:	69ea                	ld	s3,152(sp)
}
    800052d2:	70ea                	ld	ra,184(sp)
    800052d4:	744a                	ld	s0,176(sp)
    800052d6:	6129                	addi	sp,sp,192
    800052d8:	8082                	ret
      end_op();
    800052da:	c73fe0ef          	jal	80003f4c <end_op>
      return -1;
    800052de:	557d                	li	a0,-1
    800052e0:	74aa                	ld	s1,168(sp)
    800052e2:	bfc5                	j	800052d2 <sys_open+0xc8>
    if((ip = namei(path)) == 0){
    800052e4:	f5040513          	addi	a0,s0,-176
    800052e8:	a27fe0ef          	jal	80003d0e <namei>
    800052ec:	84aa                	mv	s1,a0
    800052ee:	c11d                	beqz	a0,80005314 <sys_open+0x10a>
    ilock(ip);
    800052f0:	a08fe0ef          	jal	800034f8 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800052f4:	04449703          	lh	a4,68(s1)
    800052f8:	4785                	li	a5,1
    800052fa:	f4f71de3          	bne	a4,a5,80005254 <sys_open+0x4a>
    800052fe:	f4c42783          	lw	a5,-180(s0)
    80005302:	d3bd                	beqz	a5,80005268 <sys_open+0x5e>
      iunlockput(ip);
    80005304:	8526                	mv	a0,s1
    80005306:	bfcfe0ef          	jal	80003702 <iunlockput>
      end_op();
    8000530a:	c43fe0ef          	jal	80003f4c <end_op>
      return -1;
    8000530e:	557d                	li	a0,-1
    80005310:	74aa                	ld	s1,168(sp)
    80005312:	b7c1                	j	800052d2 <sys_open+0xc8>
      end_op();
    80005314:	c39fe0ef          	jal	80003f4c <end_op>
      return -1;
    80005318:	557d                	li	a0,-1
    8000531a:	74aa                	ld	s1,168(sp)
    8000531c:	bf5d                	j	800052d2 <sys_open+0xc8>
    iunlockput(ip);
    8000531e:	8526                	mv	a0,s1
    80005320:	be2fe0ef          	jal	80003702 <iunlockput>
    end_op();
    80005324:	c29fe0ef          	jal	80003f4c <end_op>
    return -1;
    80005328:	557d                	li	a0,-1
    8000532a:	74aa                	ld	s1,168(sp)
    8000532c:	b75d                	j	800052d2 <sys_open+0xc8>
      fileclose(f);
    8000532e:	854a                	mv	a0,s2
    80005330:	fbffe0ef          	jal	800042ee <fileclose>
    80005334:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005336:	8526                	mv	a0,s1
    80005338:	bcafe0ef          	jal	80003702 <iunlockput>
    end_op();
    8000533c:	c11fe0ef          	jal	80003f4c <end_op>
    return -1;
    80005340:	557d                	li	a0,-1
    80005342:	74aa                	ld	s1,168(sp)
    80005344:	790a                	ld	s2,160(sp)
    80005346:	b771                	j	800052d2 <sys_open+0xc8>
    f->type = FD_DEVICE;
    80005348:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    8000534c:	04649783          	lh	a5,70(s1)
    80005350:	02f91223          	sh	a5,36(s2)
    80005354:	bf3d                	j	80005292 <sys_open+0x88>
    itrunc(ip);
    80005356:	8526                	mv	a0,s1
    80005358:	a8efe0ef          	jal	800035e6 <itrunc>
    8000535c:	b795                	j	800052c0 <sys_open+0xb6>

000000008000535e <sys_mkdir>:

uint64
sys_mkdir(void)
{
    8000535e:	7175                	addi	sp,sp,-144
    80005360:	e506                	sd	ra,136(sp)
    80005362:	e122                	sd	s0,128(sp)
    80005364:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005366:	b7dfe0ef          	jal	80003ee2 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000536a:	08000613          	li	a2,128
    8000536e:	f7040593          	addi	a1,s0,-144
    80005372:	4501                	li	a0,0
    80005374:	f88fd0ef          	jal	80002afc <argstr>
    80005378:	02054363          	bltz	a0,8000539e <sys_mkdir+0x40>
    8000537c:	4681                	li	a3,0
    8000537e:	4601                	li	a2,0
    80005380:	4585                	li	a1,1
    80005382:	f7040513          	addi	a0,s0,-144
    80005386:	96fff0ef          	jal	80004cf4 <create>
    8000538a:	c911                	beqz	a0,8000539e <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000538c:	b76fe0ef          	jal	80003702 <iunlockput>
  end_op();
    80005390:	bbdfe0ef          	jal	80003f4c <end_op>
  return 0;
    80005394:	4501                	li	a0,0
}
    80005396:	60aa                	ld	ra,136(sp)
    80005398:	640a                	ld	s0,128(sp)
    8000539a:	6149                	addi	sp,sp,144
    8000539c:	8082                	ret
    end_op();
    8000539e:	baffe0ef          	jal	80003f4c <end_op>
    return -1;
    800053a2:	557d                	li	a0,-1
    800053a4:	bfcd                	j	80005396 <sys_mkdir+0x38>

00000000800053a6 <sys_mknod>:

uint64
sys_mknod(void)
{
    800053a6:	7135                	addi	sp,sp,-160
    800053a8:	ed06                	sd	ra,152(sp)
    800053aa:	e922                	sd	s0,144(sp)
    800053ac:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800053ae:	b35fe0ef          	jal	80003ee2 <begin_op>
  argint(1, &major);
    800053b2:	f6c40593          	addi	a1,s0,-148
    800053b6:	4505                	li	a0,1
    800053b8:	f0cfd0ef          	jal	80002ac4 <argint>
  argint(2, &minor);
    800053bc:	f6840593          	addi	a1,s0,-152
    800053c0:	4509                	li	a0,2
    800053c2:	f02fd0ef          	jal	80002ac4 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800053c6:	08000613          	li	a2,128
    800053ca:	f7040593          	addi	a1,s0,-144
    800053ce:	4501                	li	a0,0
    800053d0:	f2cfd0ef          	jal	80002afc <argstr>
    800053d4:	02054563          	bltz	a0,800053fe <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800053d8:	f6841683          	lh	a3,-152(s0)
    800053dc:	f6c41603          	lh	a2,-148(s0)
    800053e0:	458d                	li	a1,3
    800053e2:	f7040513          	addi	a0,s0,-144
    800053e6:	90fff0ef          	jal	80004cf4 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800053ea:	c911                	beqz	a0,800053fe <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800053ec:	b16fe0ef          	jal	80003702 <iunlockput>
  end_op();
    800053f0:	b5dfe0ef          	jal	80003f4c <end_op>
  return 0;
    800053f4:	4501                	li	a0,0
}
    800053f6:	60ea                	ld	ra,152(sp)
    800053f8:	644a                	ld	s0,144(sp)
    800053fa:	610d                	addi	sp,sp,160
    800053fc:	8082                	ret
    end_op();
    800053fe:	b4ffe0ef          	jal	80003f4c <end_op>
    return -1;
    80005402:	557d                	li	a0,-1
    80005404:	bfcd                	j	800053f6 <sys_mknod+0x50>

0000000080005406 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005406:	7135                	addi	sp,sp,-160
    80005408:	ed06                	sd	ra,152(sp)
    8000540a:	e922                	sd	s0,144(sp)
    8000540c:	e14a                	sd	s2,128(sp)
    8000540e:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005410:	fb8fc0ef          	jal	80001bc8 <myproc>
    80005414:	892a                	mv	s2,a0
  
  begin_op();
    80005416:	acdfe0ef          	jal	80003ee2 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    8000541a:	08000613          	li	a2,128
    8000541e:	f6040593          	addi	a1,s0,-160
    80005422:	4501                	li	a0,0
    80005424:	ed8fd0ef          	jal	80002afc <argstr>
    80005428:	04054363          	bltz	a0,8000546e <sys_chdir+0x68>
    8000542c:	e526                	sd	s1,136(sp)
    8000542e:	f6040513          	addi	a0,s0,-160
    80005432:	8ddfe0ef          	jal	80003d0e <namei>
    80005436:	84aa                	mv	s1,a0
    80005438:	c915                	beqz	a0,8000546c <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    8000543a:	8befe0ef          	jal	800034f8 <ilock>
  if(ip->type != T_DIR){
    8000543e:	04449703          	lh	a4,68(s1)
    80005442:	4785                	li	a5,1
    80005444:	02f71963          	bne	a4,a5,80005476 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005448:	8526                	mv	a0,s1
    8000544a:	95cfe0ef          	jal	800035a6 <iunlock>
  iput(p->cwd);
    8000544e:	15093503          	ld	a0,336(s2)
    80005452:	a28fe0ef          	jal	8000367a <iput>
  end_op();
    80005456:	af7fe0ef          	jal	80003f4c <end_op>
  p->cwd = ip;
    8000545a:	14993823          	sd	s1,336(s2)
  return 0;
    8000545e:	4501                	li	a0,0
    80005460:	64aa                	ld	s1,136(sp)
}
    80005462:	60ea                	ld	ra,152(sp)
    80005464:	644a                	ld	s0,144(sp)
    80005466:	690a                	ld	s2,128(sp)
    80005468:	610d                	addi	sp,sp,160
    8000546a:	8082                	ret
    8000546c:	64aa                	ld	s1,136(sp)
    end_op();
    8000546e:	adffe0ef          	jal	80003f4c <end_op>
    return -1;
    80005472:	557d                	li	a0,-1
    80005474:	b7fd                	j	80005462 <sys_chdir+0x5c>
    iunlockput(ip);
    80005476:	8526                	mv	a0,s1
    80005478:	a8afe0ef          	jal	80003702 <iunlockput>
    end_op();
    8000547c:	ad1fe0ef          	jal	80003f4c <end_op>
    return -1;
    80005480:	557d                	li	a0,-1
    80005482:	64aa                	ld	s1,136(sp)
    80005484:	bff9                	j	80005462 <sys_chdir+0x5c>

0000000080005486 <sys_exec>:

uint64
sys_exec(void)
{
    80005486:	7121                	addi	sp,sp,-448
    80005488:	ff06                	sd	ra,440(sp)
    8000548a:	fb22                	sd	s0,432(sp)
    8000548c:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000548e:	e4840593          	addi	a1,s0,-440
    80005492:	4505                	li	a0,1
    80005494:	e4cfd0ef          	jal	80002ae0 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005498:	08000613          	li	a2,128
    8000549c:	f5040593          	addi	a1,s0,-176
    800054a0:	4501                	li	a0,0
    800054a2:	e5afd0ef          	jal	80002afc <argstr>
    800054a6:	87aa                	mv	a5,a0
    return -1;
    800054a8:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    800054aa:	0c07c463          	bltz	a5,80005572 <sys_exec+0xec>
    800054ae:	f726                	sd	s1,424(sp)
    800054b0:	f34a                	sd	s2,416(sp)
    800054b2:	ef4e                	sd	s3,408(sp)
    800054b4:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    800054b6:	10000613          	li	a2,256
    800054ba:	4581                	li	a1,0
    800054bc:	e5040513          	addi	a0,s0,-432
    800054c0:	a21fb0ef          	jal	80000ee0 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800054c4:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    800054c8:	89a6                	mv	s3,s1
    800054ca:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    800054cc:	02000a13          	li	s4,32
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800054d0:	00391513          	slli	a0,s2,0x3
    800054d4:	e4040593          	addi	a1,s0,-448
    800054d8:	e4843783          	ld	a5,-440(s0)
    800054dc:	953e                	add	a0,a0,a5
    800054de:	d5cfd0ef          	jal	80002a3a <fetchaddr>
    800054e2:	02054663          	bltz	a0,8000550e <sys_exec+0x88>
      goto bad;
    }
    if(uarg == 0){
    800054e6:	e4043783          	ld	a5,-448(s0)
    800054ea:	c3a9                	beqz	a5,8000552c <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    800054ec:	f5efb0ef          	jal	80000c4a <kalloc>
    800054f0:	85aa                	mv	a1,a0
    800054f2:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800054f6:	cd01                	beqz	a0,8000550e <sys_exec+0x88>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054f8:	6605                	lui	a2,0x1
    800054fa:	e4043503          	ld	a0,-448(s0)
    800054fe:	d86fd0ef          	jal	80002a84 <fetchstr>
    80005502:	00054663          	bltz	a0,8000550e <sys_exec+0x88>
    if(i >= NELEM(argv)){
    80005506:	0905                	addi	s2,s2,1
    80005508:	09a1                	addi	s3,s3,8
    8000550a:	fd4913e3          	bne	s2,s4,800054d0 <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000550e:	f5040913          	addi	s2,s0,-176
    80005512:	6088                	ld	a0,0(s1)
    80005514:	c931                	beqz	a0,80005568 <sys_exec+0xe2>
    kfree(argv[i]);
    80005516:	db4fb0ef          	jal	80000aca <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000551a:	04a1                	addi	s1,s1,8
    8000551c:	ff249be3          	bne	s1,s2,80005512 <sys_exec+0x8c>
  return -1;
    80005520:	557d                	li	a0,-1
    80005522:	74ba                	ld	s1,424(sp)
    80005524:	791a                	ld	s2,416(sp)
    80005526:	69fa                	ld	s3,408(sp)
    80005528:	6a5a                	ld	s4,400(sp)
    8000552a:	a0a1                	j	80005572 <sys_exec+0xec>
      argv[i] = 0;
    8000552c:	0009079b          	sext.w	a5,s2
    80005530:	078e                	slli	a5,a5,0x3
    80005532:	fd078793          	addi	a5,a5,-48
    80005536:	97a2                	add	a5,a5,s0
    80005538:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    8000553c:	e5040593          	addi	a1,s0,-432
    80005540:	f5040513          	addi	a0,s0,-176
    80005544:	ba8ff0ef          	jal	800048ec <kexec>
    80005548:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000554a:	f5040993          	addi	s3,s0,-176
    8000554e:	6088                	ld	a0,0(s1)
    80005550:	c511                	beqz	a0,8000555c <sys_exec+0xd6>
    kfree(argv[i]);
    80005552:	d78fb0ef          	jal	80000aca <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005556:	04a1                	addi	s1,s1,8
    80005558:	ff349be3          	bne	s1,s3,8000554e <sys_exec+0xc8>
  return ret;
    8000555c:	854a                	mv	a0,s2
    8000555e:	74ba                	ld	s1,424(sp)
    80005560:	791a                	ld	s2,416(sp)
    80005562:	69fa                	ld	s3,408(sp)
    80005564:	6a5a                	ld	s4,400(sp)
    80005566:	a031                	j	80005572 <sys_exec+0xec>
  return -1;
    80005568:	557d                	li	a0,-1
    8000556a:	74ba                	ld	s1,424(sp)
    8000556c:	791a                	ld	s2,416(sp)
    8000556e:	69fa                	ld	s3,408(sp)
    80005570:	6a5a                	ld	s4,400(sp)
}
    80005572:	70fa                	ld	ra,440(sp)
    80005574:	745a                	ld	s0,432(sp)
    80005576:	6139                	addi	sp,sp,448
    80005578:	8082                	ret

000000008000557a <sys_pipe>:

uint64
sys_pipe(void)
{
    8000557a:	7139                	addi	sp,sp,-64
    8000557c:	fc06                	sd	ra,56(sp)
    8000557e:	f822                	sd	s0,48(sp)
    80005580:	f426                	sd	s1,40(sp)
    80005582:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005584:	e44fc0ef          	jal	80001bc8 <myproc>
    80005588:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000558a:	fd840593          	addi	a1,s0,-40
    8000558e:	4501                	li	a0,0
    80005590:	d50fd0ef          	jal	80002ae0 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005594:	fc840593          	addi	a1,s0,-56
    80005598:	fd040513          	addi	a0,s0,-48
    8000559c:	85cff0ef          	jal	800045f8 <pipealloc>
    return -1;
    800055a0:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800055a2:	0a054463          	bltz	a0,8000564a <sys_pipe+0xd0>
  fd0 = -1;
    800055a6:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800055aa:	fd043503          	ld	a0,-48(s0)
    800055ae:	f08ff0ef          	jal	80004cb6 <fdalloc>
    800055b2:	fca42223          	sw	a0,-60(s0)
    800055b6:	08054163          	bltz	a0,80005638 <sys_pipe+0xbe>
    800055ba:	fc843503          	ld	a0,-56(s0)
    800055be:	ef8ff0ef          	jal	80004cb6 <fdalloc>
    800055c2:	fca42023          	sw	a0,-64(s0)
    800055c6:	06054063          	bltz	a0,80005626 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800055ca:	4691                	li	a3,4
    800055cc:	fc440613          	addi	a2,s0,-60
    800055d0:	fd843583          	ld	a1,-40(s0)
    800055d4:	68a8                	ld	a0,80(s1)
    800055d6:	ac2fc0ef          	jal	80001898 <copyout>
    800055da:	00054e63          	bltz	a0,800055f6 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800055de:	4691                	li	a3,4
    800055e0:	fc040613          	addi	a2,s0,-64
    800055e4:	fd843583          	ld	a1,-40(s0)
    800055e8:	0591                	addi	a1,a1,4
    800055ea:	68a8                	ld	a0,80(s1)
    800055ec:	aacfc0ef          	jal	80001898 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800055f0:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800055f2:	04055c63          	bgez	a0,8000564a <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    800055f6:	fc442783          	lw	a5,-60(s0)
    800055fa:	07e9                	addi	a5,a5,26
    800055fc:	078e                	slli	a5,a5,0x3
    800055fe:	97a6                	add	a5,a5,s1
    80005600:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005604:	fc042783          	lw	a5,-64(s0)
    80005608:	07e9                	addi	a5,a5,26
    8000560a:	078e                	slli	a5,a5,0x3
    8000560c:	94be                	add	s1,s1,a5
    8000560e:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005612:	fd043503          	ld	a0,-48(s0)
    80005616:	cd9fe0ef          	jal	800042ee <fileclose>
    fileclose(wf);
    8000561a:	fc843503          	ld	a0,-56(s0)
    8000561e:	cd1fe0ef          	jal	800042ee <fileclose>
    return -1;
    80005622:	57fd                	li	a5,-1
    80005624:	a01d                	j	8000564a <sys_pipe+0xd0>
    if(fd0 >= 0)
    80005626:	fc442783          	lw	a5,-60(s0)
    8000562a:	0007c763          	bltz	a5,80005638 <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    8000562e:	07e9                	addi	a5,a5,26
    80005630:	078e                	slli	a5,a5,0x3
    80005632:	97a6                	add	a5,a5,s1
    80005634:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005638:	fd043503          	ld	a0,-48(s0)
    8000563c:	cb3fe0ef          	jal	800042ee <fileclose>
    fileclose(wf);
    80005640:	fc843503          	ld	a0,-56(s0)
    80005644:	cabfe0ef          	jal	800042ee <fileclose>
    return -1;
    80005648:	57fd                	li	a5,-1
}
    8000564a:	853e                	mv	a0,a5
    8000564c:	70e2                	ld	ra,56(sp)
    8000564e:	7442                	ld	s0,48(sp)
    80005650:	74a2                	ld	s1,40(sp)
    80005652:	6121                	addi	sp,sp,64
    80005654:	8082                	ret
	...

0000000080005660 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005660:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005662:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005664:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005666:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005668:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000566a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000566c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000566e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005670:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005672:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005674:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005676:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005678:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000567a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000567c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000567e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005680:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005682:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005684:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005686:	ac4fd0ef          	jal	8000294a <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000568a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000568c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000568e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005690:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005692:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005694:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005696:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005698:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000569a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000569c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000569e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800056a0:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800056a2:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800056a4:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800056a6:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800056a8:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800056aa:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800056ac:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800056ae:	10200073          	sret
	...

00000000800056be <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800056be:	1141                	addi	sp,sp,-16
    800056c0:	e422                	sd	s0,8(sp)
    800056c2:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800056c4:	0c0007b7          	lui	a5,0xc000
    800056c8:	4705                	li	a4,1
    800056ca:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800056cc:	0c0007b7          	lui	a5,0xc000
    800056d0:	c3d8                	sw	a4,4(a5)
}
    800056d2:	6422                	ld	s0,8(sp)
    800056d4:	0141                	addi	sp,sp,16
    800056d6:	8082                	ret

00000000800056d8 <plicinithart>:

void
plicinithart(void)
{
    800056d8:	1141                	addi	sp,sp,-16
    800056da:	e406                	sd	ra,8(sp)
    800056dc:	e022                	sd	s0,0(sp)
    800056de:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056e0:	cbcfc0ef          	jal	80001b9c <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800056e4:	0085171b          	slliw	a4,a0,0x8
    800056e8:	0c0027b7          	lui	a5,0xc002
    800056ec:	97ba                	add	a5,a5,a4
    800056ee:	40200713          	li	a4,1026
    800056f2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800056f6:	00d5151b          	slliw	a0,a0,0xd
    800056fa:	0c2017b7          	lui	a5,0xc201
    800056fe:	97aa                	add	a5,a5,a0
    80005700:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005704:	60a2                	ld	ra,8(sp)
    80005706:	6402                	ld	s0,0(sp)
    80005708:	0141                	addi	sp,sp,16
    8000570a:	8082                	ret

000000008000570c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000570c:	1141                	addi	sp,sp,-16
    8000570e:	e406                	sd	ra,8(sp)
    80005710:	e022                	sd	s0,0(sp)
    80005712:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005714:	c88fc0ef          	jal	80001b9c <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005718:	00d5151b          	slliw	a0,a0,0xd
    8000571c:	0c2017b7          	lui	a5,0xc201
    80005720:	97aa                	add	a5,a5,a0
  return irq;
}
    80005722:	43c8                	lw	a0,4(a5)
    80005724:	60a2                	ld	ra,8(sp)
    80005726:	6402                	ld	s0,0(sp)
    80005728:	0141                	addi	sp,sp,16
    8000572a:	8082                	ret

000000008000572c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000572c:	1101                	addi	sp,sp,-32
    8000572e:	ec06                	sd	ra,24(sp)
    80005730:	e822                	sd	s0,16(sp)
    80005732:	e426                	sd	s1,8(sp)
    80005734:	1000                	addi	s0,sp,32
    80005736:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005738:	c64fc0ef          	jal	80001b9c <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    8000573c:	00d5151b          	slliw	a0,a0,0xd
    80005740:	0c2017b7          	lui	a5,0xc201
    80005744:	97aa                	add	a5,a5,a0
    80005746:	c3c4                	sw	s1,4(a5)
}
    80005748:	60e2                	ld	ra,24(sp)
    8000574a:	6442                	ld	s0,16(sp)
    8000574c:	64a2                	ld	s1,8(sp)
    8000574e:	6105                	addi	sp,sp,32
    80005750:	8082                	ret

0000000080005752 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005752:	1141                	addi	sp,sp,-16
    80005754:	e406                	sd	ra,8(sp)
    80005756:	e022                	sd	s0,0(sp)
    80005758:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000575a:	479d                	li	a5,7
    8000575c:	04a7ca63          	blt	a5,a0,800057b0 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005760:	0003e797          	auipc	a5,0x3e
    80005764:	ed078793          	addi	a5,a5,-304 # 80043630 <disk>
    80005768:	97aa                	add	a5,a5,a0
    8000576a:	0187c783          	lbu	a5,24(a5)
    8000576e:	e7b9                	bnez	a5,800057bc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005770:	00451693          	slli	a3,a0,0x4
    80005774:	0003e797          	auipc	a5,0x3e
    80005778:	ebc78793          	addi	a5,a5,-324 # 80043630 <disk>
    8000577c:	6398                	ld	a4,0(a5)
    8000577e:	9736                	add	a4,a4,a3
    80005780:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005784:	6398                	ld	a4,0(a5)
    80005786:	9736                	add	a4,a4,a3
    80005788:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000578c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005790:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005794:	97aa                	add	a5,a5,a0
    80005796:	4705                	li	a4,1
    80005798:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000579c:	0003e517          	auipc	a0,0x3e
    800057a0:	eac50513          	addi	a0,a0,-340 # 80043648 <disk+0x18>
    800057a4:	a69fc0ef          	jal	8000220c <wakeup>
}
    800057a8:	60a2                	ld	ra,8(sp)
    800057aa:	6402                	ld	s0,0(sp)
    800057ac:	0141                	addi	sp,sp,16
    800057ae:	8082                	ret
    panic("free_desc 1");
    800057b0:	00002517          	auipc	a0,0x2
    800057b4:	fc050513          	addi	a0,a0,-64 # 80007770 <etext+0x770>
    800057b8:	828fb0ef          	jal	800007e0 <panic>
    panic("free_desc 2");
    800057bc:	00002517          	auipc	a0,0x2
    800057c0:	fc450513          	addi	a0,a0,-60 # 80007780 <etext+0x780>
    800057c4:	81cfb0ef          	jal	800007e0 <panic>

00000000800057c8 <virtio_disk_init>:
{
    800057c8:	1101                	addi	sp,sp,-32
    800057ca:	ec06                	sd	ra,24(sp)
    800057cc:	e822                	sd	s0,16(sp)
    800057ce:	e426                	sd	s1,8(sp)
    800057d0:	e04a                	sd	s2,0(sp)
    800057d2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800057d4:	00002597          	auipc	a1,0x2
    800057d8:	fbc58593          	addi	a1,a1,-68 # 80007790 <etext+0x790>
    800057dc:	0003e517          	auipc	a0,0x3e
    800057e0:	f7c50513          	addi	a0,a0,-132 # 80043758 <disk+0x128>
    800057e4:	da8fb0ef          	jal	80000d8c <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057e8:	100017b7          	lui	a5,0x10001
    800057ec:	4398                	lw	a4,0(a5)
    800057ee:	2701                	sext.w	a4,a4
    800057f0:	747277b7          	lui	a5,0x74727
    800057f4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800057f8:	18f71063          	bne	a4,a5,80005978 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800057fc:	100017b7          	lui	a5,0x10001
    80005800:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    80005802:	439c                	lw	a5,0(a5)
    80005804:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005806:	4709                	li	a4,2
    80005808:	16e79863          	bne	a5,a4,80005978 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000580c:	100017b7          	lui	a5,0x10001
    80005810:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    80005812:	439c                	lw	a5,0(a5)
    80005814:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005816:	16e79163          	bne	a5,a4,80005978 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    8000581a:	100017b7          	lui	a5,0x10001
    8000581e:	47d8                	lw	a4,12(a5)
    80005820:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005822:	554d47b7          	lui	a5,0x554d4
    80005826:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    8000582a:	14f71763          	bne	a4,a5,80005978 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000582e:	100017b7          	lui	a5,0x10001
    80005832:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005836:	4705                	li	a4,1
    80005838:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000583a:	470d                	li	a4,3
    8000583c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000583e:	10001737          	lui	a4,0x10001
    80005842:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005844:	c7ffe737          	lui	a4,0xc7ffe
    80005848:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fbafef>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000584c:	8ef9                	and	a3,a3,a4
    8000584e:	10001737          	lui	a4,0x10001
    80005852:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005854:	472d                	li	a4,11
    80005856:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005858:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    8000585c:	439c                	lw	a5,0(a5)
    8000585e:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005862:	8ba1                	andi	a5,a5,8
    80005864:	12078063          	beqz	a5,80005984 <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005868:	100017b7          	lui	a5,0x10001
    8000586c:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005870:	100017b7          	lui	a5,0x10001
    80005874:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005878:	439c                	lw	a5,0(a5)
    8000587a:	2781                	sext.w	a5,a5
    8000587c:	10079a63          	bnez	a5,80005990 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005880:	100017b7          	lui	a5,0x10001
    80005884:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005888:	439c                	lw	a5,0(a5)
    8000588a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000588c:	10078863          	beqz	a5,8000599c <virtio_disk_init+0x1d4>
  if(max < NUM)
    80005890:	471d                	li	a4,7
    80005892:	10f77b63          	bgeu	a4,a5,800059a8 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    80005896:	bb4fb0ef          	jal	80000c4a <kalloc>
    8000589a:	0003e497          	auipc	s1,0x3e
    8000589e:	d9648493          	addi	s1,s1,-618 # 80043630 <disk>
    800058a2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800058a4:	ba6fb0ef          	jal	80000c4a <kalloc>
    800058a8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800058aa:	ba0fb0ef          	jal	80000c4a <kalloc>
    800058ae:	87aa                	mv	a5,a0
    800058b0:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800058b2:	6088                	ld	a0,0(s1)
    800058b4:	10050063          	beqz	a0,800059b4 <virtio_disk_init+0x1ec>
    800058b8:	0003e717          	auipc	a4,0x3e
    800058bc:	d8073703          	ld	a4,-640(a4) # 80043638 <disk+0x8>
    800058c0:	0e070a63          	beqz	a4,800059b4 <virtio_disk_init+0x1ec>
    800058c4:	0e078863          	beqz	a5,800059b4 <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    800058c8:	6605                	lui	a2,0x1
    800058ca:	4581                	li	a1,0
    800058cc:	e14fb0ef          	jal	80000ee0 <memset>
  memset(disk.avail, 0, PGSIZE);
    800058d0:	0003e497          	auipc	s1,0x3e
    800058d4:	d6048493          	addi	s1,s1,-672 # 80043630 <disk>
    800058d8:	6605                	lui	a2,0x1
    800058da:	4581                	li	a1,0
    800058dc:	6488                	ld	a0,8(s1)
    800058de:	e02fb0ef          	jal	80000ee0 <memset>
  memset(disk.used, 0, PGSIZE);
    800058e2:	6605                	lui	a2,0x1
    800058e4:	4581                	li	a1,0
    800058e6:	6888                	ld	a0,16(s1)
    800058e8:	df8fb0ef          	jal	80000ee0 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800058ec:	100017b7          	lui	a5,0x10001
    800058f0:	4721                	li	a4,8
    800058f2:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800058f4:	4098                	lw	a4,0(s1)
    800058f6:	100017b7          	lui	a5,0x10001
    800058fa:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800058fe:	40d8                	lw	a4,4(s1)
    80005900:	100017b7          	lui	a5,0x10001
    80005904:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005908:	649c                	ld	a5,8(s1)
    8000590a:	0007869b          	sext.w	a3,a5
    8000590e:	10001737          	lui	a4,0x10001
    80005912:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005916:	9781                	srai	a5,a5,0x20
    80005918:	10001737          	lui	a4,0x10001
    8000591c:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005920:	689c                	ld	a5,16(s1)
    80005922:	0007869b          	sext.w	a3,a5
    80005926:	10001737          	lui	a4,0x10001
    8000592a:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000592e:	9781                	srai	a5,a5,0x20
    80005930:	10001737          	lui	a4,0x10001
    80005934:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005938:	10001737          	lui	a4,0x10001
    8000593c:	4785                	li	a5,1
    8000593e:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005940:	00f48c23          	sb	a5,24(s1)
    80005944:	00f48ca3          	sb	a5,25(s1)
    80005948:	00f48d23          	sb	a5,26(s1)
    8000594c:	00f48da3          	sb	a5,27(s1)
    80005950:	00f48e23          	sb	a5,28(s1)
    80005954:	00f48ea3          	sb	a5,29(s1)
    80005958:	00f48f23          	sb	a5,30(s1)
    8000595c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005960:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005964:	100017b7          	lui	a5,0x10001
    80005968:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    8000596c:	60e2                	ld	ra,24(sp)
    8000596e:	6442                	ld	s0,16(sp)
    80005970:	64a2                	ld	s1,8(sp)
    80005972:	6902                	ld	s2,0(sp)
    80005974:	6105                	addi	sp,sp,32
    80005976:	8082                	ret
    panic("could not find virtio disk");
    80005978:	00002517          	auipc	a0,0x2
    8000597c:	e2850513          	addi	a0,a0,-472 # 800077a0 <etext+0x7a0>
    80005980:	e61fa0ef          	jal	800007e0 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005984:	00002517          	auipc	a0,0x2
    80005988:	e3c50513          	addi	a0,a0,-452 # 800077c0 <etext+0x7c0>
    8000598c:	e55fa0ef          	jal	800007e0 <panic>
    panic("virtio disk should not be ready");
    80005990:	00002517          	auipc	a0,0x2
    80005994:	e5050513          	addi	a0,a0,-432 # 800077e0 <etext+0x7e0>
    80005998:	e49fa0ef          	jal	800007e0 <panic>
    panic("virtio disk has no queue 0");
    8000599c:	00002517          	auipc	a0,0x2
    800059a0:	e6450513          	addi	a0,a0,-412 # 80007800 <etext+0x800>
    800059a4:	e3dfa0ef          	jal	800007e0 <panic>
    panic("virtio disk max queue too short");
    800059a8:	00002517          	auipc	a0,0x2
    800059ac:	e7850513          	addi	a0,a0,-392 # 80007820 <etext+0x820>
    800059b0:	e31fa0ef          	jal	800007e0 <panic>
    panic("virtio disk kalloc");
    800059b4:	00002517          	auipc	a0,0x2
    800059b8:	e8c50513          	addi	a0,a0,-372 # 80007840 <etext+0x840>
    800059bc:	e25fa0ef          	jal	800007e0 <panic>

00000000800059c0 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800059c0:	7159                	addi	sp,sp,-112
    800059c2:	f486                	sd	ra,104(sp)
    800059c4:	f0a2                	sd	s0,96(sp)
    800059c6:	eca6                	sd	s1,88(sp)
    800059c8:	e8ca                	sd	s2,80(sp)
    800059ca:	e4ce                	sd	s3,72(sp)
    800059cc:	e0d2                	sd	s4,64(sp)
    800059ce:	fc56                	sd	s5,56(sp)
    800059d0:	f85a                	sd	s6,48(sp)
    800059d2:	f45e                	sd	s7,40(sp)
    800059d4:	f062                	sd	s8,32(sp)
    800059d6:	ec66                	sd	s9,24(sp)
    800059d8:	1880                	addi	s0,sp,112
    800059da:	8a2a                	mv	s4,a0
    800059dc:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800059de:	00c52c83          	lw	s9,12(a0)
    800059e2:	001c9c9b          	slliw	s9,s9,0x1
    800059e6:	1c82                	slli	s9,s9,0x20
    800059e8:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    800059ec:	0003e517          	auipc	a0,0x3e
    800059f0:	d6c50513          	addi	a0,a0,-660 # 80043758 <disk+0x128>
    800059f4:	c18fb0ef          	jal	80000e0c <acquire>
  for(int i = 0; i < 3; i++){
    800059f8:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    800059fa:	44a1                	li	s1,8
      disk.free[i] = 0;
    800059fc:	0003eb17          	auipc	s6,0x3e
    80005a00:	c34b0b13          	addi	s6,s6,-972 # 80043630 <disk>
  for(int i = 0; i < 3; i++){
    80005a04:	4a8d                	li	s5,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005a06:	0003ec17          	auipc	s8,0x3e
    80005a0a:	d52c0c13          	addi	s8,s8,-686 # 80043758 <disk+0x128>
    80005a0e:	a8b9                	j	80005a6c <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80005a10:	00fb0733          	add	a4,s6,a5
    80005a14:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005a18:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005a1a:	0207c563          	bltz	a5,80005a44 <virtio_disk_rw+0x84>
  for(int i = 0; i < 3; i++){
    80005a1e:	2905                	addiw	s2,s2,1
    80005a20:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005a22:	05590963          	beq	s2,s5,80005a74 <virtio_disk_rw+0xb4>
    idx[i] = alloc_desc();
    80005a26:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005a28:	0003e717          	auipc	a4,0x3e
    80005a2c:	c0870713          	addi	a4,a4,-1016 # 80043630 <disk>
    80005a30:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005a32:	01874683          	lbu	a3,24(a4)
    80005a36:	fee9                	bnez	a3,80005a10 <virtio_disk_rw+0x50>
  for(int i = 0; i < NUM; i++){
    80005a38:	2785                	addiw	a5,a5,1
    80005a3a:	0705                	addi	a4,a4,1
    80005a3c:	fe979be3          	bne	a5,s1,80005a32 <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005a40:	57fd                	li	a5,-1
    80005a42:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005a44:	01205d63          	blez	s2,80005a5e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005a48:	f9042503          	lw	a0,-112(s0)
    80005a4c:	d07ff0ef          	jal	80005752 <free_desc>
      for(int j = 0; j < i; j++)
    80005a50:	4785                	li	a5,1
    80005a52:	0127d663          	bge	a5,s2,80005a5e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005a56:	f9442503          	lw	a0,-108(s0)
    80005a5a:	cf9ff0ef          	jal	80005752 <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005a5e:	85e2                	mv	a1,s8
    80005a60:	0003e517          	auipc	a0,0x3e
    80005a64:	be850513          	addi	a0,a0,-1048 # 80043648 <disk+0x18>
    80005a68:	f58fc0ef          	jal	800021c0 <sleep>
  for(int i = 0; i < 3; i++){
    80005a6c:	f9040613          	addi	a2,s0,-112
    80005a70:	894e                	mv	s2,s3
    80005a72:	bf55                	j	80005a26 <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a74:	f9042503          	lw	a0,-112(s0)
    80005a78:	00451693          	slli	a3,a0,0x4

  if(write)
    80005a7c:	0003e797          	auipc	a5,0x3e
    80005a80:	bb478793          	addi	a5,a5,-1100 # 80043630 <disk>
    80005a84:	00a50713          	addi	a4,a0,10
    80005a88:	0712                	slli	a4,a4,0x4
    80005a8a:	973e                	add	a4,a4,a5
    80005a8c:	01703633          	snez	a2,s7
    80005a90:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005a92:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005a96:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005a9a:	6398                	ld	a4,0(a5)
    80005a9c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a9e:	0a868613          	addi	a2,a3,168
    80005aa2:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005aa4:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005aa6:	6390                	ld	a2,0(a5)
    80005aa8:	00d605b3          	add	a1,a2,a3
    80005aac:	4741                	li	a4,16
    80005aae:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005ab0:	4805                	li	a6,1
    80005ab2:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005ab6:	f9442703          	lw	a4,-108(s0)
    80005aba:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80005abe:	0712                	slli	a4,a4,0x4
    80005ac0:	963a                	add	a2,a2,a4
    80005ac2:	058a0593          	addi	a1,s4,88
    80005ac6:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005ac8:	0007b883          	ld	a7,0(a5)
    80005acc:	9746                	add	a4,a4,a7
    80005ace:	40000613          	li	a2,1024
    80005ad2:	c710                	sw	a2,8(a4)
  if(write)
    80005ad4:	001bb613          	seqz	a2,s7
    80005ad8:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005adc:	00166613          	ori	a2,a2,1
    80005ae0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005ae4:	f9842583          	lw	a1,-104(s0)
    80005ae8:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005aec:	00250613          	addi	a2,a0,2
    80005af0:	0612                	slli	a2,a2,0x4
    80005af2:	963e                	add	a2,a2,a5
    80005af4:	577d                	li	a4,-1
    80005af6:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80005afa:	0592                	slli	a1,a1,0x4
    80005afc:	98ae                	add	a7,a7,a1
    80005afe:	03068713          	addi	a4,a3,48
    80005b02:	973e                	add	a4,a4,a5
    80005b04:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005b08:	6398                	ld	a4,0(a5)
    80005b0a:	972e                	add	a4,a4,a1
    80005b0c:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005b10:	4689                	li	a3,2
    80005b12:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005b16:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005b1a:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005b1e:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005b22:	6794                	ld	a3,8(a5)
    80005b24:	0026d703          	lhu	a4,2(a3)
    80005b28:	8b1d                	andi	a4,a4,7
    80005b2a:	0706                	slli	a4,a4,0x1
    80005b2c:	96ba                	add	a3,a3,a4
    80005b2e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005b32:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005b36:	6798                	ld	a4,8(a5)
    80005b38:	00275783          	lhu	a5,2(a4)
    80005b3c:	2785                	addiw	a5,a5,1
    80005b3e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005b42:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b46:	100017b7          	lui	a5,0x10001
    80005b4a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005b4e:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    80005b52:	0003e917          	auipc	s2,0x3e
    80005b56:	c0690913          	addi	s2,s2,-1018 # 80043758 <disk+0x128>
  while(b->disk == 1) {
    80005b5a:	4485                	li	s1,1
    80005b5c:	01079a63          	bne	a5,a6,80005b70 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005b60:	85ca                	mv	a1,s2
    80005b62:	8552                	mv	a0,s4
    80005b64:	e5cfc0ef          	jal	800021c0 <sleep>
  while(b->disk == 1) {
    80005b68:	004a2783          	lw	a5,4(s4)
    80005b6c:	fe978ae3          	beq	a5,s1,80005b60 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005b70:	f9042903          	lw	s2,-112(s0)
    80005b74:	00290713          	addi	a4,s2,2
    80005b78:	0712                	slli	a4,a4,0x4
    80005b7a:	0003e797          	auipc	a5,0x3e
    80005b7e:	ab678793          	addi	a5,a5,-1354 # 80043630 <disk>
    80005b82:	97ba                	add	a5,a5,a4
    80005b84:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005b88:	0003e997          	auipc	s3,0x3e
    80005b8c:	aa898993          	addi	s3,s3,-1368 # 80043630 <disk>
    80005b90:	00491713          	slli	a4,s2,0x4
    80005b94:	0009b783          	ld	a5,0(s3)
    80005b98:	97ba                	add	a5,a5,a4
    80005b9a:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005b9e:	854a                	mv	a0,s2
    80005ba0:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005ba4:	bafff0ef          	jal	80005752 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005ba8:	8885                	andi	s1,s1,1
    80005baa:	f0fd                	bnez	s1,80005b90 <virtio_disk_rw+0x1d0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005bac:	0003e517          	auipc	a0,0x3e
    80005bb0:	bac50513          	addi	a0,a0,-1108 # 80043758 <disk+0x128>
    80005bb4:	af0fb0ef          	jal	80000ea4 <release>
}
    80005bb8:	70a6                	ld	ra,104(sp)
    80005bba:	7406                	ld	s0,96(sp)
    80005bbc:	64e6                	ld	s1,88(sp)
    80005bbe:	6946                	ld	s2,80(sp)
    80005bc0:	69a6                	ld	s3,72(sp)
    80005bc2:	6a06                	ld	s4,64(sp)
    80005bc4:	7ae2                	ld	s5,56(sp)
    80005bc6:	7b42                	ld	s6,48(sp)
    80005bc8:	7ba2                	ld	s7,40(sp)
    80005bca:	7c02                	ld	s8,32(sp)
    80005bcc:	6ce2                	ld	s9,24(sp)
    80005bce:	6165                	addi	sp,sp,112
    80005bd0:	8082                	ret

0000000080005bd2 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005bd2:	1101                	addi	sp,sp,-32
    80005bd4:	ec06                	sd	ra,24(sp)
    80005bd6:	e822                	sd	s0,16(sp)
    80005bd8:	e426                	sd	s1,8(sp)
    80005bda:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005bdc:	0003e497          	auipc	s1,0x3e
    80005be0:	a5448493          	addi	s1,s1,-1452 # 80043630 <disk>
    80005be4:	0003e517          	auipc	a0,0x3e
    80005be8:	b7450513          	addi	a0,a0,-1164 # 80043758 <disk+0x128>
    80005bec:	a20fb0ef          	jal	80000e0c <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005bf0:	100017b7          	lui	a5,0x10001
    80005bf4:	53b8                	lw	a4,96(a5)
    80005bf6:	8b0d                	andi	a4,a4,3
    80005bf8:	100017b7          	lui	a5,0x10001
    80005bfc:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    80005bfe:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005c02:	689c                	ld	a5,16(s1)
    80005c04:	0204d703          	lhu	a4,32(s1)
    80005c08:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005c0c:	04f70663          	beq	a4,a5,80005c58 <virtio_disk_intr+0x86>
    __sync_synchronize();
    80005c10:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005c14:	6898                	ld	a4,16(s1)
    80005c16:	0204d783          	lhu	a5,32(s1)
    80005c1a:	8b9d                	andi	a5,a5,7
    80005c1c:	078e                	slli	a5,a5,0x3
    80005c1e:	97ba                	add	a5,a5,a4
    80005c20:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005c22:	00278713          	addi	a4,a5,2
    80005c26:	0712                	slli	a4,a4,0x4
    80005c28:	9726                	add	a4,a4,s1
    80005c2a:	01074703          	lbu	a4,16(a4)
    80005c2e:	e321                	bnez	a4,80005c6e <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005c30:	0789                	addi	a5,a5,2
    80005c32:	0792                	slli	a5,a5,0x4
    80005c34:	97a6                	add	a5,a5,s1
    80005c36:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005c38:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c3c:	dd0fc0ef          	jal	8000220c <wakeup>

    disk.used_idx += 1;
    80005c40:	0204d783          	lhu	a5,32(s1)
    80005c44:	2785                	addiw	a5,a5,1
    80005c46:	17c2                	slli	a5,a5,0x30
    80005c48:	93c1                	srli	a5,a5,0x30
    80005c4a:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005c4e:	6898                	ld	a4,16(s1)
    80005c50:	00275703          	lhu	a4,2(a4)
    80005c54:	faf71ee3          	bne	a4,a5,80005c10 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005c58:	0003e517          	auipc	a0,0x3e
    80005c5c:	b0050513          	addi	a0,a0,-1280 # 80043758 <disk+0x128>
    80005c60:	a44fb0ef          	jal	80000ea4 <release>
}
    80005c64:	60e2                	ld	ra,24(sp)
    80005c66:	6442                	ld	s0,16(sp)
    80005c68:	64a2                	ld	s1,8(sp)
    80005c6a:	6105                	addi	sp,sp,32
    80005c6c:	8082                	ret
      panic("virtio_disk_intr status");
    80005c6e:	00002517          	auipc	a0,0x2
    80005c72:	bea50513          	addi	a0,a0,-1046 # 80007858 <etext+0x858>
    80005c76:	b6bfa0ef          	jal	800007e0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
